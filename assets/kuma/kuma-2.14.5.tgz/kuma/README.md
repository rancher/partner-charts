[![][kuma-logo]][kuma-url]

A Helm chart for the Kuma Control Plane

![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![Version: 2.14.5](https://img.shields.io/badge/Version-2.14.5-informational?style=flat-square) ![AppVersion: 2.14.5](https://img.shields.io/badge/AppVersion-2.14.5-informational?style=flat-square)

**Homepage:** <https://github.com/kumahq/kuma>

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| global.image.registry | string | `"docker.io/kumahq"` | Default registry for all Kuma Images |
| global.image.tag | string | `nil` | The default tag for all Kuma images, which itself defaults to .Chart.AppVersion |
| global.imagePullSecrets | list | `[]` | Add `imagePullSecrets` to all the service accounts used for Kuma components |
| patchSystemNamespace | bool | `true` | Whether to patch the target namespace with the system label |
| installCrdsOnUpgrade.enabled | bool | `true` | Whether install new CRDs before upgrade (if any were introduced with the new version of Kuma) |
| installCrdsOnUpgrade.imagePullSecrets | list | `[]` | The `imagePullSecrets` to attach to the Service Account running CRD installation. This field will be deprecated in a future release, please use .global.imagePullSecrets |
| noHelmHooks | bool | `false` | Whether to disable all helm hooks |
| namespaceAllowList | list | `[]` | Namespaces that are part of the Mesh. When specified, the control plane receives write permissions only for the allowed namespaces. If not specified, the control plane has write permissions for all namespaces. |
| skipRBAC | bool | `false` | Determines whether ClusterRole, Role, ClusterRoleBinding, RoleBinding for Kuma should be created. If set to true, the user must manually create these resources before installation. |
| restartOnSecretChange | bool | `true` | Whether to restart control-plane by calculating a new checksum for the secret |
| controlPlane.environment | string | `"kubernetes"` | Environment that control plane is run in, useful when running universal global control plane on k8s |
| controlPlane.extraLabels | object | `{}` | Labels to add to resources in addition to default labels |
| controlPlane.logLevel | string | `"info"` | Kuma CP log level: one of off,info,debug |
| controlPlane.logOutputPath | string | `""` | Kuma CP log output path: Defaults to /dev/stdout |
| controlPlane.mode | string | `"zone"` | Kuma CP modes: one of zone,global |
| controlPlane.zone | string | `nil` | Kuma CP zone, if running multizone |
| controlPlane.kdsGlobalAddress | string | `""` | Only used in `zone` mode |
| controlPlane.replicas | int | `1` | Number of replicas of the Kuma CP. Ignored when autoscaling is enabled |
| controlPlane.restartPolicy | string | `"Always"` | Pod restart policy for the Control Plane. |
| controlPlane.minReadySeconds | int | `0` | Minimum number of seconds for which a newly created pod should be ready for it to be considered available. |
| controlPlane.deploymentAnnotations | object | `{}` | Annotations applied only to the `Deployment` resource |
| controlPlane.podAnnotations | object | `{}` | Annotations applied only to the `Pod` resource |
| controlPlane.autoscaling.enabled | bool | `false` | Whether to enable Horizontal Pod Autoscaling, which requires the [Metrics Server](https://github.com/kubernetes-sigs/metrics-server) in the cluster |
| controlPlane.autoscaling.minReplicas | int | `2` | The minimum CP pods to allow |
| controlPlane.autoscaling.maxReplicas | int | `5` | The max CP pods to scale to |
| controlPlane.autoscaling.metrics | list | `[{"resource":{"name":"cpu","target":{"averageUtilization":80,"type":"Utilization"}},"type":"Resource"}]` | Target metrics for the HPA to scale on |
| controlPlane.autoscaling.behavior | object | `{}` | Scaling behavior for the HPA (https://kubernetes.io/docs/tasks/run-application/horizontal-pod-autoscale/#configurable-scaling-behavior). Omit to use Kubernetes defaults. |
| controlPlane.nodeSelector | object | `{"kubernetes.io/os":"linux"}` | Node selector for the Kuma Control Plane pods |
| controlPlane.tolerations | list | `[]` | Tolerations for the Kuma Control Plane pods |
| controlPlane.podDisruptionBudget.enabled | bool | `false` | Whether to create a pod disruption budget |
| controlPlane.podDisruptionBudget.maxUnavailable | int | `1` | The maximum number of unavailable pods allowed by the budget |
| controlPlane.affinity | object | `{"podAntiAffinity":{"preferredDuringSchedulingIgnoredDuringExecution":[{"podAffinityTerm":{"labelSelector":{"matchExpressions":[{"key":"app.kubernetes.io/name","operator":"In","values":["{{ include \"kuma.name\" . }}"]},{"key":"app.kubernetes.io/instance","operator":"In","values":["{{ .Release.Name }}"]},{"key":"app","operator":"In","values":["{{ include \"kuma.name\" . }}-control-plane"]}]},"topologyKey":"kubernetes.io/hostname"},"weight":100}]}}` | Affinity placement rule for the Kuma Control Plane pods. This is rendered as a template, so you can reference other helm variables or includes. |
| controlPlane.topologySpreadConstraints | string | `nil` | Topology spread constraints rule for the Kuma Control Plane pods. This is rendered as a template, so you can use variables to generate match labels. |
| controlPlane.priorityClassName | string | `""` | Priority Class Name of the Kuma Control Plane |
| controlPlane.injectorFailurePolicy | string | `"Fail"` | Failure policy of the mutating webhook implemented by the Kuma Injector component |
| controlPlane.madsServer.enabled | bool | `true` | Whether the Monitoring Assignment Discovery Service (MADS) server is enabled |
| controlPlane.service.apiServer.http.nodePort | int | `30681` | Port on which Http api server Service is exposed on Node for service of type NodePort |
| controlPlane.service.apiServer.https.nodePort | int | `30682` | Port on which Https api server Service is exposed on Node for service of type NodePort |
| controlPlane.service.enabled | bool | `true` | Whether to create a service resource. |
| controlPlane.service.name | string | `nil` | Optionally override of the Kuma Control Plane Service's name |
| controlPlane.service.type | string | `"ClusterIP"` | Service type of the Kuma Control Plane |
| controlPlane.service.annotations | object | `{"prometheus.io/port":"5680","prometheus.io/scrape":"true"}` | Annotations to put on the Kuma Control Plane |
| controlPlane.ingress.enabled | bool | `false` | Install K8s Ingress resource that exposes GUI and API |
| controlPlane.ingress.ingressClassName | string | `nil` | IngressClass defines which controller will implement the resource |
| controlPlane.ingress.hostname | string | `nil` | Ingress hostname |
| controlPlane.ingress.annotations | object | `{}` | Map of ingress annotations. |
| controlPlane.ingress.path | string | `"/"` | Ingress path. |
| controlPlane.ingress.pathType | string | `"ImplementationSpecific"` | Each path in an Ingress is required to have a corresponding path type. (ImplementationSpecific/Exact/Prefix) |
| controlPlane.ingress.servicePort | int | `5681` | Port from kuma-cp to use to expose API and GUI. Switch to 5682 to expose TLS port |
| controlPlane.serviceMonitor.enabled | bool | `false` | Install CoreOS ServiceMonitor custom resource that configures metrics scraping. |
| controlPlane.serviceMonitor.annotations | object | `{}` | Map of serviceMonitor annotations. |
| controlPlane.globalZoneSyncService.enabled | bool | `true` | Whether to create a k8s service for the global zone sync service. It will only be created when enabled and deploying the global control plane. |
| controlPlane.globalZoneSyncService.type | string | `"LoadBalancer"` | Service type of the Global-zone sync |
| controlPlane.globalZoneSyncService.loadBalancerIP | string | `nil` | Optionally specify IP to be used by cloud provider when configuring load balancer |
| controlPlane.globalZoneSyncService.loadBalancerSourceRanges | list | `[]` | Optionally specify allowed source ranges that can access the load balancer |
| controlPlane.globalZoneSyncService.annotations | object | `{}` | Additional annotations to put on the Global Zone Sync Service |
| controlPlane.globalZoneSyncService.nodePort | int | `30685` | Port on which Global Zone Sync Service is exposed on Node for service of type NodePort |
| controlPlane.globalZoneSyncService.port | int | `5685` | Port on which Global Zone Sync Service is exposed |
| controlPlane.globalZoneSyncService.protocol | string | `"grpc"` | Protocol of the Global Zone Sync service port |
| controlPlane.defaults.skipMeshCreation | bool | `false` | Whether to skip creating the default Mesh |
| controlPlane.automountServiceAccountToken | bool | `true` | Whether to automountServiceAccountToken for cp. Optionally set to false |
| controlPlane.resources | object | `{"limits":{"memory":"256Mi"},"requests":{"cpu":"500m","memory":"256Mi"}}` | Optionally override the resource spec |
| controlPlane.runtime | object | `{"goMaxProcs":{"divisor":"1"},"goMemLimit":{"divisor":"1"}}` | Go runtime settings for the control plane |
| controlPlane.runtime.goMaxProcs | object | `{"divisor":"1"}` | Divisor for GOMAXPROCS (resourceFieldRef divisor for limits.cpu) |
| controlPlane.runtime.goMemLimit | object | `{"divisor":"1"}` | Divisor for GOMEMLIMIT (resourceFieldRef divisor for limits.memory) |
| controlPlane.lifecycle | object | `{}` | Pod lifecycle settings (useful for adding a preStop hook, when using AWS ALB or NLB) |
| controlPlane.terminationGracePeriodSeconds | int | `30` | Number of seconds to wait before force killing the pod. Make sure to update this if you add a preStop hook. |
| controlPlane.tls.general.secretName | string | `""` | Secret that contains tls.crt, tls.key [and ca.crt when no controlPlane.tls.general.caSecretName specified] for protecting Kuma in-cluster communication |
| controlPlane.tls.general.caSecretName | string | `""` | Secret that contains ca.crt that was used to sign cert for protecting Kuma in-cluster communication (ca.crt present in this secret have precedence over the one provided in the controlPlane.tls.general.secretName) |
| controlPlane.tls.general.caBundle | string | `""` | Base64 encoded CA certificate (the same as in controlPlane.tls.general.secret#ca.crt) |
| controlPlane.tls.general.certManager.enabled | bool | `false` | Enable cert-manager integration for webhook certificates. When enabled, cert-manager will manage the webhook certificates and inject the CA bundle into webhook configurations automatically. This requires cert-manager to be installed in the cluster. Note: When enabled, secretName and caBundle should be empty. |
| controlPlane.tls.general.certManager.issuerRef | object | `{"kind":"Issuer","name":""}` | Reference to an existing issuer. If not specified, a self-signed issuer is created. |
| controlPlane.tls.general.certManager.issuerRef.name | string | `""` | Name of an existing cert-manager Issuer or ClusterIssuer. If empty, a self-signed issuer will be created automatically. |
| controlPlane.tls.general.certManager.issuerRef.kind | string | `"Issuer"` | Kind of the issuer: "Issuer" or "ClusterIssuer" |
| controlPlane.tls.general.certManager.dnsNames | list | `["{{ include \"kuma.controlPlane.serviceName\" . }}.{{ .Release.Namespace }}","{{ include \"kuma.controlPlane.serviceName\" . }}.{{ .Release.Namespace }}.svc","{{ include \"kuma.controlPlane.serviceName\" . }}.{{ .Release.Namespace }}.svc.cluster.local"]` | DNS names to include in the certificate SANs. Supports Helm template strings (evaluated via tpl). |
| controlPlane.tls.apiServer.secretName | string | `""` | Secret that contains tls.crt, tls.key for protecting Kuma API on HTTPS |
| controlPlane.tls.apiServer.clientCertsSecretName | string | `""` | Secret that contains list of .pem certificates that can access admin endpoints of Kuma API on HTTPS |
| controlPlane.tls.kdsGlobalServer.secretName | string | `""` | Name of the K8s TLS Secret resource. If you set this and don't set create=true, you have to create the secret manually. |
| controlPlane.tls.kdsGlobalServer.create | bool | `false` | Whether to create the TLS secret in helm. |
| controlPlane.tls.kdsGlobalServer.cert | string | `""` | The TLS certificate to offer. |
| controlPlane.tls.kdsGlobalServer.key | string | `""` | The TLS key to use. |
| controlPlane.tls.kdsZoneClient.secretName | string | `""` | Name of the K8s Secret resource that contains ca.crt which was used to sign the certificate of KDS Global Server. If you set this and don't set create=true, you have to create the secret manually. |
| controlPlane.tls.kdsZoneClient.create | bool | `false` | Whether to create the TLS secret in helm. |
| controlPlane.tls.kdsZoneClient.cert | string | `""` | CA bundle that was used to sign the certificate of KDS Global Server. |
| controlPlane.tls.kdsZoneClient.skipVerify | bool | `false` | If true, TLS cert of the server is not verified. |
| controlPlane.serviceAccountAnnotations | object | `{}` | Annotations to add for Control Plane's Service Account |
| controlPlane.image.pullPolicy | string | `"IfNotPresent"` | Kuma CP ImagePullPolicy |
| controlPlane.image.repository | string | `"kuma-cp"` | Kuma CP image repository |
| controlPlane.image.tag | string | `nil` | Kuma CP Image tag. When not specified, the value is copied from global.tag |
| controlPlane.secrets | object with { Env: string, Secret: string, Key: string } | `nil` | Secrets to add as environment variables, where `Env` is the name of the env variable, `Secret` is the name of the Secret, and `Key` is the key of the Secret value to use |
| controlPlane.envVars | object | `{}` | Additional environment variables that will be passed to the control plane |
| controlPlane.envVarEntries | string | `nil` | Additional environment variables that will be passed to the control plane. Can be used with Kubernetes downward API |
| controlPlane.extraConfigMaps | list | `[]` | Additional config maps to mount into the control plane, with optional inline values |
| controlPlane.extraSecrets | object with { name: string, mountPath: string, readOnly: string } | `nil` | Additional secrets to mount into the control plane, where `Env` is the name of the env variable, `Secret` is the name of the Secret, and `Key` is the key of the Secret value to use |
| controlPlane.webhooks.validator.additionalRules | string | `""` | Additional rules to apply on Kuma validator webhook. Useful when building custom policy on top of Kuma. |
| controlPlane.webhooks.ownerReference.additionalRules | string | `""` | Additional rules to apply on Kuma owner reference webhook. Useful when building custom policy on top of Kuma. |
| controlPlane.hostNetwork | bool | `false` | Specifies if the deployment should be started in hostNetwork mode. |
| controlPlane.admissionServerPort | int | `5443` | Define a new server port for the admission controller. Recommended to set in combination with hostNetwork to prevent multiple port bindings on the same port (like Calico in AWS EKS). |
| controlPlane.podSecurityContext | object | `{"runAsNonRoot":true,"seccompProfile":{"type":"RuntimeDefault"}}` | Security context at the pod level for control plane. |
| controlPlane.containerSecurityContext | object | `{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]},"readOnlyRootFilesystem":true}` | Security context at the container level for control plane. |
| controlPlane.supportGatewaySecretsInAllNamespaces | bool | `false` | If true, then control plane can support TLS secrets for builtin gateway outside of mesh system namespace. The downside is that control plane requires permission to read Secrets in all namespaces. |
| controlPlane.dns | object | `{"config":{"nameservers":[],"searches":[]},"policy":""}` | DNS configuration for the control-plane pod. This is equivalent to the [Kubernetes DNS policy](https://kubernetes.io/docs/concepts/services-networking/dns-pod-service/#pod-s-dns-policy). |
| controlPlane.dns.policy | string | `""` | Defines how DNS resolution is configured for that Pod. |
| controlPlane.dns.config | object | `{"nameservers":[],"searches":[]}` | Optional dns configuration, required when policy is 'None' |
| controlPlane.dns.config.nameservers | list | `[]` | A list of IP addresses that will be used as DNS servers for the Pod. There can be at most 3 IP addresses specified. |
| controlPlane.dns.config.searches | list | `[]` | A list of DNS search domains for hostname lookup in the Pod. |
| controlPlane.skipClusterRoleCreation | bool | `false` | Determines whether ClusterRole and ClusterRoleBinding for the control plane should be created. If set to true, the user must manually create these resources before deploying the control plane. |
| cni.enabled | bool | `false` | Install Kuma with CNI instead of proxy init container |
| cni.chained | bool | `false` | Install CNI in chained mode |
| cni.netDir | string | `"/etc/cni/multus/net.d"` | Set the CNI install directory |
| cni.binDir | string | `"/var/lib/cni/bin"` | Set the CNI bin directory |
| cni.confName | string | `"kuma-cni.conf"` | Set the CNI configuration name |
| cni.logLevel | string | `"info"` | CNI log level: one of off,info,debug |
| cni.nodeSelector | object | `{"kubernetes.io/os":"linux"}` | Node Selector for the CNI pods |
| cni.tolerations | list | `[]` | Additional tolerations for the CNI pods |
| cni.podAnnotations | object | `{}` | Additional pod annotations |
| cni.namespace | string | `"kube-system"` | Set the CNI namespace |
| cni.affinity | object | `{}` | Set the CNI affinity |
| cni.taintController.enabled | bool | `true` | Enable taint controller |
| cni.image.repository | string | `"kuma-cni"` | CNI image repository |
| cni.image.tag | string | `nil` | CNI image tag - defaults to .Chart.AppVersion |
| cni.image.imagePullPolicy | string | `"IfNotPresent"` | CNI image pull policy |
| cni.restartPolicy | string | `"Always"` | Pod restart policy for the CNI pods |
| cni.delayStartupSeconds | int | `0` | it's only useful in tests to trigger a possible race condition |
| cni.experimental | object | `{"imageEbpf":{"registry":"docker.io/kumahq","repository":"merbridge","tag":"0.8.5"}}` | use new CNI (experimental) |
| cni.experimental.imageEbpf.registry | string | `"docker.io/kumahq"` | CNI experimental eBPF image registry |
| cni.experimental.imageEbpf.repository | string | `"merbridge"` | CNI experimental eBPF image repository |
| cni.experimental.imageEbpf.tag | string | `"0.8.5"` | CNI experimental eBPF image tag |
| cni.resources.requests.cpu | string | `"100m"` |  |
| cni.resources.requests.memory | string | `"100Mi"` |  |
| cni.resources.limits.memory | string | `"100Mi"` |  |
| cni.podSecurityContext | object | `{}` | Security context at the pod level for cni |
| cni.containerSecurityContext | object | `{"readOnlyRootFilesystem":true,"runAsGroup":0,"runAsNonRoot":false,"runAsUser":0}` | Security context at the container level for cni |
| dataPlane.dnsLogging | bool | `false` | If true, then turn on CoreDNS query logging |
| dataPlane.image.repository | string | `"kuma-dp"` | The Kuma DP image repository |
| dataPlane.image.pullPolicy | string | `"IfNotPresent"` | Kuma DP ImagePullPolicy |
| dataPlane.image.tag | string | `nil` | Kuma DP Image Tag. When not specified, the value is copied from global.tag |
| dataPlane.initImage.repository | string | `"kuma-init"` | The Kuma DP init image repository |
| dataPlane.initImage.tag | string | `nil` | Kuma DP init image tag When not specified, the value is copied from global.tag |
| dataPlane.initContainer | object | `{"resources":{"limits":{"cpu":"0","memory":"50M"},"requests":{"cpu":"20m","memory":"20M"}}}` | Resource limits and requests for the kuma-init container. Set cpu limit to "0" to disable the CPU limit (default). |
| dataPlane.validationContainer | object | `{"resources":{"limits":{"cpu":"0","memory":"50M"},"requests":{"cpu":"20m","memory":"20M"}}}` | Resource limits and requests for the kuma-validation init container. Set cpu limit to "0" to disable the CPU limit (default). |
| dataPlane.sidecarContainer | object | `{"resources":{"limits":{"cpu":"0","memory":"512Mi"},"requests":{"cpu":"50m","memory":"64Mi"}}}` | Resource limits and requests for the kuma-sidecar container. Set cpu limit to "0" to disable the CPU limit (default). |
| dataPlane.features.unifiedResourceNaming | bool | `false` | Enables automatic injection of the unified naming for Envoy resources and stats feature flag. When set to true, it sets the environment variable KUMA_RUNTIME_KUBERNETES_INJECTOR_UNIFIED_RESOURCE_NAMING_ENABLED=true in the control plane, which causes the sidecar injector to add KUMA_DATAPLANE_RUNTIME_UNIFIED_RESOURCE_NAMING_ENABLED=true to each injected kuma-sidecar container. It also adds the same KUMA_DATAPLANE_RUNTIME_UNIFIED_RESOURCE_NAMING_ENABLED=true environment variable to all ZoneIngress and ZoneEgress deployments. This option only automates setting the required flags and does not enable or disable the feature itself. You can still opt in manually by setting KUMA_DATAPLANE_RUNTIME_UNIFIED_RESOURCE_NAMING_ENABLED=true in ZoneIngress or ZoneEgress deployments, or in regular data plane proxies using a ContainerPatch |
| ingress.enabled | bool | `false` | If true, it deploys Ingress for cross cluster communication |
| ingress.extraLabels | object | `{}` | Labels to add to resources, in addition to default labels |
| ingress.drainTime | string | `"30s"` | Time for which old listener will still be active as draining |
| ingress.replicas | int | `1` | Number of replicas of the Ingress. Ignored when autoscaling is enabled. |
| ingress.logLevel | string | `"info"` | Log level for ingress (available values: off|info|debug) |
| ingress.restartPolicy | string | `"Always"` | Pod restart policy for the ingress pods |
| ingress.resources | object | `{"limits":{"cpu":"1000m","memory":"512Mi"},"requests":{"cpu":"50m","memory":"64Mi"}}` | Define the resources to allocate to mesh ingress |
| ingress.livenessProbe | object | `{"enabled":true,"failureThreshold":12,"initialDelaySeconds":60,"periodSeconds":5,"successThreshold":1,"timeoutSeconds":3}` | Liveness probe settings for the Ingress proxy |
| ingress.livenessProbe.enabled | bool | `true` | Whether to enable the liveness probe. |
| ingress.readinessProbe | object | `{"enabled":true,"failureThreshold":12,"initialDelaySeconds":1,"periodSeconds":5,"successThreshold":1,"timeoutSeconds":3}` | Readiness probe settings for the Ingress proxy |
| ingress.readinessProbe.enabled | bool | `true` | Whether to enable the readiness probe. |
| ingress.startupProbe | object | `{"enabled":false,"failureThreshold":60,"initialDelaySeconds":1,"periodSeconds":5,"successThreshold":1,"timeoutSeconds":3}` | Startup probe settings for the Ingress proxy |
| ingress.startupProbe.enabled | bool | `false` | Whether to enable the startup probe. |
| ingress.lifecycle | object | `{}` | Pod lifecycle settings (useful for adding a preStop hook, when using AWS ALB or NLB) |
| ingress.terminationGracePeriodSeconds | int | `40` | Number of seconds to wait before force killing the pod. Make sure to update this if you add a preStop hook. |
| ingress.autoscaling.enabled | bool | `false` | Whether to enable Horizontal Pod Autoscaling, which requires the [Metrics Server](https://github.com/kubernetes-sigs/metrics-server) in the cluster |
| ingress.autoscaling.minReplicas | int | `2` | The minimum CP pods to allow |
| ingress.autoscaling.maxReplicas | int | `5` | The max CP pods to scale to |
| ingress.autoscaling.metrics | list | `[{"resource":{"name":"cpu","target":{"averageUtilization":80,"type":"Utilization"}},"type":"Resource"}]` | Target metrics for the HPA to scale on |
| ingress.service.enabled | bool | `true` | Whether to create a Service resource. |
| ingress.service.type | string | `"LoadBalancer"` | Service type of the Ingress |
| ingress.service.loadBalancerIP | string | `nil` | Optionally specify IP to be used by cloud provider when configuring load balancer |
| ingress.service.loadBalancerSourceRanges | list | `[]` | A list of CIDRs or IPs for the cloud-provider load balancer to allow access from. |
| ingress.service.annotations | object | `{}` | Additional annotations to put on the Ingress service |
| ingress.service.port | int | `10001` | Port on which Ingress is exposed |
| ingress.service.nodePort | string | `nil` | Port on which service is exposed on Node for service of type NodePort |
| ingress.annotations | object | `{}` | Additional pod annotations (deprecated favor `podAnnotations`) |
| ingress.podAnnotations | object | `{}` | Additional pod annotations |
| ingress.deploymentAnnotations | object | `{}` | Annotations to add to the Deployment resource. |
| ingress.nodeSelector | object | `{"kubernetes.io/os":"linux"}` | Node Selector for the Ingress pods |
| ingress.tolerations | list | `[]` | Tolerations for the Ingress pods |
| ingress.podDisruptionBudget.enabled | bool | `false` | Whether to create a pod disruption budget |
| ingress.podDisruptionBudget.maxUnavailable | int | `1` | The maximum number of unavailable pods allowed by the budget |
| ingress.affinity | object | `{"podAntiAffinity":{"preferredDuringSchedulingIgnoredDuringExecution":[{"podAffinityTerm":{"labelSelector":{"matchExpressions":[{"key":"app.kubernetes.io/name","operator":"In","values":["{{ include \"kuma.name\" . }}"]},{"key":"app.kubernetes.io/instance","operator":"In","values":["{{ .Release.Name }}"]},{"key":"app","operator":"In","values":["kuma-ingress"]}]},"topologyKey":"kubernetes.io/hostname"},"weight":100}]}}` | Affinity placement rule for the Kuma Ingress pods This is rendered as a template, so you can reference other helm variables or includes. |
| ingress.topologySpreadConstraints | string | `nil` | Topology spread constraints rule for the Kuma Mesh Ingress pods. This is rendered as a template, so you can use variables to generate match labels. |
| ingress.priorityClassName | string | `""` | Priority Class Name of the ingress |
| ingress.podSecurityContext | object | `{"runAsGroup":5678,"runAsNonRoot":true,"runAsUser":5678}` | Security context at the pod level for ingress |
| ingress.containerSecurityContext | object | `{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]},"readOnlyRootFilesystem":true}` | Security context at the container level for ingress |
| ingress.serviceAccountAnnotations | object | `{}` | Annotations to add for Control Plane's Service Account |
| ingress.automountServiceAccountToken | bool | `true` | Whether to automountServiceAccountToken for cp. Optionally set to false |
| ingress.dns | object | `{"config":{"nameservers":[],"searches":[]},"policy":""}` | DNS configuration for the ingress pod. This is equivalent to the [Kubernetes DNS policy](https://kubernetes.io/docs/concepts/services-networking/dns-pod-service/#pod-s-dns-policy). |
| ingress.dns.policy | string | `""` | Defines how DNS resolution is configured for that Pod. |
| ingress.dns.config | object | `{"nameservers":[],"searches":[]}` | Optional dns configuration, required when policy is 'None' |
| ingress.dns.config.nameservers | list | `[]` | A list of IP addresses that will be used as DNS servers for the Pod. There can be at most 3 IP addresses specified. |
| ingress.dns.config.searches | list | `[]` | A list of DNS search domains for hostname lookup in the Pod. |
| egress.enabled | bool | `false` | If true, it deploys Egress for cross cluster communication |
| egress.extraLabels | object | `{}` | Labels to add to resources, in addition to the default labels. |
| egress.drainTime | string | `"30s"` | Time for which old listener will still be active as draining |
| egress.replicas | int | `1` | Number of replicas of the Egress. Ignored when autoscaling is enabled. |
| egress.logLevel | string | `"info"` | Log level for egress (available values: off|info|debug) |
| egress.restartPolicy | string | `"Always"` | Pod restart policy for the egress pods |
| egress.autoscaling.enabled | bool | `false` | Whether to enable Horizontal Pod Autoscaling, which requires the [Metrics Server](https://github.com/kubernetes-sigs/metrics-server) in the cluster |
| egress.autoscaling.minReplicas | int | `2` | The minimum CP pods to allow |
| egress.autoscaling.maxReplicas | int | `5` | The max CP pods to scale to |
| egress.autoscaling.metrics | list | `[{"resource":{"name":"cpu","target":{"averageUtilization":80,"type":"Utilization"}},"type":"Resource"}]` | Target metrics for the HPA to scale on |
| egress.resources.requests.cpu | string | `"50m"` |  |
| egress.resources.requests.memory | string | `"64Mi"` |  |
| egress.resources.limits.cpu | string | `"1000m"` |  |
| egress.resources.limits.memory | string | `"512Mi"` |  |
| egress.livenessProbe | object | `{"enabled":true,"failureThreshold":12,"initialDelaySeconds":60,"periodSeconds":5,"successThreshold":1,"timeoutSeconds":3}` | Liveness probe settings for the Egress proxy |
| egress.livenessProbe.enabled | bool | `true` | Whether to enable the liveness probe. |
| egress.readinessProbe | object | `{"enabled":true,"failureThreshold":12,"initialDelaySeconds":1,"periodSeconds":5,"successThreshold":1,"timeoutSeconds":3}` | Readiness probe settings for the Egress proxy |
| egress.readinessProbe.enabled | bool | `true` | Whether to enable the readiness probe. |
| egress.startupProbe | object | `{"enabled":false,"failureThreshold":60,"initialDelaySeconds":1,"periodSeconds":5,"successThreshold":1,"timeoutSeconds":3}` | Startup probe settings for the Egress proxy |
| egress.startupProbe.enabled | bool | `false` | Whether to enable the startup probe. |
| egress.service.enabled | bool | `true` | Whether to create the service object |
| egress.service.type | string | `"ClusterIP"` | Service type of the Egress |
| egress.service.loadBalancerIP | string | `nil` | Optionally specify IP to be used by cloud provider when configuring load balancer |
| egress.service.annotations | object | `{}` | Additional annotations to put on the Egress service |
| egress.service.port | int | `10002` | Port on which Egress is exposed |
| egress.service.nodePort | string | `nil` | Port on which service is exposed on Node for service of type NodePort |
| egress.annotations | object | `{}` | Additional pod annotations (deprecated favor `podAnnotations`) |
| egress.podAnnotations | object | `{}` | Additional pod annotations |
| egress.deploymentAnnotations | object | `{}` | Annotations to add to the Deployment resource. |
| egress.nodeSelector | object | `{"kubernetes.io/os":"linux"}` | Node Selector for the Egress pods |
| egress.tolerations | list | `[]` | Tolerations for the Egress pods |
| egress.podDisruptionBudget.enabled | bool | `false` | Whether to create a pod disruption budget |
| egress.podDisruptionBudget.maxUnavailable | int | `1` | The maximum number of unavailable pods allowed by the budget |
| egress.affinity | object | `{"podAntiAffinity":{"preferredDuringSchedulingIgnoredDuringExecution":[{"podAffinityTerm":{"labelSelector":{"matchExpressions":[{"key":"app.kubernetes.io/name","operator":"In","values":["{{ include \"kuma.name\" . }}"]},{"key":"app.kubernetes.io/instance","operator":"In","values":["{{ .Release.Name }}"]},{"key":"app","operator":"In","values":["kuma-egress"]}]},"topologyKey":"kubernetes.io/hostname"},"weight":100}]}}` | Affinity placement rule for the Kuma Egress pods. This is rendered as a template, so you can reference other helm variables or includes. |
| egress.topologySpreadConstraints | string | `nil` | Topology spread constraints rule for the Kuma Egress pods. This is rendered as a template, so you can use variables to generate match labels. |
| egress.priorityClassName | string | `""` | Priority Class Name of the egress |
| egress.podSecurityContext | object | `{"runAsGroup":5678,"runAsNonRoot":true,"runAsUser":5678}` | Security context at the pod level for egress |
| egress.containerSecurityContext | object | `{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]},"readOnlyRootFilesystem":true}` | Security context at the container level for egress |
| egress.serviceAccountAnnotations | object | `{}` | Annotations to add for Control Plane's Service Account |
| egress.automountServiceAccountToken | bool | `true` | Whether to automountServiceAccountToken for cp. Optionally set to false |
| egress.dns | object | `{"config":{"nameservers":[],"searches":[]},"policy":""}` | DNS configuration for the egress pod. This is equivalent to the [Kubernetes DNS policy](https://kubernetes.io/docs/concepts/services-networking/dns-pod-service/#pod-s-dns-policy). |
| egress.dns.policy | string | `""` | Defines how DNS resolution is configured for that Pod. |
| egress.dns.config | object | `{"nameservers":[],"searches":[]}` | Optional dns configuration, required when policy is 'None' |
| egress.dns.config.nameservers | list | `[]` | A list of IP addresses that will be used as DNS servers for the Pod. There can be at most 3 IP addresses specified. |
| egress.dns.config.searches | list | `[]` | A list of DNS search domains for hostname lookup in the Pod. |
| zoneProxyImage.registry | string | `"registry.k8s.io"` | The pause image registry |
| zoneProxyImage.repository | string | `"pause"` | The pause image repository |
| zoneProxyImage.tag | string | `"3.10@sha256:ee6521f290b2168b6e0935a181d4cff9be1ac3f505666ef0e3c98fae8199917a"` | The pause image tag |
| meshZoneProxyDefaults.ingress.service.type | string | `"LoadBalancer"` | Default Service type for zone ingress. |
| meshZoneProxyDefaults.ingress.service.port | int | `10001` | Default port for zone ingress Service. |
| meshZoneProxyDefaults.ingress.service.targetPort | int | `10001` | Container port the zone ingress listens on. Do not change unless the zone proxy binary is reconfigured. |
| meshZoneProxyDefaults.egress.preStopSleepSeconds | int | `15` | Seconds a terminating zone egress keeps serving before shutdown, applied as a preStop sleep hook. Clients reach a zone egress by pod IP from EDS, so a pod that goes away before the control plane has pushed new endpoints takes requests down with it. The hook has to outlast that propagation, which costs roughly KUMA_STORE_CACHE_EXPIRATION_TIME (default 1s) plus KUMA_XDS_SERVER_DATAPLANE_CONFIGURATION_REFRESH_INTERVAL (default 1s) plus the time to push and ack the update, so raise this if you have raised either interval. Must be lower than terminationGracePeriodSeconds, otherwise the chart fails to render. Set to 0 to drop the hook. |
| meshZoneProxyDefaults.egress.service.type | string | `"ClusterIP"` | Default Service type for zone egress. |
| meshZoneProxyDefaults.egress.service.port | int | `10002` | Default port for zone egress Service. |
| meshZoneProxyDefaults.egress.service.targetPort | int | `10002` | Container port the zone egress listens on. Do not change unless the zone proxy binary is reconfigured. |
| meshes[0].name | string | `"default"` | The mesh must already exist or be created separately; this Helm chart will not create it. |
| meshes[0].ingress.enabled | bool | `false` | Deploy a zone ingress for this mesh. |
| meshes[0].ingress.image | object | `{}` | Per-mesh override for the pause container image. Falls back to .Values.zoneProxyImage when unset. Partial overrides inherit the remaining registry/repository/tag fields from the chart-level default. |
| meshes[0].ingress.service.name | string | `""` | Override the auto-generated Service name (max 63 chars). Auto-generated: <name>-<mesh>-ingress (where <name> is the chart name or nameOverride) |
| meshes[0].ingress.service.type | string | `nil` | Per-mesh override for Service type. Falls back to meshZoneProxyDefaults.ingress.service.type when unset. |
| meshes[0].ingress.service.port | int | `nil` | Per-mesh override for Service port. Falls back to meshZoneProxyDefaults.ingress.service.port when unset. |
| meshes[0].ingress.service.spec | object | `{}` | Additional Service spec fields (externalIPs, loadBalancerIP, loadBalancerSourceRanges, etc.). Merged directly into the Service spec. |
| meshes[0].ingress.service.annotations | object | `{}` | Annotations to add to the Service resource. |
| meshes[0].ingress.service.labels | object | `{}` | Labels to add to the Service resource. |
| meshes[0].ingress.deployment | object | `{"annotations":{},"labels":{},"podSpec":{},"replicas":1}` | Deployment-level settings. |
| meshes[0].ingress.deployment.replicas | int | `1` | Number of replicas. Ignored when hpa.enabled is true. |
| meshes[0].ingress.deployment.annotations | object | `{}` | Annotations to add to the Deployment resource. |
| meshes[0].ingress.deployment.labels | object | `{}` | Labels to add to the Deployment resource. |
| meshes[0].ingress.deployment.podSpec | object | `{}` | Subset of Kubernetes PodSpec fields applied to the pod template (nodeSelector, tolerations, affinity, topologySpreadConstraints,  priorityClassName, securityContext, containerSecurityContext, resources,  containerResources). |
| meshes[0].ingress.hpa | object | `{"enabled":false,"maxReplicas":5,"minReplicas":2,"targetCPUUtilizationPercentage":80}` | Horizontal Pod Autoscaler settings. |
| meshes[0].ingress.pdb | object | `{"enabled":false,"maxUnavailable":1}` | Pod Disruption Budget settings. |
| meshes[0].egress.enabled | bool | `false` | Deploy a zone egress for this mesh. |
| meshes[0].egress.preStopSleepSeconds | int | `nil` | Per-mesh override for the preStop sleep duration. Falls back to meshZoneProxyDefaults.egress.preStopSleepSeconds when unset. Set to 0 to drop the hook. |
| meshes[0].egress.image | object | `{}` | Per-mesh override for the pause container image. Falls back to .Values.zoneProxyImage when unset. Partial overrides inherit the remaining registry/repository/tag fields from the chart-level default. |
| meshes[0].egress.service.name | string | `""` | Override the auto-generated Service name (max 63 chars). Auto-generated: <name>-<mesh>-egress (where <name> is the chart name or nameOverride) |
| meshes[0].egress.service.type | string | `nil` | Per-mesh override for Service type. Falls back to meshZoneProxyDefaults.egress.service.type when unset. |
| meshes[0].egress.service.port | int | `nil` | Per-mesh override for Service port. Falls back to meshZoneProxyDefaults.egress.service.port when unset. |
| meshes[0].egress.service.spec | object | `{}` | Additional Service spec fields (externalIPs, loadBalancerIP, loadBalancerSourceRanges, etc.). Merged directly into the Service spec. |
| meshes[0].egress.service.annotations | object | `{}` | Annotations to add to the Service resource. |
| meshes[0].egress.service.labels | object | `{}` | Labels to add to the Service resource. |
| meshes[0].egress.deployment | object | `{"annotations":{},"labels":{},"podSpec":{},"replicas":1}` | Deployment-level settings. |
| meshes[0].egress.deployment.replicas | int | `1` | Number of replicas. Ignored when hpa.enabled is true. |
| meshes[0].egress.deployment.annotations | object | `{}` | Annotations to add to the Deployment resource. |
| meshes[0].egress.deployment.labels | object | `{}` | Labels to add to the Deployment resource. |
| meshes[0].egress.deployment.podSpec | object | `{}` | Subset of Kubernetes PodSpec fields applied to the pod template (nodeSelector, tolerations, affinity, topologySpreadConstraints,  priorityClassName, securityContext, containerSecurityContext, resources,  containerResources). |
| meshes[0].egress.hpa.enabled | bool | `false` |  |
| meshes[0].egress.hpa.minReplicas | int | `2` |  |
| meshes[0].egress.hpa.maxReplicas | int | `5` |  |
| meshes[0].egress.hpa.targetCPUUtilizationPercentage | int | `80` |  |
| meshes[0].egress.pdb.enabled | bool | `false` |  |
| meshes[0].egress.pdb.maxUnavailable | int | `1` |  |
| kumactl.image.repository | string | `"kumactl"` | The kumactl image repository |
| kumactl.image.tag | string | `nil` | The kumactl image tag. When not specified, the value is copied from global.tag |
| kubectl.image.registry | string | `"registry.k8s.io"` | The kubectl image registry |
| kubectl.image.repository | string | `"kubectl"` | The kubectl image repository |
| kubectl.image.tag | string | `"v1.36.1@sha256:d08f476d04d0e30f426f06bc6ff6c38913aaa4591943046b77e2f74a72d3611c"` | The kubectl image tag |
| hooks.nodeSelector | object | `{"kubernetes.io/os":"linux"}` | Node selector for the HELM hooks |
| hooks.tolerations | list | `[]` | Tolerations for the HELM hooks |
| hooks.annotations | object | `{}` | Extra annotations to add to hook Job resources. Useful for tools like ArgoCD that need to control job lifecycle (e.g. argocd.argoproj.io/hook-delete-policy). |
| hooks.ttlSecondsAfterFinished | int | `0` | TTL in seconds for hook Jobs after they finish. Set to null to disable automatic TTL-based deletion (recommended when using ArgoCD, which needs to read job status before deletion). |
| hooks.podSecurityContext | object | `{"runAsNonRoot":true}` | Security context at the pod level for crd/webhook/ns |
| hooks.containerSecurityContext | object | `{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]},"readOnlyRootFilesystem":true}` | Security context at the container level for crd/webhook/ns |
| hooks.ebpfCleanup | object | `{"containerSecurityContext":{"readOnlyRootFilesystem":false},"podSecurityContext":{"runAsNonRoot":false}}` | ebpf-cleanup hook needs write access to the root filesystem to clean ebpf programs Changing below values will potentially break ebpf cleanup completely, so be cautious when doing so. |
| hooks.ebpfCleanup.podSecurityContext | object | `{"runAsNonRoot":false}` | Security context at the pod level for crd/webhook/cleanup-ebpf |
| hooks.ebpfCleanup.containerSecurityContext | object | `{"readOnlyRootFilesystem":false}` | Security context at the container level for crd/webhook/cleanup-ebpf |
| transparentProxy.configMap.enabled | bool | `false` | If true, enables the use of a ConfigMap to manage transparent proxy configuration instead of directly configuring it within the Kuma system |
| transparentProxy.configMap.name | string | `"kuma-transparent-proxy-config"` | The name of the ConfigMap used to store the transparent proxy configuration |
| transparentProxy.configMap.config.kumaDPUser | string | `"5678"` | The username or UID of the user that will run kuma-dp. If not provided, the system will use the default UID ("5678") or the default username ("kuma-dp") |
| transparentProxy.configMap.config.ipFamilyMode | string | `"dualstack"` | The IP family mode used for configuring traffic redirection in the transparent proxy Supports "dualstack" (for both IPv4 and IPv6) and "ipv4" modes |
| transparentProxy.configMap.config.redirect.dns.enabled | bool | `true` | Enables DNS redirection in the transparent proxy |
| transparentProxy.configMap.config.redirect.dns.captureAll | bool | `true` | Redirect all DNS queries |
| transparentProxy.configMap.config.redirect.dns.port | int | `15053` | The port on which the DNS server listens |
| transparentProxy.configMap.config.redirect.dns.resolvConfigPath | string | `"/etc/resolv.conf"` | Path to the system's resolv.conf file |
| transparentProxy.configMap.config.redirect.dns.skipConntrackZoneSplit | bool | `false` | Disables conntrack zone splitting, which can prevent potential DNS issues |
| transparentProxy.configMap.config.redirect.inbound.enabled | bool | `true` | Enables inbound traffic redirection |
| transparentProxy.configMap.config.redirect.inbound.port | int | `15006` | Port used for redirecting inbound traffic |
| transparentProxy.configMap.config.redirect.inbound.excludePorts | list | `[]` | List of ports to exclude from inbound traffic redirection |
| transparentProxy.configMap.config.redirect.inbound.excludePortsForIPs | list | `[]` | List of IP addresses to exclude from inbound traffic redirection for specific ports |
| transparentProxy.configMap.config.redirect.inbound.excludePortsForUIDs | list | `[]` | List of UIDs to exclude from inbound traffic redirection for specific ports |
| transparentProxy.configMap.config.redirect.inbound.includePorts | list | `[]` | List of ports to include in inbound traffic redirection |
| transparentProxy.configMap.config.redirect.inbound.insertRedirectInsteadOfAppend | bool | `false` | Inserts the redirection rule at the beginning of the chain instead of appending it |
| transparentProxy.configMap.config.redirect.outbound.enabled | bool | `true` | Enables outbound traffic redirection |
| transparentProxy.configMap.config.redirect.outbound.port | int | `15001` | Port used for redirecting outbound traffic |
| transparentProxy.configMap.config.redirect.outbound.excludePorts | list | `[]` | List of ports to exclude from outbound traffic redirection |
| transparentProxy.configMap.config.redirect.outbound.excludePortsForIPs | list | `[]` | List of IP addresses to exclude from outbound traffic redirection for specific ports |
| transparentProxy.configMap.config.redirect.outbound.excludePortsForUIDs | list | `[]` | List of UIDs to exclude from outbound traffic redirection for specific ports |
| transparentProxy.configMap.config.redirect.outbound.includePorts | list | `[]` | List of ports to include in outbound traffic redirection |
| transparentProxy.configMap.config.redirect.outbound.insertRedirectInsteadOfAppend | bool | `false` | Inserts the redirection rule at the beginning of the chain instead of appending it |
| transparentProxy.configMap.config.redirect.vnet.networks | list | `[]` | Specifies virtual networks using the format interfaceName:CIDR Allows matching traffic on specific network interfaces Examples: - "docker0:172.17.0.0/16" - "br+:172.18.0.0/16" (matches any interface starting with "br") - "iface:::1/64" (for IPv6) |
| transparentProxy.configMap.config.ebpf.enabled | bool | `false` | Enables eBPF support for handling traffic redirection in the transparent proxy |
| transparentProxy.configMap.config.ebpf.bpffsPath | string | `"/run/kuma/bpf"` | The path of the BPF filesystem |
| transparentProxy.configMap.config.ebpf.cgroupPath | string | `"/sys/fs/cgroup"` | The path of cgroup2 |
| transparentProxy.configMap.config.ebpf.instanceIPEnvVarName | string | `""` | The name of the environment variable containing the IP address of the instance (pod/vm) where transparent proxy will be installed |
| transparentProxy.configMap.config.ebpf.programsSourcePath | string | `"/tmp/kuma-ebpf"` | Path where compiled eBPF programs and other necessary files for eBPF mode can be found |
| transparentProxy.configMap.config.ebpf.tcAttachIface | string | `""` | The network interface for TC eBPF programs to bind to. If not provided, it will be automatically determined |
| transparentProxy.configMap.config.retry.maxRetries | int | `4` | The maximum number of retry attempts for operations |
| transparentProxy.configMap.config.retry.sleepBetweenRetries | string | `"2s"` | The time duration to wait between retry attempts |
| transparentProxy.configMap.config.iptablesExecutables.iptables | string | `""` | Custom path for the iptables executable (IPv4) |
| transparentProxy.configMap.config.iptablesExecutables.iptables-save | string | `""` | Custom path for the iptables-save executable (IPv4) |
| transparentProxy.configMap.config.iptablesExecutables.iptables-restore | string | `""` | Custom path for the iptables-restore executable (IPv4) |
| transparentProxy.configMap.config.iptablesExecutables.ip6tables | string | `""` | Custom path for the ip6tables executable (IPv6) |
| transparentProxy.configMap.config.iptablesExecutables.ip6tables-save | string | `""` | Custom path for the ip6tables-save executable (IPv6) |
| transparentProxy.configMap.config.iptablesExecutables.ip6tables-restore | string | `""` | Custom path for the ip6tables-restore executable (IPv6) |
| transparentProxy.configMap.config.log.enabled | bool | `false` | Enables logging of iptables rules for diagnostics and monitoring |
| transparentProxy.configMap.config.comments.disabled | bool | `false` | Disables comments in the generated iptables rules |
| transparentProxy.configMap.config.wait | int | `5` | Time in seconds to wait for acquiring the xtables lock before failing Value 0 means wait indefinitely |
| transparentProxy.configMap.config.waitInterval | int | `0` | Time interval between retries to acquire the xtables lock in seconds |
| transparentProxy.configMap.config.dropInvalidPackets | bool | `false` | Drops invalid packets to avoid connection resets in high-throughput scenarios |
| transparentProxy.configMap.config.storeFirewalld | bool | `false` | Enables firewalld support to store iptables rules |
| transparentProxy.configMap.config.verbose | bool | `false` | Enables verbose mode with longer argument/flag names and additional comments |
| experimental.ebpf.enabled | bool | `false` | If true, ebpf will be used instead of using iptables to install/configure transparent proxy |
| experimental.ebpf.instanceIPEnvVarName | string | `"INSTANCE_IP"` | Name of the environmental variable which will contain the IP address of a pod |
| experimental.ebpf.bpffsPath | string | `"/sys/fs/bpf"` | Path where BPF file system should be mounted |
| experimental.ebpf.cgroupPath | string | `"/sys/fs/cgroup"` | Host's cgroup2 path |
| experimental.ebpf.tcAttachIface | string | `""` | Name of the network interface which TC programs should be attached to, we'll try to automatically determine it if empty |
| experimental.ebpf.programsSourcePath | string | `"/tmp/kuma-ebpf"` | Path where compiled eBPF programs which will be installed can be found |
| experimental.sidecarContainers | bool | `true` | If true, enable native Kubernetes sidecars. This requires at least Kubernetes v1.29 |
| experimental.inboundTagsDisabled | bool | `false` | If true, inbound tags are not generated for dataplanes. Used with label-based MeshService matching. |
| experimental.envoyAdminUnixSocket | bool | `true` | If true, Envoy admin API binds to a Unix domain socket instead of TCP. |
| experimental.deltaXds | bool | `false` | If true, uses Delta xDS (incremental) protocol to deliver changes to sidecars instead of State of the World (SOTW). |
| experimental.exposeZoneProxyMetrics | bool | `false` | If true, the Envoy admin listener on zone proxies also serves /stats/prometheus without mTLS, so Prometheus can scrape Envoy stats off the proxy IP. Only that path is added; the rest of the Admin API still requires mTLS. Useful for scraping ZoneIngress/ZoneEgress, which MeshMetric does not apply to. Note the stats dump lists every upstream cluster name, so effectively every service in the mesh, and Envoy renders it on the main dispatcher thread, so unauthenticated request loops cost CPU on a busy zone ingress. Restrict the admin port with a NetworkPolicy scoped to Prometheus. |
| postgres.port | string | `"5432"` | Postgres port, password should be provided as a secret reference in "controlPlane.secrets" with the Env value "KUMA_STORE_POSTGRES_PASSWORD". Example: controlPlane:   secrets:     - Secret: postgres-postgresql       Key: postgresql-password       Env: KUMA_STORE_POSTGRES_PASSWORD |
| postgres.tls.mode | string | `"disable"` | Mode of TLS connection. Available values are: "disable", "verifyNone", "verifyCa", "verifyFull" |
| postgres.tls.disableSSLSNI | bool | `false` | Whether to disable SNI the postgres `sslsni` option. |
| postgres.tls.caSecretName | string | `nil` | Secret name that contains the ca.crt |
| postgres.tls.secretName | string | `nil` | Secret name that contains the client tls.crt, tls.key |

## Custom Resource Definitions

All Kuma CRDs are loaded via the [`crds`](crds) directory. For more detailed information on CRDs and Helm,
please refer to [the Helm documentation][helm-crd].

## Deleting

As part of [Helm's limitations][helm-crd-limitations], CRDs will not be deleted when the `kuma` chart is deleted and
must be deleted manually. When a CRD is deleted Kubernetes deletes all resources of that kind as well, so this should
be done carefully.

To do this with `kubectl` on *nix platforms, run:

```shell
kubectl get crds | grep kuma.io | tr -s " " | cut -d " " -f1 | xargs kubectl delete crd

# or with jq
kubectl get crds -o json | jq '.items[].metadata.name | select(.|test(".*kuma\\.io"))' | xargs kubectl delete crd
```

## Autoscaling

In production, it is advisable to enable Control Plane autoscaling for High Availability. Autoscaling uses the
`HorizontalPodAutoscaler` resource to add redundancy and scale the CP pods based on CPU utilization, which requires
the [k8s metrics-server][kube-metrics-server] to be running on the cluster.

## Development

The charts are used internally in `kumactl install`, therefore the following rules apply when developing new chat features:
 * all templates that start with `pre-` and `post-` are omitted when processing in `kumactl install`

### Installing Metrics Server for Autoscaling

If running on kind, or on a cluster with a similarly self-signed cert, the metrics server must be configured to allow
insecure kubelet TLS. The make task `kind/deploy/metrics-server` installs this patched version of the server.

[kuma-url]: https://kuma.io/
[kuma-logo]: https://kuma-public-assets.s3.amazonaws.com/kuma-logo-v2.png
[helm-crd]: https://helm.sh/docs/chart_best_practices/custom_resource_definitions/
[helm-crd-limitations]: https://helm.sh/docs/topics/charts/#limitations-on-crds
[kube-metrics-server]: https://github.com/kubernetes-sigs/metrics-server
