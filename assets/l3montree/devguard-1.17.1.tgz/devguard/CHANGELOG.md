# Changelog

All notable changes to the DevGuard Helm chart are documented here.

For API and web frontend changes see the [main DevGuard CHANGELOG](https://github.com/l3montree-dev/devguard/blob/main/CHANGELOG.md).

## [v1.17.1] — 2026-10-27

### Fixed

- The `verify-image-signatures` Kyverno policy (`kyvernoPolicy.enabled`) rejected the v1.17.0 images: `devguard-scanner` v1.17.0 sets the SLSA provenance `runDetails.builder.id` to `https://devguard.org` (previously `devguard.org`), so the `Equals devguard.org` condition failed. The condition now accepts both `devguard.org` and `https://devguard.org`.
- The policy only matched tagged image references (`devguard:*`, `devguard-web:*`, `devguard/postgresql:*`), so images pinned by digest only (`image.digest` renders `repository@sha256:…` without a tag) were never verified. `devguard@*`, `devguard-web@*` and `devguard/postgresql@*` are now matched as well, which means digest-pinned deployments are now subject to the same signature and SLSA provenance checks.
- The DevGuard-built kratos image (`ghcr.io/l3montree-dev/devguard/kratos`, the chart default) was not covered by the policy at all: the existing rule only matches the upstream `oryd/kratos` images. A new `verify-devguard-kratos-image` rule verifies its signature with the DevGuard key, for tagged and digest-pinned references.

---

## [v1.17.0] — 2026-10-26

### Added

- `api.slsa` configures SLSA build provenance signing (`POST /slsa/build-provenance/`): `trustedIssuers` (`SLSA_OIDC_TRUSTED_ISSUERS`, empty accepts every https issuer), `oidcAudience` (`SLSA_OIDC_AUDIENCE`, defaults to the public API URL and must match `devguard_api_url` of the CI components) and `rekorUrl` (`SLSA_REKOR_URL`, empty skips the transparency log upload). Provenance is signed with the existing `api.intoto` EC key (`ec-private-key`), which is now mounted at `/slsa-private-key.pem` and passed as `SLSA_PRIVATE_KEY_PATH`; no new secret is needed.

### Changed

- The manual `Rancher catalog test` workflow now installs DevGuard from the official, pre-installed `partner-charts` ClusterRepo (forcing a refresh of it first) instead of adding its own; a custom ClusterRepo can still be used. See `rancher/e2e/README.md`. No chart templates or values changed.

---

## [v1.16.2] — 2026-10-23

### Added

- `api.riverUI.enabled` (default `false`) deploys [River UI](https://github.com/riverqueue/riverui), a dashboard for the API's background job queue. It is not exposed through an ingress; reach it with `kubectl port-forward service/devguard-riverui-service 8080:8080`. It connects with the `devguard` database user from `db-secret` and is added to the `devguard-postgresql-ingress` NetworkPolicy.
- Chart packages are now signed with OpenPGP: every release ships a `.tgz.prov` provenance file — as a GitHub release asset, next to the package in the GitHub Pages repository, and as a provenance layer in GHCR — and the public key is published at `https://l3montree-dev.github.io/devguard-helm-chart/signing-key.asc`. Verify with `helm pull devguard/devguard --verify --keyring ./signing-key.gpg` (see `DISTRIBUTION.md` → "Chart signing"). Versions released earlier stay unsigned. No chart templates or values changed.

---

## [v1.16.1] — 2026-10-11

### Changed

- Bumped default DevGuard image versions: `devguard` to `v1.16.1` and `devguard-web` to `v1.16.1`

## [v1.16.0] — 2026-10-07

### Changed

- Bumped default DevGuard image versions: `devguard` to `v1.16.0`, `devguard-web` to `v1.16.0`, `devguard-ci-components` to `v1.16.0`, `kratos` to `v26.2.0`, `postgresql` to `16.15`

---

## [v1.15.2] — 2026-10-02
### Fixed

- Not all devguard containers received the POSTGRESQL_SSL_MODE env var when `postgresql.external.sslMode` was set, so Kratos and the API could fail to connect to an external PostgreSQL with SSL enabled. The env var is now passed to all containers that connect to PostgreSQL.

## [v1.15.1] — 2026-10-02

### Changed
- Increased default PostgreSQL resource settings: `sharedBuffers` to `2GB`, `effectiveCacheSize` to `6GB`, `maintenanceWorkMem` to `512MB`.
- `postgresql.config.logMinDurationStatement` (default `2s`) to log slow queries to stderr.

## [v1.15.0] — 2026-10-01

### Added

- `postgresql.enabled` (default `true`) and `postgresql.external` (`host`, `port`, `sslMode`) to run DevGuard against a PostgreSQL you operate yourself. With `postgresql.enabled=false` the bundled StatefulSet, Service, PVC, ConfigMaps, ServiceMonitor, Grafana dashboard and the `devguard-postgresql-ingress` NetworkPolicy are no longer rendered, and the API `POSTGRES_HOST`/`POSTGRES_PORT` envs plus both Kratos DSNs resolve to `postgresql.external`. Rendering fails with a hint if `external.host` is unset. The existing secret contract is unchanged, so `useExistingSecret` / `useExistingKratosDatabaseSecret` work for external databases too. See the external PostgreSQL prerequisites in the [README](README.md#external-postgresql) — the `semver` extension in particular. `external.sslMode` applies to the Kratos connections only; the API always connects with `sslmode=disable`.

- `api.pdfGenerationApi`, passed to the API as `PDF_GENERATION_API`, which was previously hardcoded to `https://dwt-api.dev-l3montree.cloud/pdf`.

### Changed

- Bumped default DevGuard image versions: `devguard` to `v1.15.0`, `devguard-web` to `v1.15.0`, `devguard-ci-components` to `v1.15.0`, `kratos` to `v26.2.0`, `postgresql` to `16.15`
- **`PDF_GENERATION_API` now defaults to empty**, so a self-hosted instance no longer sends report data to an L3montree-operated endpoint unless configured to. With it unset, `GET …/sbom.pdf/` and `GET …/vulnerability-report.pdf/` return HTTP 500 — the web frontend still offers the download. To keep the previous behaviour, set `api.pdfGenerationApi: https://dwt-api.dev-l3montree.cloud/pdf`.
- `INSTANCE_DOMAIN` is now derived from `api.ingress.host` / `api.ingress.tls` whenever they are set, regardless of `api.ingress.enabled`, instead of falling back to the in-cluster Service URL when the Ingress is disabled. This makes the instance advertise a reachable URL when the API is published by an `HTTPRoute`, an OpenShift `Route` or a service mesh. Installs that ran with `api.ingress.enabled=false` and a placeholder `api.ingress.host` now advertise that host — set it to the real public URL.

### Fixed

- switched all `additionalEnvs` occurrences to use correct default type of `{}` instead of `[]`. (thanks a lot @skuethe for the fix!)

---

## [v1.14.1] — 2026-09-19

### Changed

- Bumped default DevGuard image versions: `devguard` to `v1.14.2`, `devguard-web` to `v1.14.1`.

---

## [v1.14.0] — 2026-09-17

### Changed

- Bumped default DevGuard image versions: `devguard` to `v1.14.0`, `devguard-web` to `v1.14.0`, `devguard-ci-components` to `v1.14.0`, `kratos` to `v26.2.0`, `postgresql` to `16.15`
---

## [v1.13.12] — 2026-09-16

### Added

- `api.tracing.spanMetrics.enabled` (default `true`) to turn the OTel Collector sidecar's `spanmetrics` connector on or off independently of tracing itself. The connector aggregates spans in memory and shares the traces pipeline, so under load or memory pressure (`memory_limiter`) it can apply backpressure that also stalls the OTLP export. Setting it to `false` keeps the sidecar forwarding spans to `api.tracing.otlpEndpoint` and drops the Prometheus `/metrics` exporter, the `span-metrics` container/service port (8889), its NetworkPolicy ingress rule and the ServiceMonitor endpoint. With `spanMetrics.enabled=false` and no `api.tracing.otlpEndpoint`, the template now fails with a hint instead of rendering a collector config with no trace exporter.

---

## [v1.13.11] — 2026-09-15

### Fixed

- The `kratos-cleanup` CronJob could no longer reach PostgreSQL after the label change in v1.13.9. The `devguard-postgresql-ingress` NetworkPolicy only allowed ingress from pods labelled `app.kubernetes.io/name: kratos`, so cleanup pods were silently dropped and failed with `Unable to ping database, retrying` / `dial error: timeout`. The policy now also permits `app.kubernetes.io/name: kratos-cleanup`.

---

## [v1.13.10] — 2026-09-15

### Changed

- Missing chart version update

---

## [v1.13.9] — 2026-09-15

### Fixed

- The `kratos-cleanup` CronJob now uses `app.kubernetes.io/name: kratos-cleanup` on the CronJob and its pod template instead of `kratos`, so cleanup pods are no longer selected by resources targeting the Kratos deployment (e.g. the Kratos service).

---

## [v1.13.8] — 2026-09-14

### Changed

- Bumped default DevGuard image versions: `devguard` to `v1.13.7`, `devguard-web` to `v1.13.2`, `devguard-ci-components` to `v1.13.2`, `kratos` to `v26.2.0`, `postgresql` to `16.15`

---

## [v1.13.7] — 2026-09-11

### Changed

- Bumped default DevGuard image versions: `devguard` / `postgresql` / `kratos` to `v1.13.7`, `devguard-web` to `v1.13.2`, `devguard-ci-components` to `v1.13.2`

---

## [v1.13.6] — 2026-09-08

### Changed

- Bumped default DevGuard image versions: `devguard` / `postgresql` / `kratos` to `v1.13.6`, `devguard-web` to `v1.13.2`, `devguard-ci-components` to `v1.13.1`

---

## [v1.13.5] — 2026-09-08

### Changed
- Release workflow now runs the DevGuard scanner and attaches an SBOM as a release asset, extracting SBOM URLs (including the upstream chart version) as part of the schema generation step. No chart templates or values changed.

---

## [v1.13.4] — 2026-08-31

### Fixed
- Restored the `api.dependencyProxyCache.maxSizeMb` default value, which was missing from `schema/schema.ts` and therefore dropped from every generated `values.yaml` again, causing `helm upgrade` to fail with a nil pointer error on `.Values.api.dependencyProxyCache.maxSizeMb`.

---

## [v1.13.3] — 2026-08-31

### Changed
- Default Kratos image switched from `oryd/kratos:v26.2.0-distroless` to L3montree's own build, `ghcr.io/l3montree-dev/devguard/kratos:v1.13.1`.

---

## [v1.13.2] — 2026-08-24

### Fixed
- Missing chart version bump in v1.13.1 release, which caused the chart to be packaged with the same version as v1.13.0 and fail to upload to Artifact Hub.

## [v1.13.1] — 2026-08-24

### Fixed

- Restored the `api.dependencyProxyCache.maxSizeMb` default value in `values.yaml`, which was missing after the v1.13.0 release.

---

## [v1.13.0] — 2026-08-24

### Added

- New `api.dependencyProxyCache.maxSizeMb` value (default `4096`), passed to the `devguard` deployment as `DEPENDENCY_PROXY_CACHE_MAX_SIZE_MB`, to configure the maximum size of the dependency proxy cache.
- New `web.issueTrackerUrl` value, passed to the `devguard-web` deployment as `ISSUE_TRACKER_URL`, to configure a link to the project's issue tracker.

---

## [v1.12.4] — 2026-08-19

### Fixed

- Corrected the PostgreSQL Grafana dashboard: removed invalid stray commas in several PromQL queries (e.g. `pg_static{, instance="$instance"}`) that broke metric selectors, and dropped the broken `$namespace` template variable filter from the `instance`/`datname` variable queries.

---

## [v1.12.3] — 2026-08-10

### Changed

- Bumped default DevGuard image versions: `devguard` / `postgresql` to `v1.12.4`, `devguard-web` to `v1.12.3`, `devguard-ci-components` to `v1.12.0`

---

## [v1.12.2] — 2026-08-10

### Changed

- Bumped default DevGuard image versions: `devguard` / `postgresql` to `v1.12.4`, `devguard-web` to `v1.12.2`, `devguard-ci-components` to `v1.12.0`

---

## [v1.12.1] — 2026-08-05

### Changed

- Bumped default DevGuard image versions: `devguard` / `postgresql` to `v1.12.3`, `devguard-web` to `v1.12.2`, `devguard-ci-components` to `v1.12.0`

---

## [v1.12.0] — 2026-08-02

### Changed

- Bumped default DevGuard image versions to v1.12.0, in line with the [versioning policy](https://github.com/l3montree-dev/devguard/blob/main/VERSIONING.md) that keeps the chart's minor version in sync with `devguard` and `devguard-web`

---

## [v1.11.0] — 2026-07-24

### Added

- Artifact Hub support: `artifacthub.io/category: security` annotation in `Chart.yaml` and a new `artifacthub-repo.yml` repository metadata file, enabling repository verification and indexing on Artifact Hub.
- The otel-collector sidecar now runs a `memory_limiter` processor (first in every pipeline) so it applies backpressure and refuses new data before hitting its Kubernetes memory limit, instead of risking an OOM kill. Limits are derived automatically from `api.tracing.spanMetrics.resources.limits.memory` (hard limit ~80%, spike limit ~20% of that) via the new `devguard.otelMemLimitMib` helper, and the same value now sets `GOMEMLIMIT` on the collector container.

### Changed

- Bumped the default otel-collector sidecar memory resources: limits `256Mi` → `768Mi`, requests `64Mi` → `256Mi`, giving the new memory limiter headroom to operate.
- Fixed the Helm release GitHub Actions workflow to pass `--version` explicitly to `helm package`, so packaged charts on `main` are versioned correctly.

---

## [v1.10.2] — 2026-07-20

### Fixed

- **In-Toto signing key: `helm upgrade` no longer fails with a Helm ownership error.** When the `ec-private-key` secret had been created manually (as the deploy-with-Helm guide instructed), the upgrade aborted with `invalid ownership metadata … missing key "app.kubernetes.io/managed-by"` because the chart tried to adopt a secret it did not create. The chart now only generates its own secret when no existing one is named, and otherwise just references yours — it never adopts a foreign secret.

### Changed

- Bumped default image versions: `devguard` / `postgresql` to `v1.10.3`, `devguard-web` to `v1.10.1`.
- **In-Toto key configuration is no longer self-contradictory.** The `api.intoto.generate` boolean is removed and `api.intoto.existingPrivateKeySecretName` now drives both modes on its own:
  - **Empty (new default):** the chart generates and manages the key in a secret named `ec-private-key`, preserving it across upgrades.
  - **Set to a secret name:** the chart only references that secret (data key `privateKey`) and generates nothing — also the way to run under ArgoCD, where the Helm `lookup` function is unavailable.

### Migration

- **If you created the `ec-private-key` secret yourself** (per the deploy-with-Helm guide), set `api.intoto.existingPrivateKeySecretName: ec-private-key` so the chart references it instead of trying to adopt it. If your values file already carried that key from the old default, the fix is automatic — the removed `api.intoto.generate` value is simply ignored.
- **If you relied on the chart generating the key**, leave `api.intoto.existingPrivateKeySecretName` empty; generation and cross-upgrade preservation are unchanged.

---

## [v1.10.1] — 2026-07-20

### Changed

- CI release workflows (GitHub Actions and GitLab CI) no longer auto-rewrite `Chart.yaml`'s `version` / `appVersion` at release time; the chart version is now expected to be committed ahead of tagging
- Removed the GitLab CI `schema-check` job that validated `values.yaml` / `questions.yaml` against `schema/schema.ts`

---

## [v1.10.0] — 2026-07-20

### Changed

- Bumped default DevGuard image versions to v1.10.0, in line with the [versioning policy](https://github.com/l3montree-dev/devguard/blob/main/VERSIONING.md) that keeps the chart's minor version in sync with `devguard` and `devguard-web`

---

## [v1.9.1] — 2026-07-17

### Added

- `api.ingress.tls` / `web.ingress.tls` now also accept a **boolean**. Set it to `true` to serve the ingress over TLS for the single configured host; the certificate is read from `api.ingress.tlsSecretName` / `web.ingress.tlsSecretName` (new values, defaulting to `devguard-api-tls` / `devguard-web-tls` when empty). The old list shape (`tls: [{hosts, secretName}]`) is still fully supported as a fallback.
- `api.ingress.host` / `web.ingress.host` — single-host **scalars** the Rancher install form can populate (the form cannot write list entries like `hosts[0].host`). Each serves one host at path `/` (pathType `Prefix`). The old `api.ingress.hosts` / `web.ingress.hosts` list is still fully supported as a fallback for multi-host / custom-path setups.

### Changed

- The single-host `host` scalar and boolean `tls` are now the documented default in `values.yaml`. **These changes are backwards compatible:** existing values files using the `hosts` and `tls` list shapes continue to render unchanged — no migration required.

### Deprecated

- The list shapes `api.ingress.hosts` / `web.ingress.hosts` (`[{host, paths}]`) and `api.ingress.tls` / `web.ingress.tls` (`[{hosts, secretName}]`) are **deprecated and will be removed in the next major version.** Helm prints a deprecation warning on install/upgrade when they are detected. Migrate to the single-host `host` scalar and the boolean `tls` + `tlsSecretName`. If you rely on multiple hosts or a custom path prefix, please open a ticket: https://github.com/l3montree-dev/devguard-helm-chart/issues

---

## [v1.9.0] — 2026-07-14

### Added

- Support for specifying additional environment variables for all services (DevGuard, DevGuard web, Kratos, PostgreSQL) (thanks to [@skuethe](https://github.com/skuethe))
- Support for using existing secrets without relying on the Helm `lookup` function, for the DB, Kratos DB, Kratos, encryption, and pprof secrets (thanks to [@skuethe](https://github.com/skuethe))

### Changed

- Bumped default Kratos image version to v26.2.0
- Extended access control documentation for database secrets (thanks to [@skuethe](https://github.com/skuethe))

### Fixed

- Corrected YAML indentation on secret templates (thanks to [@skuethe](https://github.com/skuethe))

---

## [v1.8.0] — 2026-07-06

First release under the shared [versioning policy](https://github.com/l3montree-dev/devguard/blob/main/versioning.md): major/minor versions are now synchronized across devguard, devguard-web, the Helm chart, and CI components.

### Added

- Chart metadata: maintainers, keywords, icon, and source links (`Chart.yaml`)
- Configurable Grafana dashboard sidecar label (`observability.grafanaDashboard.labelName` / `labelValue`)

### Changed

- Improved GitHub Actions release workflow to use the job token for release creation
- Minor GitLab CI pipeline cleanup

---

## [v1.7.0] — 2026-06-19

### Added

- Configurable instance admin public key via `instanceAdmin.publicKey` value

### Changed

- Bumped default DevGuard image versions to v1.7.0
- Added GitLab mirror workflow

---

## [v1.6.2] — 2026-06-17

### Changed

- Added `PROFILE` environment variable to the API deployment

---

## [v1.6.1] — 2026-06-16

### Changed

- Bumped default DevGuard image versions to v1.6.1

---

## [v1.6.0] — 2026-06-16

### Added

- App-side encryption `initContainer` and automatic secret generation for the encryption key

### Changed

- Bumped default DevGuard image versions to v1.6.0

---

## [v1.5.1] — 2026-05-29

### Changed

- Bumped default DevGuard image versions to v1.5.1

---

## [v1.5.0] — 2026-05-28

### Changed

- Bumped default DevGuard image versions to v1.5.0

---

## [v1.4.0] — 2026-05-21

### Changed

- Bumped default DevGuard image versions to v1.4.2

---

## [v1.3.5] — 2026-05-08

### Added

- Resource requests/limits are now fully configurable per component
- Kratos session cleanup CronJob
- `chown` init container for root-mounted PostgreSQL volumes

### Changed

- PostgreSQL security contexts exposed as configurable values
- Default CPA behaviour applied to the PostgreSQL init container

---

## [v1.3.4] — 2026-04-28

### Changed

- Bumped default DevGuard image versions to v1.3.1

---

## [v1.3.3] — 2026-04-28

### Fixed

- Removed default case for `registrationEnabled` that caused unexpected behaviour

---

## [v1.3.2] — 2026-04-28

### Fixed

- PostgreSQL `run` directory now uses `emptyDir` instead of a host path

---

## [v1.3.1] — 2026-04-28

### Changed

- Bumped default image tags

---

## [v1.3.0] — 2026-04-28

### Changed

- Bumped default DevGuard image versions to v1.3.0

---

## [v1.2.3] — 2026-04-23

### Added

- Web environment variables for script integrity (`SCRIPT_INTEGRITY` / `NEXT_PUBLIC_*`)

### Changed

- Bumped default DevGuard image versions to v1.2.3

---

## [v1.2.2] — 2026-04-22

### Changed

- Bumped default DevGuard image versions to v1.2.2

---

## [v1.2.1] — 2026-04-14

### Changed

- Updated default values; bumped API version to v1.2.1

---

## [v1.2.0] — 2026-04-14

### Added

- Support for pinning images by digest (`image.digest`)
- Configurable `DEVGUARD_API_URL` in the deployment and values

### Changed

- Bumped default DevGuard image versions to v1.2.0

---

## [v1.1.6] — 2026-03-20

### Added

- Compliance folder (`.compliance/`)
- PostgreSQL config mounted at `/etc`
- Grafana dashboard included in chart
- ServiceMonitor labels so Prometheus auto-discovers services

### Changed

- Kratos jsonnet mapper falls back to GitHub login

---

## [v1.1.5] — 2026-03-17

### Fixed

- Removed `hook-delete-policy` that prevented clean upgrades

---

## [v1.1.4] — 2026-03-17

### Added

- Helm hook-based OPA/Kyverno policy enforcement

---

## [v1.1.3] — 2026-03-17

### Fixed

- Kyverno policy: only verify signing attestations, not build provenance for PostgreSQL image

---

## [v1.1.2] — 2026-03-17

### Added

- `mutateDigest` option (conditional)

---

## [v1.1.1] — 2026-03-17

### Changed

- Kyverno policies disabled by default

---

## [v1.1.0] — 2026-03-17

### Added

- Kyverno policy verifying build provenance for OCI images
- Connector endpoint added to ServiceMonitor
- OpenTelemetry tracing support (basic auth, span metrics sidecar)
- Prometheus `ServiceMonitor` resource

### Changed

- Bumped default DevGuard image versions to v1.1.0

---

## [v1.0.1] — 2026-03-02

### Changed

- Bumped default DevGuard image versions to v1.0.1

---

## [v1.0.0] — 2026-02-20

Initial stable release of the DevGuard Helm chart.

### Added

- Deployments for `devguard` (API), `devguard-web` (frontend), `devguard-scanner`, and bundled PostgreSQL
- Configurable ingress, TLS, resource limits, and replica counts
- Kratos identity server integration with configurable jsonnet mappers
- Secret management for database credentials and integration tokens
