# Helm Chart for the F5 Container Ingress Services

This chart simplifies repeatable, versioned deployment of the [Container Ingress Services](https://clouddocs.f5.com/containers/latest/).

### Prerequisites
- Refer to [CIS Prerequisites](https://clouddocs.f5.com/containers/latest/userguide/cis-helm.html#prerequisites) to install Container Ingress Services on Kubernetes or Openshift
- [Helm 3](https://helm.sh/docs/intro/) should be installed.


## Installing CIS Using Helm Charts

This is the simplest way to install the CIS on OpenShift/Kubernetes cluster. Helm is a package manager for Kubernetes. Helm is Kubernetes version of yum or apt. Helm deploys something called charts, which you can think of as a packaged application. It is a collection of all your versioned, pre-configured application resources which can be deployed as one unit. This chart creates a Deployment for one Pod containing the [k8s-bigip-ctlr](https://clouddocs.f5.com/containers/latest/), it's supporting RBAC, Service Account and Custom Resources Definition installations.

## Installing the Chart

- (Optional) Add BIG-IP credentials as K8S secrets.

For Kubernetes, use the following command:

```kubectl create secret generic f5-bigip-ctlr-login -n kube-system --from-literal=username=admin --from-literal=password=<password>```
    
For OpenShift, use the following command:

```oc create secret generic f5-bigip-ctlr-login -n kube-system --from-literal=username=admin --from-literal=password=<password>```
    
- Add the CIS chart repository in Helm using following command:

```helm repo add f5-stable https://f5networks.github.io/charts/stable```
    
- Create values.yaml as shown in [examples](https://github.com/F5Networks/charts/tree/master/example_values/f5-bigip-ctlr):

- Install the Helm chart if BIGIP credential secrets created manually using the following command:
  
```helm install -f values.yaml <new-chart-name> f5-stable/f5-bigip-ctlr```

- Install the Helm chart with skip crds if BIGIP credential secrets created manually (without custom resource definitions installations)

```helm install --skip-crds -f values.yaml <new-chart-name> f5-stable/f5-bigip-ctlr```

- If you want to create the BIGIP credential secret with helm charts use the following command:

```helm install --set bigip_secret.create="true" --set bigip_secret.username=$BIGIP_USERNAME --set bigip_secret.password=$BIGIP_PASSWORD -f values.yaml <new-chart-name> f5-stable/f5-bigip-ctlr```
    
## Chart parameters:

Parameter | Required | Description | Default    
----------|-------------|-------------|--------
bigip_login_secret | Optional |  Secret that contains BIG-IP login credentials | f5-bigip-ctlr-login
args.bigip_url | Required | The management IP for your BIG-IP device | **Required**, no default
args.bigip_partition | Required | BIG-IP partition the CIS Controller will manage | f5-bigip-ctlr
args.namespaces | Optional | List of Kubernetes namespaces which CIS will monitor | empty
bigip_secret.create | Optional | Create kubernetes secret using username and password | false
bigip_secret.username | Optional | bigip username to create the kubernetes secret | empty
bigip_secret.password | Optional | bigip password to create the kubernetes secret | empty
rbac.create | Optional | Create ClusterRole and ClusterRoleBinding | true
rbac.namespaced | Optional | Enable namespaced RBAC: per-namespace Roles plus a minimal cluster-scope Role (nodes, namespaces, ingressclasses) | false
serviceAccount.name | Optional | name of the ServiceAccount for CIS controller | f5-bigip-ctlr-serviceaccount
serviceAccount.create | Optional | Create service account for the CIS controller | true
namespace | Optional | name of namespace CIS will use to create deployment and other resources | kube-system
image.user | Optional | CIS Controller image repository username | f5networks
image.repo | Optional | CIS Controller image repository name | k8s-bigip-ctlr
image.pullPolicy | Optional | CIS Controller image pull policy | Always
image.pullSecrets | Optional | List of secrets of container registry to pull image | empty
version | Optional | CIS Controller image tag | latest
nodeSelector | Optional | dictionary of Node selector labels | empty
tolerations | Optional | Array of labels | empty
limits_cpu | Optional | CPU limits for the pod | 100m
limits_memory | Optional | Memory limits for the pod | 512Mi
requests_cpu | Optional | CPU request for the pod | 100m
requests_memory | Optional | Memory request for the pod | 512Mi
affinity | Optional | Dictionary of affinity | empty
securityContext | Optional | Dictionary of deployment pod securityContext. Set to `none` to disable (useful on OpenShift). See [Disabling securityContext](#disabling-securitycontext) | If not set, defaults to runAsUser=1000, runAsGroup=1000, fsGroup=1000
podSecurityContext | Optional | Dictionary of container-level securityContext for Pod Security Admission and Pod Security Standards | empty
ingressClass.ingressClassName | Optional | Name of ingress class | f5
ingressClass.isDefaultIngressController | Optional | CIS will monitor all the ingresses resource if set true | false
ingressClass.create | Optional | Create ingress class | true

Note: bigip_login_secret and bigip_secret are mutually exclusive, if both are defined in values.yaml file bigip_secret will be given priority.


See the CIS documentation for a full list of args supported for CIS [CIS Configuration Options](https://clouddocs.f5.com/containers/latest/userguide/config-parameters.html)

> **Note:** Helm value names cannot include the character `-` which is commonly used in the names of parameters passed to the controller. To accomodate Helm, the parameter names in `values.yaml` use `_` and then replace them with `-` when rendering.
> e.g. `args.bigip_url` is rendered as `bigip-url` as required by the CIS Controller.


If you have a specific use case for F5 products in the Kubernetes environment that would benefit from a curated chart, please [open an issue](https://github.com/F5Networks/charts/issues) describing your use case and providing example resources.

## Disabling securityContext

By default, the chart applies a pod-level `securityContext` with `runAsUser: 1000`, `runAsGroup: 1000`, and `fsGroup: 1000`. On OpenShift, the Security Context Constraints (SCC) automatically manage these values, so you may need to disable the chart's `securityContext` to avoid conflicts.

To disable `securityContext`, use any of the following methods:

**In values.yaml:**
```yaml
securityContext: none
```

**Via Helm CLI:**
```shell
helm install <release-name> f5-stable/f5-bigip-ctlr --set securityContext=none -f values.yaml
```

**Via OpenShift Operator CR:**
```yaml
apiVersion: cis.f5.com/v1
kind: F5BigIpCtlr
metadata:
  name: f5bigipctlr-sample
spec:
  securityContext: none
  # ... other spec fields
```

Accepted disable values: `none`, `false`, `no`, `disable`, or an empty map `{}`.

To customize specific fields:
```yaml
securityContext:
  runAsUser: 2000
  runAsGroup: 3000
  fsGroup: 4000
```

Any omitted fields will fall back to the default value of `1000`.

## Upgrading CIS with Helm and CRDs

For upgrades that use CIS Custom Resources (for example VirtualServer, TransportServer, Policy, TLSProfile, IngressLink), update CRDs before running `helm upgrade`.

```shell
    export CIS_VERSION=<cis-version>
    # For example
    # export CIS_VERSION=v2.12.0
    # or
    # export CIS_VERSION=2.x-master
    #
    # the latter if using a CIS image with :latest label

    kubectl create -f https://raw.githubusercontent.com/F5Networks/k8s-bigip-ctlr/${CIS_VERSION}/docs/config_examples/customResourceDefinitions/customresourcedefinitions.yml

    # Then upgrade Helm release
    helm upgrade <release-name> f5-stable/f5-bigip-ctlr -f values.yaml
```

Notes:

- The chart does not automatically manage CRD upgrades during `helm upgrade`.
- Helm hook-based CRD auto-upgrade is not currently provided or supported in this chart.
- If you are not using CIS CRDs, CRD update can be skipped.

## Uninstalling Helm Chart
Run the following command to uninstall the chart.
```helm uninstall <new-chart-name>```

Note: When rbac.namespaced=true the chart:
- Skips the default broad ClusterRole/Binding.
- Creates a minimal cluster-scope ClusterRole granting get/list/watch on nodes, namespaces, ingressclasses (and CRDs if ipam enabled).
- Creates a limited Role in the controller namespace (configmaps + secrets only).
- Creates Roles/RoleBindings in each args.namespaces granting required namespace-scoped permissions.
