# cn-istio-ingress

![Version: 6.5.1](https://img.shields.io/badge/Version-6.5.1-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 6.5.1](https://img.shields.io/badge/AppVersion-6.5.1-informational?style=flat-square)

Istio Gateway

**Homepage:** <https://docs.gluu.org/>

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| Mohammad Abudayyeh | <team@gluu.org> | <https://github.com/moabu> |

## Source Code

* <https://github.com/GluuFederation/flex/tree/main/charts/gluu/charts/cn-istio-ingress>

## Requirements

Kubernetes: `>=v1.21.0-0`

