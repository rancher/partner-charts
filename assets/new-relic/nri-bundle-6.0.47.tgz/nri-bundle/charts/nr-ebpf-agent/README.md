<a href="https://opensource.newrelic.com/oss-category/#community-plus"><picture><source media="(prefers-color-scheme: dark)" srcset="https://github.com/newrelic/opensource-website/raw/main/src/images/categories/dark/Community_Plus.png"><source media="(prefers-color-scheme: light)" srcset="https://github.com/newrelic/opensource-website/raw/main/src/images/categories/Community_Plus.png"><img alt="New Relic Open Source community plus project banner." src="https://github.com/newrelic/opensource-website/raw/main/src/images/categories/Community_Plus.png"></picture></a>

# nr-ebpf-agent

A Helm chart to monitor a Kubernetes Cluster using the eBPF agent.

# Helm installation

1. Download and modify the default configuration file [values.yaml](https://github.com/newrelic/helm-charts/blob/master/charts/nr-ebpf-agent/values.yaml#L1-L4). At minimum, you will need populate the `licenseKey` field with a valid New Relic Ingest key and the `cluster` field with the name of the cluster to monitor.

**NOTE: From chart version 0.2.x onwards, please use the latest [values.yaml](https://github.com/newrelic/helm-charts/blob/master/charts/nr-ebpf-agent/values.yaml) bundled with each Helm release. This will ensure compatibility with new features and configuration options.**

Example:
```
licenseKey: "EXAMPLEINGESTLICENSEKEY345878592NRALL"
cluster: "name-of-cluster-to-monitor"
```

2. Install the helm chart, passing the configuration file created above.
```sh
helm repo add newrelic https://helm-charts.newrelic.com
helm upgrade nr-ebpf-agent newrelic/nr-ebpf-agent -f your-custom-values.yaml -n newrelic --create-namespace --install
```

## Version Compatibility

Starting with chart version 1.0.0, version validation is automatically performed to ensure agent compatibility. Chart 1.0.0+ removed OpenTelemetry collector support and requires agent version >= 1.0.0.

**Default Behavior:**
When no custom image tag is specified, the chart uses `Chart.AppVersion` (1.0.0 for chart 1.0.0), which is guaranteed to be compatible.

```yaml
ebpfAgent:
  image:
    tag: ""  # Uses Chart.AppVersion (1.0.0)
```

**Custom Image Tag:**
If you specify a custom image tag, ensure it contains an agent version >= 1.0.0:

```yaml
ebpfAgent:
  image:
    tag: "1.0.0"  # Or any version >= 1.0.0
```

### Troubleshooting Version Validation

If you encounter version validation errors:

1. **Check your image tag:** Ensure `ebpfAgent.image.tag` is set to a version >= 1.0.0
2. **Use default version:** Remove the custom tag to use the chart's default version (recommended)

## Source Code

* <https://github.com/newrelic/>

## Confirm installation
### Watch pods spin up:

```
kubectl get pods -n newrelic --watch
```

### Check the logs of the eBPF agent pod:
```
# The agent container logs detail probe attachment and data collection.
kubectl logs <ebpf-pod-name> -c nr-ebpf-agent -n newrelic
```

### Confirm data ingest to New Relic
You should see data reporting into New Relic within a couple of seconds to the `Metric` and `Span` tables.
```
FROM Metric SELECT * WHERE k8s.cluster.name='<CLUSTER_NAME>'

FROM Span SELECT * WHERE k8s.cluster.name='<CLUSTER_NAME>'
```
The entities view should show OTel services and an "APM-lite" rendition of the data for each entity when clicked on.

## Uninstall

Run the following command.

```
helm uninstall ebpf-agent -n newrelic
```

## Values managed globally

This chart implements the [New Relic's common Helm library](https://github.com/newrelic/helm-charts/tree/master/library/common-library) which
means that it honors a wide range of defaults and globals common to most New Relic Helm charts.

Options that can be defined globally include `affinity`, `nodeSelector`, `tolerations` and others. The full list can be found at
[user's guide of the common library](https://github.com/newrelic/helm-charts/blob/master/library/common-library/README.md).

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | object | `{}` | Sets all pods' affinities. Can be configured also with `global.affinity` |
| allDataFilters.dropNewRelicBundle | boolean | `true` | Drop data from the newrelic namespace and newrelic-bundle services. (RENAMED from `dropDataNewRelic` for clarity. The old name is deprecated but still supported for backward compatibility). |
| allDataFilters.dropNamespaces | list | `["kube-system"]` | List of Kubernetes namespaces for which all data should be dropped by the agent. (RENAMED from `dropDataForNamespaces` for clarity. The old name is deprecated but still supported for backward compatibility). |
| allDataFilters.dropServiceNameRegex | string | `""` | Define a regex to match k8s service names to drop. Example `"kube-dns\|otel-collector\|\\bblah\\b"`. (RENAMED from `dropDataServiceNameRegex` for clarity. The old name is deprecated but still supported for backward compatibility). |
| allDataFilters.keepServiceNameRegex | string | `""` | This config acts as a bypass for the `dropServiceNameRegex` config. Service names that match this regex will not have their data dropped by the `dropServiceNameRegex`. (RENAMED from `allowServiceNameRegex` for clarity. The old name is deprecated but still supported for backward compatibility). |
| allDataFilters.dropApmAgentEnabledEntity | boolean | `false` | Drop all data for applications or entities that have New Relic or OTEL APM agents running. |
| apmDataFilters.dropEapmForApmEnabledEntity | boolean | `true` | Drop eBPF APM data for applications/entities that have NewRelic APM/OTel agents running. |
| apmDataFilters.dropPodLabels | object | `{}` | Pod labels to match for filtering APM data. Empty map means no label-based filtering. (Example: dropPodLabels: `{ "app": "frontend", "env": "production" }`) |
| apmDataFilters.dropEntityName | list | `[]` | List of entity names to drop ebpf APM data.|
| apmDataFilters.keepEntityName | list | `[]` | List of entity names to always keep APM data. By default all entities are kept/enabled. This config bypasses `dropEntityName` filter. |
| apmDataFilters.jvmMetricsReporting | bool | `true` | Enable JVM Metrics Reporting. |
| cluster | string | `""` | Name of the Kubernetes cluster to be monitored. Mandatory. Can be configured with `global.cluster` |
| containerSecurityContext | object | `{}` | Sets all pods' containerSecurityContext. Can be configured also with `global.securityContext.container` |
| customSecretLicenseKey | string | `""` | In case you don't want to have the license key in your values, this allows you to point to which secret key is the license key located. Can be configured also with `global.customSecretLicenseKey` |
| customSecretName | string | `""` | In case you don't want to have the license key in your values, this allows you to point to a user created secret to get the key from there. Can be configured also with `global.customSecretName` |
| logLevel | string | `INFO` | To configure the log level in increasing order of verboseness. OFF, FATAL, ERROR, WARNING, INFO, DEBUG |
| logFilePath | string | `""` | To configure log file path of eBPF Agent. If logging to this path fails, logs will be directed to stdout. |
| dnsConfig | object | `{}` | Sets pod's dnsConfig. Can be configured also with `global.dnsConfig` |
| dropAPMEnabledPods | bool | `false` | Drop data from pods that are monitored by New Relic APM via auto attach. |
| ebpfAgent.affinity | object | `{}` | Sets ebpfAgent pod affinities. Overrides `affinity` and `global.affinity` |
| ebpfAgent.containerSecurityContext | object | `{}` | Sets ebpfAgent pod containerSecurityContext. Overrides `containerSecurityContext` and `global.securityContext.container` |
| ebpfAgent.image.pullPolicy | string | `"IfNotPresent"` | The pull policy is defaulted to IfNotPresent, which skips pulling an image if it already exists. If pullPolicy is defined without a specific value, it is also set to Always. |
| ebpfAgent.image.repository | string | `"docker.io/newrelic/newrelic-ebpf-agent"` | eBPF agent image to be deployed. |
| ebpfAgent.image.tag | string | `"agent-nr-ebpf-agent_0.0.9"` | The tag of the eBPF agent image to be deployed. |
| ebpfAgent.podAnnotations | object | `{}` | Sets ebpfAgent pod Annotations. Overrides `podAnnotations` and `global.podAnnotations` |
| ebpfAgent.podSecurityContext | object | `{}` | Sets ebpfAgent pod podSecurityContext. Overrides `podSecurityContext` and `global.securityContext.pod` |
| ebpfAgent.resources.limits.memory | string | `"2Gi"` | Max memory allocated to the container. |
| ebpfAgent.resources.requests.cpu | string | `"100m"` | Min CPU allocated to the container. |
| ebpfAgent.resources.requests.memory | string | `"250Mi"` | Min memory allocated to the container. |
| ebpfAgent.tolerations | list | `[]` | Sets ebpfAgent pod tolerations. Overrides `tolerations` and `global.tolerations` |
| kubernetesClusterDomain | string | `"cluster.local"` | Kubernetes cluster domain. |
| labels | object | `{}` | Additional labels for chart objects. |
| licenseKey | string | `""` | The license key to use. Can be configured with `global.licenseKey` |
| logDataFilters.applicationReporting.enabled | bool | `true` | Enable logs collection from the entities matching the filters below. |
| logDataFilters.applicationReporting.fileRegex | string | `".*\\.log$"` | Regex to match log file names to include. |
| logDataFilters.applicationReporting.keepFileEntityRegex | string | `".*"` | Regex to match entity names to keep logs from log files. |
| logDataFilters.applicationReporting.keepStdEntityRegex | string | `".*"` | Regex to match entity names to keep logs from stdout and stderr. |
| logDataFilters.applicationReporting.maxSamplePerMinute | int | `10000` | Maximum number of log samples to collect per minute from an entity. |
| logReporting | bool | `true` | Enable log reporting. When enabled, the agent collects and reports logs from entities. |
| networkMetricsDataFilter.dropPodLabels | object | `{}` | Pod labels to match for filtering Network metrics data. Empty map means no label-based filtering. (Example: dropPodLabels: `{ "app": "frontend", "env": "production" }`) |
| networkMetricsDataFilter.dropEntityName | list | `[]` | List of entity names to drop Network metrics data for |
| networkMetricsDataFilter.keepEntityName | list | `[]` | List of entity names to always keep Network metrics data. By default all entities are kept/enabled. This config bypasses `dropEntityName` filter. |
| networkMetricsReporting | string | `true` | Enable network metrics reporting. When enabled, the agent collects and reports network metrics including TCP statistics. RENAMED from `tcpStatsReporting`. The old name is deprecated however backward compatibility is supported. |
| nodeSelector | object | `{}` | Sets all pods' node selector. Can be configured also with `global.nodeSelector` |
| nrStaging | bool | `false` | Endpoint to export data to via the otel collector. NR prod (otlp.nr-data.net:443) by default. Staging (staging-otlp.nr-data.net:443) otherwise. |
| podLabels | object | `{}` | Additional labels for chart pods. |
| podSecurityContext | object | `{}` | Sets all pods' podSecurityContext. Can be configured also with `global.securityContext.pod` |
| priorityClassName | string | `""` | Sets pod's priorityClassName. Can be configured also with `global.priorityClassName` |
| protocols.amqp.enabled | bool | `false` |  |
| protocols.amqp.spans.enabled | bool | `false` |  |
| protocols.amqp.spans.samplingLatency | string | `""` |  |
| protocols.cass.enabled | bool | `true` |  |
| protocols.cass.spans.enabled | bool | `false` |  |
| protocols.cass.spans.samplingLatency | string | `""` |  |
| protocols.dns.enabled | bool | `false` |  |
| protocols.dns.spans.enabled | bool | `false` |  |
| protocols.dns.spans.samplingLatency | string | `""` |  |
| protocols.http.enabled | bool | `true` |  |
| protocols.http.spans.enabled | bool | `true` |  |
| protocols.http.spans.samplingErrorRate | string | `""` | samplingErrorRate represents the error rate threshold for an HTTP route where surpassing it would mean the corresponds spans of the route are exported. Options: 1-100 |
| protocols.http.spans.samplingLatency | string | `"p50"` |  |
| protocols.kafka.enabled | bool | `false` |  |
| protocols.kafka.spans.enabled | bool | `false` |  |
| protocols.kafka.spans.samplingLatency | string | `""` |  |
| protocols.mongodb.enabled | bool | `true` |  |
| protocols.mongodb.spans.enabled | bool | `false` |  |
| protocols.mongodb.spans.samplingLatency | string | `""` |  |
| protocols.mysql.enabled | bool | `true` |  |
| protocols.mysql.spans.enabled | bool | `false` |  |
| protocols.mysql.spans.samplingLatency | string | `""` |  |
| protocols.pgsql.enabled | bool | `true` |  |
| protocols.pgsql.spans.enabled | bool | `false` |  |
| protocols.pgsql.spans.samplingLatency | string | `""` |  |
| protocols.redis.enabled | bool | `true` |  |
| protocols.redis.spans.enabled | bool | `false` |  |
| protocols.redis.spans.samplingLatency | string | `""` |  |
| stirlingSources | string | `"socket_tracer,tcp_stats"` | The source connectors (and data export scripts) to enable. Note that socket_tracer tracks http, mysql, redis, mongodb, amqp, cassandra, dns, and postgresql while tcp_stats tracks TCP metrics. |
| tableStoreDataLimitMB | string | `"250"` | The primary lever to control RAM use of the eBPF agent. Specified in MiB. |
| tolerations | list | `[]` | Sets all pods' tolerations to node taints. Can be configured also with `global.tolerations` |

## Common Errors

### Exporting Errors

If the `nr-ebpf-agent` container logs indicate that the scripts are failing to export data, ensure that Linux headers are installed on the host. Verify that the `nr-ebpf-agent` container logs indicate that the Linux header files were found and that the Stirling data tables were initialized. These logs should be written as the agent is booting up (towards the beginning of the output).

## Maintainers

* kkhandelwal
* bsanwarwala