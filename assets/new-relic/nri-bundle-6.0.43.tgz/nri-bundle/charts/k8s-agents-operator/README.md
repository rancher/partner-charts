# k8s-agents-operator

![Version: 0.38.3](https://img.shields.io/badge/Version-0.38.3-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 0.38.3](https://img.shields.io/badge/AppVersion-0.38.3-informational?style=flat-square)

A Helm chart for the Kubernetes Agents Operator

**Homepage:** <https://github.com/newrelic/k8s-agents-operator/blob/main/charts/k8s-agents-operator/README.md>

## Prerequisites

[Helm](https://helm.sh) must be installed to use the charts.  Please refer to Helm's [documentation](https://helm.sh/docs) to get started.

## Installation

### Requirements

Add the `k8s-agents-operator` Helm chart repository:
```shell
helm repo add k8s-agents-operator https://newrelic.github.io/k8s-agents-operator
```

### Instrumentation

Install the [`k8s-agents-operator`](https://github.com/newrelic/k8s-agents-operator) Helm chart:
```shell
helm upgrade --install k8s-agents-operator k8s-agents-operator/k8s-agents-operator \
  --namespace newrelic \
  --create-namespace \
  --values your-custom-values.yaml
```

### Monitored namespaces

For each namespace you want the operator to be instrumented, a secret will be replicated from the newrelic operator namespace.

For each `Instrumentation` custom resource created, specifying which APM agent you want to instrument for each language. All available APM
 agent docker images and corresponding tags are listed on DockerHub:

* [.NET on Linux](https://hub.docker.com/repository/docker/newrelic/newrelic-dotnet-init/general)
* [.NET on Windows 2022](https://hub.docker.com/repository/docker/newrelic/newrelic-dotnet-windows2022-init/general)
* [.NET on Windows 2025](https://hub.docker.com/repository/docker/newrelic/newrelic-dotnet-windows2025-init/general)
* [Java](https://hub.docker.com/repository/docker/newrelic/newrelic-java-init/general)
* [Node](https://hub.docker.com/repository/docker/newrelic/newrelic-node-init/general)
* [Python](https://hub.docker.com/repository/docker/newrelic/newrelic-python-init/general)
* [Ruby](https://hub.docker.com/repository/docker/newrelic/newrelic-ruby-init/general)
* [PHP](https://hub.docker.com/repository/docker/newrelic/newrelic-php-init/general)

For .NET on Linux

```yaml
apiVersion: newrelic.com/v1alpha2
kind: Instrumentation
metadata:
  name: newrelic-instrumentation-dotnet
spec:
  agent:
    language: dotnet
    image: newrelic/newrelic-dotnet-init:latest # Please ensure you're using a trusted New Relic image
    # env: ...
```

For .NET on Windows 2022

```yaml
apiVersion: newrelic.com/v1alpha2
kind: Instrumentation
metadata:
  name: newrelic-instrumentation-dotnet
spec:
  agent:
    language: dotnet-windows2022
    image: newrelic/newrelic-dotnet-windows2022-init:latest # Please ensure you're using a trusted New Relic image
    # env: ...
```

For .NET on Windows 2025

```yaml
apiVersion: newrelic.com/v1alpha2
kind: Instrumentation
metadata:
  name: newrelic-instrumentation-dotnet
spec:
  agent:
    language: dotnet-windows2025
    image: newrelic/newrelic-dotnet-windows2025-init:latest # Please ensure you're using a trusted New Relic image
    # env: ...
```

For Java

```yaml
apiVersion: newrelic.com/v1alpha2
kind: Instrumentation
metadata:
  name: newrelic-instrumentation-java
  namespace: newrelic
spec:
  agent:
    language: java
    image: newrelic/newrelic-java-init:latest # Please ensure you're using a trusted New Relic image
    # env: ...
```

For NodeJS

```yaml
apiVersion: newrelic.com/v1alpha2
kind: Instrumentation
metadata:
  name: newrelic-instrumentation-nodejs
  namespace: newrelic
spec:
  agent:
    language: nodejs
    image: newrelic/newrelic-node-init:latest # Please ensure you're using a trusted New Relic image
    # env: ...
```

For Python

```yaml
apiVersion: newrelic.com/v1alpha2
kind: Instrumentation
metadata:
  name: newrelic-instrumentation-python
  namespace: newrelic
spec:
  agent:
    language: python
    image: newrelic/newrelic-python-init:latest # Please ensure you're using a trusted New Relic image
    # env: ...
```

For Ruby

```yaml
apiVersion: newrelic.com/v1alpha2
kind: Instrumentation
metadata:
  name: newrelic-instrumentation-ruby
  namespace: newrelic
spec:
  agent:
    language: ruby
    image: newrelic/newrelic-ruby-init:latest # Please ensure you're using a trusted New Relic image
    # env: ...
```

For PHP (glibc)

```yaml
apiVersion: newrelic.com/v1alpha2
kind: Instrumentation
metadata:
  name: newrelic-instrumentation-php
  namespace: newrelic
spec:
  agent:
    language: php-${phpversion} # [7.2, 7.3, 7.4, 8.0, 8.1, 8.2, 8.3, etc.]
    image: newrelic/newrelic-php-init:latest # Please ensure you're using a trusted New Relic image
    # env: ...
```

For PHP (musl)

```yaml
apiVersion: newrelic.com/v1alpha2
kind: Instrumentation
metadata:
  name: newrelic-instrumentation-php
  namespace: newrelic
spec:
  agent:
    language: php-${phpversion} # [7.2, 7.3, 7.4, 8.0, 8.1, 8.2, 8.3, etc.]
    image: newrelic/newrelic-php-init:musl # Please ensure you're using a trusted New Relic image
    # env: ...
```

Configuration using environment variables

```yaml
apiVersion: newrelic.com/v1alpha2
kind: Instrumentation
metadata:
  name: newrelic-instrumentation-lang
  namespace: newrelic
spec:
  agent:
    env:
    # Example New Relic agent supported environment variables
      - name: NEW_RELIC_LABELS
        value: "environment:auto-injection"
    # Example setting the pod name based on the metadata
      - name: NEW_RELIC_POD_NAME
        valueFrom:
          fieldRef:
            fieldPath: metadata.name
    # Example overriding the appName configuration
      - name: NEW_RELIC_APP_NAME
        value: "$(NEW_RELIC_LABELS)-$(NEW_RELIC_POD_NAME)"
```

Configuration using a configmap (Java only)

**Note:** The configmap must store the Java configuration in a key named "newrelic.yaml". Setting an application name and license key via configmap is not supported. To override these properties, use env variables and/or custom secrets.

```yaml
apiVersion: newrelic.com/v1alpha2
kind: Instrumentation
metadata:
  name: newrelic-instrumentation-lang
  namespace: newrelic
spec:
  agentConfigMap: "my-java-app-config" # This configmap must exist in every namespace that the pod in this `Instrumentation` is targeting
  agent: ...
```

Targeting everything in a specific namespace with a label

```yaml
apiVersion: newrelic.com/v1alpha2
kind: Instrumentation
metadata:
  name: newrelic-instrumentation-lang
  namespace: newrelic
spec:
  #agent: ...
  namespaceLabelSelector:
    matchExpressions:
      - key: "app.newrelic.instrumentation"
        operator: "In"
        values: ["java"]
```

Targeting a pod with a specific label

```yaml
apiVersion: newrelic.com/v1alpha2
kind: Instrumentation
metadata:
  name: newrelic-instrumentation-lang
  namespace: newrelic
spec:
  # agent: ...
  podLabelSelector:
    matchExpressions:
      - key: "app.newrelic.instrumentation"
        operator: "In"
        values: ["dotnet"]
```

Using a secret with a non-default name

```yaml
apiVersion: newrelic.com/v1alpha2
kind: Instrumentation
metadata:
  name: newrelic-instrumentation-lang
  namespace: newrelic
spec:
  # agent: ...
  licenseKeySecret: the-name-of-the-custom-secret
```

In the example above, we show how you can configure the agent settings globally using environment variables. See each agent's configuration documentation for available configuration options:
* [Java](https://docs.newrelic.com/docs/apm/agents/java-agent/configuration/java-agent-configuration-config-file/)
* [Node](https://docs.newrelic.com/docs/apm/agents/nodejs-agent/installation-configuration/nodejs-agent-configuration/)
* [Python](https://docs.newrelic.com/docs/apm/agents/python-agent/configuration/python-agent-configuration/)
* [.NET](https://docs.newrelic.com/docs/apm/agents/net-agent/configuration/net-agent-configuration/)
* [Ruby](https://docs.newrelic.com/docs/apm/agents/ruby-agent/configuration/ruby-agent-configuration/)
* [PHP](https://docs.newrelic.com/docs/apm/agents/php-agent/configuration/php-agent-configuration/)

### cert-manager

The K8s Agents Operator supports the use of [`cert-manager`](https://github.com/cert-manager/cert-manager) if preferred.

Install the [`cert-manager`](https://github.com/cert-manager/cert-manager) Helm chart:
```shell
helm install cert-manager jetstack/cert-manager \
  --namespace cert-manager \
  --create-namespace \
  --set crds.enabled=true
```

In your `values.yaml` file, set `admissionWebhooks.autoGenerateCert.enabled: false` and `admissionWebhooks.certManager.enabled: true`. Then install the chart as normal.

## Security

This operator requires a privileged environment to run correctly. As with all components that run in a privileged environment, please exercise caution when granting access to the namespace (and other resources) that the K8s Agent Operator is deployed on.

## Available Chart Releases

To see the available charts:
```shell
helm search repo k8s-agents-operator
```

If you want to see a list of all available charts and releases, check [index.yaml](https://newrelic.github.io/k8s-agents-operator/index.yaml).

## Source Code

* <https://github.com/newrelic/k8s-agents-operator>

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| https://helm-charts.newrelic.com | common-library | 1.4.0 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| admissionWebhooks | object | `{"autoGenerateCert":{"certPeriodDays":365,"enabled":true,"recreate":true},"caFile":"","certFile":"","certManager":{"enabled":false},"create":true,"failurePolicy":"Fail","keyFile":"","podFailurePolicy":"Ignore","timeoutSeconds":null}` | Admission webhooks make sure only requests with correctly formatted rules will get into the Operator |
| admissionWebhooks.autoGenerateCert.certPeriodDays | int | `365` | Cert validity period time in days. |
| admissionWebhooks.autoGenerateCert.enabled | bool | `true` | If true and certManager.enabled is false, Helm will automatically create a self-signed cert and secret for you. |
| admissionWebhooks.autoGenerateCert.recreate | bool | `true` | If set to true, new webhook key/certificate is generated on helm upgrade. |
| admissionWebhooks.caFile | string | `""` | Path to the CA cert. |
| admissionWebhooks.certFile | string | `""` | Path to your own PEM-encoded certificate. |
| admissionWebhooks.certManager.enabled | bool | `false` | If true and autoGenerateCert.enabled is false, cert-manager will create a self-signed cert and secret for you. |
| admissionWebhooks.failurePolicy | string | `"Fail"` | Failure policy for Instrumentation webhooks (v1alpha2, v1beta1, v1beta2). Valid values: Fail, Ignore. Default: Fail. Fail: Rejects CREATE/UPDATE operations on Instrumentation resources if the webhook is unavailable,       ensuring strict validation and enforcement of instrumentation configuration. Ignore: Allows operations to proceed even if the webhook is unavailable, providing resilience         but potentially allowing misconfigured Instrumentation resources. |
| admissionWebhooks.keyFile | string | `""` | Path to your own PEM-encoded private key. |
| admissionWebhooks.podFailurePolicy | string | `"Ignore"` | Failure policy for Pod mutation webhook. Valid values: Fail, Ignore. Default: Ignore. Fail: Rejects pod creation if the webhook is unavailable, ensuring all pods are properly instrumented       but potentially blocking pod deployments if the operator is down. Ignore: Allows pod creation to proceed even if the webhook is unavailable (default behavior),         providing resilience and preventing the operator from blocking critical workloads. Note: This is intentionally separate from failurePolicy to allow different behavior for pod mutations. |
| admissionWebhooks.timeoutSeconds | string | `nil` | Timeout in seconds for all webhook calls (applies to all 4 webhooks). If not set, defaults to Kubernetes API server default (typically 10s). Valid range: 1-30 seconds. Increase this value if you experience timeout issues due to network latency or slow webhook responses. Example: Set to 15 for environments with high network latency. |
| affinity | object | `{}` | Sets all pods' affinities. Can be configured also with `global.affinity` |
| containerSecurityContext | object | `{}` | Sets all security context (at container level). Can be configured also with `global.securityContext.container` |
| controllerManager.manager.containerSecurityContext | string | `nil` | Sets security context (at container level) for the manager container. Overrides `containerSecurityContext` and `global.containerSecurityContext` (Type: object) |
| controllerManager.manager.image.pullPolicy | string | `nil` | Sets the image pull policy for the manager container. Can be configured also with `global.images.pullPolicy` |
| controllerManager.manager.image.repository | string | `"newrelic/k8s-agents-operator"` | Sets the repository and image to use for the manager. Please ensure you're using trusted New Relic images. |
| controllerManager.manager.image.version | string | `nil` | Sets the manager image version to retrieve. Could be a tag i.e. "v0.17.0" or a SHA digest i.e. "sha256:e2399e70e99ac370ca6a3c7e5affa9655da3b246d0ada77c40ed155b3726ee2e" |
| controllerManager.manager.leaderElection | object | `{"enabled":true}` | Enable leader election mechanism for protecting against split brain if multiple operator pods/replicas are started |
| controllerManager.manager.logLevel | string | `"info"` | Log level for the manager |
| controllerManager.manager.resources.limits.cpu | string | `"500m"` |  |
| controllerManager.manager.resources.limits.memory | string | `"192Mi"` |  |
| controllerManager.manager.resources.requests.cpu | string | `"100m"` |  |
| controllerManager.manager.resources.requests.memory | string | `"64Mi"` |  |
| controllerManager.manager.verboseLog | string | `nil` | Enable or disable verbose (debug) logging |
| controllerManager.replicas | int | `1` |  |
| crds.enabled | bool | `true` |  |
| dnsConfig | object | `{}` | Sets pod's dnsConfig. Can be configured also with `global.dnsConfig` |
| healthProbe | object | `{"port":8081}` | when the operator is healthy. It is used by Kubernetes to check the health of the operator. |
| hostNetwork | string | `nil` |  |
| imagePullSecrets | list | `[]` | Image pull secrets. Can be configured also with `global.images.pullSecrets` |
| kubernetesClusterDomain | string | `"cluster.local"` |  |
| labels | object | `{}` | Additional labels for chart objects |
| licenseKey | string | `""` | This set this license key to use. Can be configured also with `global.licenseKey` |
| metricsService.ports[0].name | string | `"https"` |  |
| metricsService.ports[0].port | int | `8443` |  |
| metricsService.ports[0].protocol | string | `"TCP"` |  |
| metricsService.ports[0].targetPort | int | `8443` |  |
| metricsService.type | string | `"ClusterIP"` |  |
| nodeSelector | object | `{}` | Sets all pods' node selector. Can be configured also with `global.nodeSelector` |
| podAnnotations | object | `{}` | Annotations to be added to the deployment. |
| podLabels | object | `{}` | Additional labels for chart pods |
| podSecurityContext | object | `{"runAsNonRoot":true}` | SecurityContext holds pod-level security attributes and common container settings |
| priorityClassName | string | `""` | Sets pod's priorityClassName. Can be configured also with `global.priorityClassName` |
| proxy | string | `""` | HTTP/HTTPS proxy URL for Kubernetes API calls. Can be configured also with `global.proxy` |
| serviceAccount | object | See `values.yaml` | Settings controlling ServiceAccount creation |
| serviceAccount.create | bool | `true` | Specifies whether a ServiceAccount should be created |
| tolerations | list | `[]` | Sets all pods' tolerations to node taints. Can be configured also with `global.tolerations` |
| webhookService.ports[0].port | int | `443` |  |
| webhookService.ports[0].protocol | string | `"TCP"` |  |
| webhookService.ports[0].targetPort | int | `9443` |  |
| webhookService.type | string | `"ClusterIP"` |  |

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| dbudziwojskiNR |  | <https://github.com/dbudziwojskiNR> |
| danielstokes |  | <https://github.com/danielstokes> |
