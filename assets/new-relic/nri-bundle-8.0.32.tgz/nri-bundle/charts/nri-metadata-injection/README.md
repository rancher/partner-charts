# nri-metadata-injection

A Helm chart to deploy the New Relic metadata injection webhook.

**Homepage:** <https://hub.docker.com/r/newrelic/k8s-metadata-injection>

# Helm installation

You can install this chart using [`nri-bundle`](https://github.com/newrelic/helm-charts/tree/master/charts/nri-bundle) located in the
[helm-charts repository](https://github.com/newrelic/helm-charts) or directly from this repository by adding this Helm repository:

```shell
helm repo add nri-metadata-injection https://newrelic.github.io/k8s-metadata-injection
helm upgrade --install nri-metadata-injection/nri-metadata-injection -f your-custom-values.yaml
```

## Source Code

* <https://github.com/newrelic/k8s-metadata-injection>
* <https://github.com/newrelic/k8s-metadata-injection/tree/master/charts/nri-metadata-injection>

## Values managed globally

This chart implements the [New Relic's common Helm library](https://github.com/newrelic/helm-charts/tree/master/library/common-library) which
means that it honors a wide range of defaults and globals common to most New Relic Helm charts.

Options that can be defined globally include `affinity`, `nodeSelector`, `tolerations`, `proxy` and others. The full list can be found at
[user's guide of the common library](https://github.com/newrelic/helm-charts/blob/master/library/common-library/README.md).

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | object | `{}` | Sets pod/node affinities. Can be configured also with `global.affinity` |
| certManager.enabled | bool | `false` | Use cert manager for webhook certs |
| certManager.rootCertificateDuration | string | `"43800h"` | Sets the root certificate duration. Defaults to 43800h (5 years). |
| certManager.webhookCertificateDuration | string | `"8760h"` | Sets certificate duration. Defaults to 8760h (1 year). |
| cluster | string | `""` | Name of the Kubernetes cluster monitored. Can be configured also with `global.cluster` |
| containerSecurityContext | object | `{}` | Sets security context (at container level). Can be configured also with `global.containerSecurityContext` |
| customTLSCertificate | bool | `false` | Use custom tls certificates for the webhook, or let the chart handle it automatically. Ref: https://docs.newrelic.com/docs/integrations/kubernetes-integration/link-your-applications/link-your-applications-kubernetes#configure-injection |
| dnsConfig | object | `{}` | Sets pod's dnsConfig. Can be configured also with `global.dnsConfig` |
| fullnameOverride | string | `""` | Override the full name of the release |
| hostNetwork | bool | false | Sets pod's hostNetwork. Can be configured also with `global.hostNetwork` |
| ignoreNamespaces | list | `["kube-public","kube-node-lease","kube-system"]` | This is a list of namespaces that will be ignored by the webhook. |
| image | object | See `values.yaml` | Image for the New Relic Metadata Injector |
| image.pullSecrets | list | `[]` | The secrets that are needed to pull images from a custom registry. |
| injectOnlyLabeledNamespaces | bool | `false` | Enable the metadata decoration only for pods living in namespaces labeled with 'newrelic-metadata-injection=enabled'. |
| jobImage | object | See `values.yaml` | Image for creating the needed certificates of this webhook to work |
| jobImage.admissionCreate | object | `{"resources":{}}` | Resources for the job container admission-create |
| jobImage.admissionPatch | object | `{"resources":{}}` | Resources for the job container admission-patch |
| jobImage.pullSecrets | list | `[]` | The secrets that are needed to pull images from a custom registry. |
| jobImage.volumeMounts | list | `[]` | Volume mounts to add to the job, you might want to mount tmp if Pod Security Policies Enforce a read-only root. |
| jobImage.volumes | list | `[]` | Volumes to add to the job container |
| labels | object | `{}` | Additional labels for chart objects. Can be configured also with `global.labels` |
| logLevel | string | `"info"` | Log level for the application. Valid values: debug, info, warn, error |
| nameOverride | string | `""` | Override the name of the chart |
| nodeSelector | object | `{}` | Sets pod's node selector. Can be configured also with `global.nodeSelector` |
| podAnnotations | object | `{}` | Annotations to be added to all pods created by the integration. |
| podLabels | object | `{}` | Additional labels for chart pods. Can be configured also with `global.podLabels` |
| podSecurityContext | object | `{}` | Sets security context (at pod level). Can be configured also with `global.podSecurityContext` |
| ports | object | `{"health":8080,"webhook":8443}` | Port configuration for the webhook server |
| ports.health | int | `8080` | Port for health check endpoint (HTTP) |
| ports.webhook | int | `8443` | Port on which the webhook server listens (TLS/HTTPS) |
| priorityClassName | string | `""` | Sets pod's priorityClassName. Can be configured also with `global.priorityClassName` |
| provider | string | `nil` | The provider that you are deploying your cluster on. Sets config options providers that are known to have constraints. |
| rbac.pspEnabled | bool | `false` | Whether the chart should create Pod Security Policy objects. |
| replicas | int | `1` |  |
| resources | object | 100m/30M -/80M | Image for creating the needed certificates of this webhook to work |
| service | object | `{"port":443,"targetPort":""}` | Service configuration |
| service.port | int | `443` | External port exposed by the Kubernetes service |
| service.targetPort | string | `""` | Target port that the service forwards traffic to (should match webhook port) If not specified, defaults to the webhook port value |
| timeoutSeconds | int | `28` | Webhook timeout Ref: https://kubernetes.io/docs/reference/access-authn-authz/extensible-admission-controllers/#timeouts |
| tolerations | list | `[]` | Sets pod's tolerations to node taints. Can be configured also with `global.tolerations` |

## Maintainers

* [juanjjaramillo](https://github.com/juanjjaramillo)
* [csongnr](https://github.com/csongnr)
* [dbudziwojskiNR](https://github.com/dbudziwojskiNR)
* [Philip-R-Beckwith](https://github.com/Philip-R-Beckwith)
