<picture>
  <source media="(prefers-color-scheme: dark)"
          srcset="https://raw.githubusercontent.com/airlock/microgateway/main/media/Microgateway_Labeled_Negative.svg" width="400">
  <source media="(prefers-color-scheme: light)"
          srcset="https://raw.githubusercontent.com/airlock/microgateway/main/media/Microgateway_Labeled.svg" width="400">
  <img alt="Microgateway" src="https://raw.githubusercontent.com/airlock/microgateway/main/media/Microgateway_Labeled.svg" width="400">
</picture>

[![Release](https://img.shields.io/badge/Release-v5.1.2-6bba62)](https://github.com/airlock/microgateway/releases/tag/5.1.2)
[![Gateway API Conformance](https://img.shields.io/badge/Gateway%20API%20Conformance-v1.6-6bba62?logo=kubernetes&logoColor=white)](https://github.com/kubernetes-sigs/gateway-api/blob/main/conformance/reports/v1.6/airlock-microgateway)
[![GitHub](https://img.shields.io/badge/GitHub-Published-6bba62?logo=github&logoColor=white)](https://github.com/airlock/microgateway/releases/tag/5.1.2)
[![Artifact Hub](https://img.shields.io/badge/Artifact%20Hub-Published-6bba62?logo=artifacthub&logoColor=white)](https://artifacthub.io/packages/helm/airlock-microgateway/microgateway)
[![OpenShift Certified](https://img.shields.io/badge/OpenShift%20Certification-Passed-6bba62?logo=redhatopenshift)](https://catalog.redhat.com/en/software/container-stacks/detail/67177f927cfedb209761e48f)

*Airlock Microgateway is a Kubernetes native WAAP (Web Application and API Protection) solution to protect microservices.*

Modern application security is embedded in the development workflow and follows DevSecOps paradigms. Airlock Microgateway is the perfect fit for these requirements. It is a lightweight alternative to the Airlock Gateway appliance, optimized for Kubernetes environments. Airlock Microgateway protects your applications and microservices with the tried-and-tested Airlock security features against attacks, while also providing a high degree of scalability.
__This Helm chart is part of Airlock Microgateway. See our [GitHub repo](https://github.com/airlock/microgateway/tree/5.1.2).__

### Features
* Kubernetes native integration with Gateway API
* Comprehensive set of security features, including deny rules to protect against known attacks (OWASP Top 10), header filtering, JSON parsing, OpenAPI specification enforcement, GraphQL schema validation, and antivirus scanning with ICAP
* Identity aware proxy which makes it possible to enforce authentication using client certificate based authentication, JWT authentication or OIDC with step-up authentication to realize multi factor authentication (MFA). Provides OAuth 2.0 Token Introspection and Token Exchange for continuous validation and secure delegation across services
* Reverse proxy functionality with request routing rules, TLS termination, and remote IP extraction
* Easy-to-use Grafana dashboards which provide valuable insights in allowed and blocked traffic and other metrics

A valid license is required unless Airlock Microgateway is used in the Community Edition.
For a list of all features, view the **[comparison of the community and premium edition](https://docs.airlock.com/microgateway/latest/?topic=MGW-00000056)**.

# Quick start guide

The instructions below provide a quick start guide. Detailed information on the installation are provided in the **[manual](https://docs.airlock.com/microgateway/latest/?topic=MGW-00000138)**.

## Prerequisites
* [Kubernetes Gateway API CRDs](https://gateway-api.sigs.k8s.io/guides/#installing-gateway-api)
* [helm](https://helm.sh/docs/intro/install/) (>= v3.8.0)

### Deploy Kubernetes Gateway API CRDs

```console
kubectl apply --server-side -f https://github.com/kubernetes-sigs/gateway-api/releases/download/v1.6.0/standard-install.yaml
```

## Deploy Airlock Microgateway Operator

1. Install CRDs and Operator:

    ```console
    # Create namespace
    kubectl create namespace airlock-microgateway-system

    # Install the Operator (CRDs are included via the standard Helm 3 mechanism, i.e. Helm will handle initial installation but not upgrades)
    helm install airlock-microgateway \
      oci://quay.io/airlockcharts/microgateway \
      --version '5.1.2' \
      -n airlock-microgateway-system \
      --wait
    ```

2. Verify the correctness of the installation (Recommended):

    ```console
    helm upgrade airlock-microgateway \
      oci://quay.io/airlockcharts/microgateway \
      --version '5.1.2' \
      -n airlock-microgateway-system \
      --set tests.enabled=true \
      --reuse-values

    helm test airlock-microgateway -n airlock-microgateway-system --logs

    helm upgrade airlock-microgateway \
      oci://quay.io/airlockcharts/microgateway \
      --version '5.1.2' \
      -n airlock-microgateway-system \
      --set tests.enabled=false \
      --reuse-values
    ```

## What’s next

After installing the Airlock Microgateway Operator, the various [Configuration Guides](https://docs.airlock.com/microgateway/latest/?topic=MGW-00000146) describe how to deploy and configure a Gateway in your cluster and how to implement common scenarios.
> Several features require a license. See [Community vs. Premium editions in detail](https://docs.airlock.com/microgateway/latest/?topic=MGW-00000056) to choose the right license type.

## Support

### Premium support
If you have a paid license, please follow the [premium support process](https://techzone.ergon.ch/support-process).

### Community support
For the community edition, check our **[Airlock community forum](https://forum.airlock.com/)** for FAQs or register to post your question.
## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | object | `{}` | Custom affinity to apply to the operator Deployment. Used to influence the scheduling. |
| commonAnnotations | object | `{}` | Annotations to add to all resources. |
| commonLabels | object | `{}` | Labels to add to all resources. |
| config.engineImage.digest | string | `"sha256:f6a727669544ba3f7c029352957e4143bd5920ddab4a720b01887bb13ba0606c"` | SHA256 image digest to pull (in the format "sha256:a3051f42d3013813b05f7513bb86ed6a3209cb3003f1bb2f7b72df249aa544d3"). Overrides tag when specified. |
| config.engineImage.pullPolicy | string | `"IfNotPresent"` | Pull policy for this image. |
| config.engineImage.repository | string | `"quay.io/airlock/microgateway-engine"` | Image repository from which to pull the Airlock Microgateway Engine image. |
| config.engineImage.tag | string | `"5.1.2"` | Image tag to pull. |
| config.gatewayPodMonitor.create | bool | `false` | Whether the controller should create a PodMonitor per Gateway. Requires that the monitoring.coreos.com/v1 resources are installed on the cluster. |
| config.gatewayPodMonitor.labels | object | `{}` | Allows to define additional labels that should be set on the PodMonitors. |
| config.logLevel | string | `"info"` | Operator application log level. |
| config.sessionAgentImage.digest | string | `"sha256:a423b06e7d05dcda795f4ca7aec8f2022330c83b1b68607e6b2f2657c336cbd6"` | SHA256 image digest to pull (in the format "sha256:a3051f42d3013813b05f7513bb86ed6a3209cb3003f1bb2f7b72df249aa544d3"). Overrides tag when specified. |
| config.sessionAgentImage.pullPolicy | string | `"IfNotPresent"` | Pull policy for this image. |
| config.sessionAgentImage.repository | string | `"quay.io/airlock/microgateway-session-agent"` | Image repository from which to pull the Airlock Microgateway Session Agent image. |
| config.sessionAgentImage.tag | string | `"5.1.2"` | Image tag to pull. |
| controllerName | string | `"microgateway.airlock.com/gatewayclass-controller"` | Controller name referred in the GatewayClasses managed by this operator. The value must be a path prefixed by the domain `microgateway.airlock.com`. |
| crds.skipGatewayAPICheck | bool | `false` | Whether to skip the sanity check which prevents installing/upgrading the helm chart in a cluster which does not have GatewayAPI v1 CRDs installed. |
| crds.skipVersionCheck | bool | `false` | Whether to skip the sanity check which prevents installing/upgrading the helm chart in a cluster with outdated Airlock Microgateway CRDs. The check aims to prevent unexpected behavior and issues due to Helm v3 not automatically upgrading CRDs which are already present in the cluster when performing a "helm install/upgrade". |
| dashboards.config.grafana.dashboardLabel.name | string | `"grafana_dashboard"` | Name of the label that lets Grafana identify ConfigMaps that represent dashboards. |
| dashboards.config.grafana.dashboardLabel.value | string | `"1"` | Value of the label that lets Grafana identify ConfigMaps that represent dashboards. |
| dashboards.config.grafana.folderAnnotation.name | string | `"grafana_folder"` | Name of the annotation containing the folder name to file dashboards into. |
| dashboards.config.grafana.folderAnnotation.value | string | `"Airlock Microgateway"` | Name of the folder dashboards are filed into within the Grafana UI. |
| dashboards.create | bool | `false` | Whether to create any ConfigMaps containing Grafana dashboards to import. |
| dashboards.instances.accessCtrlLogs.create | bool | `true` | Whether to create the access control logs dashboard. |
| dashboards.instances.accessCtrlMetrics.create | bool | `true` | Whether to create the access control metrics dashboard. |
| dashboards.instances.blockLogs.create | bool | `true` | Whether to create the block logs dashboard. |
| dashboards.instances.blockMetrics.create | bool | `true` | Whether to create the block metrics dashboard. |
| dashboards.instances.downstreamMetrics.create | bool | `true` | Whether to create the downstream metrics dashboard. |
| dashboards.instances.headerLogs.create | bool | `true` | Whether to create the header rewrite logs dashboard. |
| dashboards.instances.license.create | bool | `true` | Whether to create the license dashboard. |
| dashboards.instances.logOnlyLogs.create | bool | `true` | Whether to create the log only logs dashboard. |
| dashboards.instances.logOnlyMetrics.create | bool | `true` | Whether to create the log only metrics dashboard |
| dashboards.instances.overview.create | bool | `true` | Whether to create the overview dashboard. |
| dashboards.instances.requestLogs.create | bool | `true` | Whether to create the request logs dashboard. |
| dashboards.instances.systemMetrics.create | bool | `true` | Whether to create the system metrics dashboard. |
| dashboards.instances.upstreamMetrics.create | bool | `true` | Whether to create the upstream metrics dashboard. |
| extraEnv | list | `[]` | Additional environment variables to set for the operator container. |
| fullnameOverride | string | `""` | Allows overriding the name to use as full name of resources. |
| gatewayClass.create | bool | `true` | Whether to create a default GatewayClass during installation. |
| gatewayClass.name | string | `"airlock-microgateway"` | Name of the default GatewayClass. The name must adhere to the DNS Subdomain Name format as defined in RFC1123. See https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#dns-subdomain-names for details. |
| image.digest | string | `"sha256:a7ef43220bfd6c3e3d7b81eaa421c30e970fb4263787d0ea57155a820e9cf11a"` | SHA256 image digest to pull (in the format "sha256:c79ee3f85862fb386e9dd62b901b607161d27807f512d7fbdece05e9ee3d7c63"). Overrides tag when specified. |
| image.pullPolicy | string | `"IfNotPresent"` | Pull policy for this image. |
| image.repository | string | `"quay.io/airlock/microgateway-operator"` | Image repository from which to pull the Airlock Microgateway Operator image. |
| image.tag | string | `"5.1.2"` | Image tag to pull. |
| imagePullSecrets | list | `[]` | ImagePullSecrets to use when pulling images. Can be defined either as a list of objects or as a list of strings. |
| license.mode | string | `"optional"` | License enforcement mode, controls whether a license is required for Gateways to be accepted. With "required", Gateways are rejected unless a valid license is configured, surfacing a missing or misconfigured license as an error early. With "optional", Gateways are always accepted, if no license is configured, the operator falls back to the Community edition. It is recommended to set to "required" when a Premium license is obtained. |
| license.secretName | string | `"airlock-microgateway-license"` | Name of the secret containing the "microgateway-license.txt" key. |
| nameOverride | string | `""` | Allows overriding the name to use instead of "microgateway". |
| nodeSelector | object | `{}` | Custom nodeSelector to apply to the operator Deployment to constrain its Pods to certain nodes. |
| podAnnotations | object | `{}` | Annotations to add to all operator Pods. |
| podDisruptionBudget | object | `{}` | PodDisruptionBudget to create for the operator Deployment. If empty, no PDB is created. Note: The selector is automatically configured to match the labels of the operator Deployment and does not need to be set manually. See https://kubernetes.io/docs/tasks/run-application/configure-pdb/ for details. |
| podLabels | object | `{}` | Labels to add to all operator Pods. |
| rbac.create | bool | `true` | Whether to create RBAC resources which are required for the Airlock Microgateway Operator to function. |
| replicaCount | int | `1` | Number of replicas for the operator Deployment. |
| resources | object | `{"limits":{"cpu":"2000m","memory":"256Mi"},"requests":{"cpu":"250m","memory":"256Mi"}}` | Resource restrictions to apply to the operator container. |
| serviceAccount.annotations | object | `{}` | Annotations to add to the ServiceAccount. |
| serviceAccount.create | bool | `true` | Whether a ServiceAccount should be created for the operator Deployment. |
| serviceAccount.name | string | `""` | Name of the ServiceAccount to use. If not set and create is true, a name is generated using the fullname template. |
| serviceAnnotations | object | `{}` | Annotations to add to the operator Service. |
| serviceLabels | object | `{}` | Labels to add to the operator Service. |
| serviceMonitor.create | bool | `false` | Whether to create a ServiceMonitor resource for monitoring of the operator Deployment. Requires that the monitoring.coreos.com/v1 resources are installed on the cluster. |
| serviceMonitor.labels | object | `{}` | Labels to add to the ServiceMonitor. |
| tests.enabled | bool | `false` | Whether additional resources required for running `helm test` should be created (e.g. Roles and ServiceAccounts). If set to false, `helm test` will not run any tests. |
| tolerations | list | `[]` | Custom tolerations to apply to the operator Deployment to allow its Pods to run on tainted nodes. |
| topologySpreadConstraints | list | `[]` | Custom topologySpreadConstraints to apply to the operator Deployment. Used to influence how replicas are spread across the cluster. |
| updateStrategy | object | `{"type":"RollingUpdate"}` | Specifies the operator Deployment update strategy. |

## License
View the [detailed license terms](https://www.airlock.com/en/airlock-license) for the software contained in this image.
* Decompiling or reverse engineering is not permitted.
* Using any of the deny rules or parts of these filter patterns outside of the image is not permitted.

Airlock<sup>&#174;</sup> is a security innovation by [ergon](https://www.ergon.ch/en)

<!-- Airlock SAH Logo (different image for light/dark mode) -->
<a href="https://www.airlock.com/en/secure-access-hub/">
<picture>
    <source media="(prefers-color-scheme: dark)"
        srcset="https://raw.githubusercontent.com/airlock/microgateway/main/media/Airlock_Logo_Negative.png">
    <source media="(prefers-color-scheme: light)"
        srcset="https://raw.githubusercontent.com/airlock/microgateway/main/media/Airlock_Logo.png">
    <img alt="Airlock Secure Access Hub" src="https://raw.githubusercontent.com/airlock/microgateway/main/media/Airlock_Logo.png" width="150">
</picture>
</a>
