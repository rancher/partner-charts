# Copyright Dynatrace LLC
# SPDX-License-Identifier: Apache-2.0

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "dynatrace-operator.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Check if default image or imageref is used.
When imageRef.digest is set, it wins over imageRef.tag. The rendered image
reference uses <repository>@<digest> and the tag is omitted to avoid the
confusing case where the tag and digest disagree.
*/}}
{{- define "dynatrace-operator.image" -}}
{{- if .Values.image -}}
	{{- printf "%s" .Values.image -}}
{{- else -}}
    {{- if (.Values.imageRef).repository -}}
        {{- if .Values.imageRef.digest -}}
            {{- printf "%s@%s" .Values.imageRef.repository .Values.imageRef.digest -}}
        {{- else -}}
            {{- .Values.imageRef.tag | default (printf "v%s" .Chart.AppVersion) | printf "%s:%s" .Values.imageRef.repository -}}
        {{- end -}}
    {{- else if hasPrefix "0.0.0-nightly-" .Chart.AppVersion -}}
        {{- printf "%s:%s" "ghcr.io/dynatrace/dynatrace-operator" (.Chart.AppVersion | replace "0.0.0-" "") }}
    {{- else if eq (include "dynatrace-operator.platform" .) "openshift" -}}
        {{- printf "%s:v%s" "registry.connect.redhat.com/dynatrace/dynatrace-operator" .Chart.AppVersion }}
    {{- else if eq (include "dynatrace-operator.platform" .) "google-marketplace" -}}
    	{{- printf "%s:%s" "gcr.io/dynatrace-marketplace-prod/dynatrace-operator" .Chart.AppVersion }}
    {{- else if eq (include "dynatrace-operator.platform" .) "azure-marketplace" -}}
        {{- printf "%s/%s@%s" .Values.global.azure.images.operator.registry .Values.global.azure.images.operator.image .Values.global.azure.images.operator.digest }}
    {{- else -}}
            {{- printf "%s:v%s" "public.ecr.aws/dynatrace/dynatrace-operator" .Chart.AppVersion }}
    {{- end -}}
{{- end -}}
{{- end -}}

{{- define "webhook.securityContext" -}}
    {{- if not .Values.debug -}}
        {{- toYaml .Values.webhook.securityContext -}}
    {{- end -}}
{{- end -}}

{{- define "csidriver.provisioner.resources" -}}
    {{- if not .Values.debug -}}
        {{- toYaml .Values.csidriver.provisioner.resources -}}
    {{- end -}}
{{- end -}}

{{- define "csidriver.server.resources" -}}
    {{- if not .Values.debug -}}
        {{- toYaml .Values.csidriver.server.resources -}}
    {{- end -}}
{{- end -}}

{{- define "dynatrace-operator.startupProbe" -}}
startupProbe:
  exec:
    command:
    - /usr/local/bin/dynatrace-operator
    - startup-probe
  periodSeconds: {{ .periodSeconds | default 10 }}
  timeoutSeconds: {{ .timeoutSeconds | default 5 }}
  failureThreshold: {{ .failureThreshold | default 1 }}
{{- end -}}

{{- define "dynatrace-operator.modules-json-env" -}}
- name: modules.json
  value: |
    {
      "csiDriver": {{ and .Values.csidriver.enabled (not .Values.csidriver.migrationMode) }},
      "activeGate": {{ .Values.rbac.activeGate.create }},
      "oneAgent": {{ .Values.rbac.oneAgent.create }},
      "extensions": {{ .Values.rbac.extensions.create }},
      "logMonitoring": {{ .Values.rbac.logMonitoring.create }},
      "edgeConnect": {{ .Values.rbac.edgeConnect.create }},
      "supportability": {{ .Values.rbac.supportability }},
      "kubernetesMonitoring": {{ .Values.rbac.kubernetesMonitoring.create }},
      "kspm": {{ .Values.rbac.kspm.create }}
    }
{{- end -}}

{{- define "dynatrace-operator.helm-json-env" -}}
- name: helm.json
  value: |
    {
      "tolerations": {{ .Values.csidriver.tolerations | toJson }},
      "annotations": {{ .Values.csidriver.annotations | toJson }},
      "labels": {{ .Values.csidriver.labels | toJson }},
      "job": {
        "securityContext": {{ .Values.csidriver.job.securityContext | toJson }},
        "resources": {{ .Values.csidriver.job.resources | toJson }},
        "priorityClassName": {{ include "dynatrace-operator.CSIPriorityClassName" . | toJson }}
      }
    }
{{- end -}}

{{- define "dynatrace-operator.app-version-env" -}}
- name: APP_VERSION
  value: {{ .Chart.AppVersion | quote }}
{{- end -}}

{{/*
The common envs that inform the component about what is configured in its pod
*/}}
{{- define "dynatrace-operator.common.pod.envs" -}}
- name: POD_NAMESPACE
  valueFrom:
    fieldRef:
      fieldPath: metadata.namespace
- name: POD_NAME
  valueFrom:
    fieldRef:
      fieldPath: metadata.name
- name: DT_OPERATOR_IMAGE
  value: {{ include "dynatrace-operator.image" . }}
- name: OLM_OPERATOR_NAMESPACE
  valueFrom:
    fieldRef:
      fieldPath: metadata.annotations['olm.operatorNamespace']
{{- end -}}

{{- define "dynatrace-operator.pull-secret-env" -}}
{{- if .Values.customPullSecret }}
- name: DT_OPERATOR_PULL_SECRET
  value: {{ .Values.customPullSecret }}
{{- end }}
{{- end -}}

{{- define "dynatrace-operator.helmPreUpgradeHookAnnotations" -}}
"helm.sh/hook": pre-upgrade
"helm.sh/hook-weight": "-5"
"helm.sh/hook-delete-policy": before-hook-creation,hook-succeeded
{{- end -}}

{{- define "kubernetes.appArmorSecurityContextSupported" -}}
{{- if semverCompare ">=1.31.0" .Capabilities.KubeVersion.Version -}}
    true
{{- end -}}
{{- end -}}

{{- define "kubernetes.defaultAppArmorProfile" -}}
{{- if (include "kubernetes.appArmorSecurityContextSupported" .) -}}
appArmorProfile:
  type: RuntimeDefault
{{- end -}}
{{- end -}}

{{- define "dynatrace-operator.webhook.replicas" -}}
  {{- if or (not .Values.webhook.highAvailability) .Values.debug -}}
    {{- 1 -}}
  {{- else -}}
    {{- .Values.webhook.replicas -}}
  {{- end -}}
{{- end -}}

{{- define "dynatrace-operator.webhook.topologySpreadConstraints" -}}
  {{- if .Values.webhook.highAvailability -}}
topologySpreadConstraints:
  {{- toYaml .Values.webhook.topologySpreadConstraints | nindent 2 }}
  {{- end -}}
{{- end -}}

{{- define "dynatrace-operator.webhookCertsCtrl.envs" -}}
{{- with .Values.webhook.certs.rootDuration }}
- name: DT_WEBHOOK_CERTS_ROOT_DURATION
  value: {{ . | quote }}
{{- end }}
{{- with .Values.webhook.certs.serverDuration }}
- name: DT_WEBHOOK_CERTS_SERVER_DURATION
  value: {{ . | quote }}
{{- end }}
{{- with .Values.webhook.certs.renewalThreshold }}
- name: DT_WEBHOOK_CERTS_RENEWAL_THRESHOLD
  value: {{ . | quote }}
{{- end }}
{{- with .Values.webhook.certs.requeueAfter }}
- name: DT_WEBHOOK_CERTS_REQUEUE_AFTER
  value: {{ . | quote }}
{{- end }}
{{- end -}}

{{- define "dynatrace-operator.client-connection-timeout-env" -}}
  {{- with .Values.operator.clientConnectionTimeout }}
- name: DT_CLIENT_CONNECTION_TIMEOUT
  value: {{ . | quote }}
  {{- end }}
{{- end -}}

{{- define "dynatrace-csidriver.client-connection-timeout-env" -}}
  {{- with .Values.csidriver.clientConnectionTimeout }}
- name: DT_CLIENT_CONNECTION_TIMEOUT
  value: {{ . | quote }}
  {{- end }}
{{- end -}}

{{- define "dynatrace-webhook.metadata-size-limit-env" -}}
  {{- with .Values.webhook.metadataSizeLimit }}
- name: DT_METADATA_SIZE_LIMIT
  value: {{ . | quote }}
  {{- end }}
{{- end -}}
