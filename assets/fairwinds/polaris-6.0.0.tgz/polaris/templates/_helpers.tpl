{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "polaris.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "polaris.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "polaris.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Standard labels
*/}}
{{- define "polaris.labels" -}}
app: {{ include "polaris.name" . }}
{{- if not .Values.templateOnly }}
app.kubernetes.io/component: dashboard
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/name: {{ template "polaris.name" . }}
app.kubernetes.io/part-of: {{ template "polaris.name" . }} 
app.kubernetes.io/version: "{{ .Chart.Version }}"
helm.sh/chart: {{ include "polaris.chart" . }}
{{- end -}}
{{- end -}}

{{/*
Standard selector
*/}}
{{- define "polaris.selectors" -}}
app: {{ include "polaris.name" . }}
{{- if not .Values.templateOnly }}
app.kubernetes.io/name: {{ include "polaris.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}
{{- end -}}

{{/*
Name of the service account to use
*/}}
{{- define "polaris.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
    {{ default (include "polaris.fullname" .) .Values.serviceAccount.name }}
{{- else -}}
    {{ default "default" .Values.serviceAccount.name }}
{{- end -}}
{{- end -}}

{{/*
Polaris OSS images use v-prefixed semver tags on Artifact Registry (e.g. v10.2.0).
*/}}
{{- define "polaris.imageTag" -}}
{{- if .Values.image.tag -}}
{{- .Values.image.tag -}}
{{- else -}}
{{- $v := .Chart.AppVersion -}}
{{- if hasPrefix "v" $v -}}
{{- $v -}}
{{- else -}}
{{- printf "v%s" $v -}}
{{- end -}}
{{- end -}}
{{- end -}}
