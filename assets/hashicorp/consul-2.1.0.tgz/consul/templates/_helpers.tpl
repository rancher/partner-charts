{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to
this (by the DNS naming spec). Supports the legacy fullnameOverride setting
as well as the global.name setting.
*/}}
{{- define "consul.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else if .Values.global.name -}}
{{- .Values.global.name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/*
Base name that all Kubernetes auth methods managed by this chart are derived from.
Defaults to the release fullname so that existing installations keep their auth
method names. Set global.acls.authMethod.name to a value that is unique per
Kubernetes cluster when several clusters share a single Consul control plane,
otherwise the clusters overwrite each other's auth methods.
*/}}
{{- define "consul.authMethodPrefix" -}}
{{- default (include "consul.fullname" .) .Values.global.acls.authMethod.name -}}
{{- end -}}

{{/*
Auth method that Consul components use to issue a `consul login` for local tokens.
*/}}
{{- define "consul.localComponentAuthMethodName" -}}
{{ include "consul.authMethodPrefix" . }}-k8s-component-auth-method
{{- end -}}

{{/*
Auth method that Consul components use to issue a `consul login` for global tokens.
Only created in secondary datacenters when federation is enabled, which is why it
is suffixed with the datacenter name to keep it distinct from the local one.
*/}}
{{- define "consul.globalComponentAuthMethodName" -}}
{{ include "consul.authMethodPrefix" . }}-k8s-component-auth-method-{{ .Values.global.datacenter }}
{{- end -}}

{{/*
Auth method that service mesh workloads use to issue a `consul login`.
*/}}
{{- define "consul.connectInjectAuthMethodName" -}}
{{ include "consul.authMethodPrefix" . }}-k8s-auth-method
{{- end -}}

{{/*
Resolve the Consul namespace that a terminating gateway service should be
registered into. Resolution order:
  1. Per-gateway consulNamespace.
  2. terminatingGateways.defaults.consulNamespace, unless it is the bare
     "default" sentinel (treated as unset so mirroring can take precedence).
  3. The mirrored Consul namespace derived from the release namespace when
     namespace mirroring is enabled.
  4. The terminatingGateways.defaults.consulNamespace value (i.e. "default").

Note: This intentionally does NOT consult
connectInject.consulNamespaces.consulDestinationNamespace. Terminating gateways have
historically only resolved their namespace from terminatingGateways.defaults.consulNamespace
/ the per-gateway consulNamespace, and the gateway's ACL policy (created by server-acl-init)
is scoped to that same namespace. Following the connect destination namespace here would
register the service into a namespace its ACL token is not authorized for. Mirroring is the
only additional case we resolve, matching connect-injected services and the API gateway.

Usage:
  {{ include "consul.terminatingGatewayNamespace" (dict "root" $root "gatewayNamespace" .consulNamespace "defaultsNamespace" $defaults.consulNamespace) }}
*/}}
{{- define "consul.terminatingGatewayNamespace" -}}
{{- $root := .root -}}
{{- $gatewayNamespace := .gatewayNamespace -}}
{{- $defaultsNamespace := .defaultsNamespace -}}
{{- if $gatewayNamespace -}}
{{- $gatewayNamespace -}}
{{- else if (and $defaultsNamespace (ne $defaultsNamespace "default")) -}}
{{- $defaultsNamespace -}}
{{- else if $root.Values.connectInject.consulNamespaces.mirroringK8S -}}
{{- printf "%s%s" $root.Values.connectInject.consulNamespaces.mirroringK8SPrefix $root.Release.Namespace -}}
{{- else -}}
{{- default "default" $defaultsNamespace -}}
{{- end -}}
{{- end -}}

{{- define "consul.restrictedSecurityContext" -}}
{{- if not .Values.global.enablePodSecurityPolicies -}}
securityContext:
  allowPrivilegeEscalation: false
  readOnlyRootFilesystem: true
  capabilities:
    drop:
    - ALL
  runAsNonRoot: true
  seccompProfile:
    type: RuntimeDefault
{{- if not .Values.global.openshift.enabled -}}
{{/*
We must set runAsUser or else the root user will be used in some cases and
containers will fail to start due to runAsNonRoot above (e.g.
tls-init-cleanup). On OpenShift, runAsUser is automatically. We pick user 100
because it is a non-root user id that exists in the consul, consul-dataplane,
and consul-k8s-control-plane images.
*/}}
  runAsUser: 100
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "consul.podSecurityContext" -}}
{{- if and .Values.global.podSecurityContext.enabled (not .Values.global.openshift.enabled) -}}
securityContext:
  fsGroup: 100
  fsGroupChangePolicy: OnRootMismatch
{{- end -}}
{{- end -}}

{{- define "consul.restrictedSecurityContextWithNetBindService" -}}
{{- if not .Values.global.enablePodSecurityPolicies -}}
securityContext:
  allowPrivilegeEscalation: false
  readOnlyRootFilesystem: true
  capabilities:
    add:
    - NET_BIND_SERVICE
    drop:
    - ALL
  runAsNonRoot: true
  seccompProfile:
    type: RuntimeDefault
{{- if not .Values.global.openshift.enabled -}}
{{/*
We must set runAsUser or else the root user will be used in some cases and
containers will fail to start due to runAsNonRoot above (e.g.
tls-init-cleanup). On OpenShift, runAsUser is automatically. We pick user 100
because it is a non-root user id that exists in the consul, consul-dataplane,
and consul-k8s-control-plane images.
*/}}
  runAsUser: 100
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "consul.vaultSecretTemplate" -}}
 |
            {{ "{{" }}- with secret "{{ .secretName }}" -{{ "}}" }}
            {{ "{{" }}- {{ printf ".Data.data.%s" .secretKey }} -{{ "}}" }}
            {{ "{{" }}- end -{{ "}}" }}
{{- end -}}

{{- define "consul.vaultCATemplate" -}}
 |
            {{ "{{" }}- with secret "{{ .secretName }}" -{{ "}}" }}
            {{ "{{" }}- .Data.certificate -{{ "}}" }}
            {{ "{{" }}- end -{{ "}}" }}
{{- end -}}

{{- define "consul.serverTLSCATemplate" -}}
{{ include "consul.vaultCATemplate" .Values.global.tls.caCert }}
{{- end -}}

{{- define "consul.serverTLSCertTemplate" -}}
 |
            {{ "{{" }}- with secret "{{ .Values.server.serverCert.secretName }}" "{{ printf "common_name=server.%s.%s" .Values.global.datacenter .Values.global.domain }}"
            "alt_names={{ include "consul.serverTLSAltNames" . }}" "ip_sans=127.0.0.1{{ include "consul.serverAdditionalIPSANs" . }}" -{{ "}}" }}
            {{ "{{" }}- .Data.certificate -{{ "}}" }}
            {{ "{{" }}- if .Data.ca_chain -{{ "}}" }}
            {{ "{{" }}- $lastintermediatecertindex := len .Data.ca_chain | subtract 1 -{{ "}}" }}
            {{ "{{" }} range $index, $cacert := .Data.ca_chain {{ "}}" }}
            {{ "{{" }} if (lt $index $lastintermediatecertindex) {{ "}}" }}
            {{ "{{" }} $cacert {{ "}}" }}
            {{ "{{" }} end {{ "}}" }}
            {{ "{{" }} end {{ "}}" }}
            {{ "{{" }}- end -{{ "}}" }}
            {{ "{{" }}- end -{{ "}}" }}
{{- end -}}

{{- define "consul.serverTLSKeyTemplate" -}}
 |
            {{ "{{" }}- with secret "{{ .Values.server.serverCert.secretName }}" "{{ printf "common_name=server.%s.%s" .Values.global.datacenter .Values.global.domain }}"
            "alt_names={{ include "consul.serverTLSAltNames" . }}" "ip_sans=127.0.0.1{{ include "consul.serverAdditionalIPSANs" . }}" -{{ "}}" }}
            {{ "{{" }}- .Data.private_key -{{ "}}" }}
            {{ "{{" }}- end -{{ "}}" }}
{{- end -}}

{{- define "consul.connectInjectWebhookTLSCertTemplate" -}}
 |
            {{ "{{" }}- with secret "{{ .Values.global.secretsBackend.vault.connectInject.tlsCert.secretName }}" "{{- $name := include "consul.fullname" . -}}{{ printf "common_name=%s-connect-injector" $name }}"
            "alt_names={{ include "consul.connectInjectorTLSAltNames" . }}" -{{ "}}" }}
            {{ "{{" }}- .Data.certificate -{{ "}}" }}
            {{ "{{" }}- end -{{ "}}" }}
{{- end -}}

{{- define "consul.connectInjectWebhookTLSKeyTemplate" -}}
 |
            {{ "{{" }}- with secret "{{ .Values.global.secretsBackend.vault.connectInject.tlsCert.secretName }}" "{{- $name := include "consul.fullname" . -}}{{ printf "common_name=%s-connect-injector" $name }}"
            "alt_names={{ include "consul.connectInjectorTLSAltNames" . }}" -{{ "}}" }}
            {{ "{{" }}- .Data.private_key -{{ "}}" }}
            {{ "{{" }}- end -{{ "}}" }}
{{- end -}}

{{- define "consul.serverTLSAltNames" -}}
{{- $name := include "consul.fullname" . -}}
{{- $ns := .Release.Namespace -}}
{{ printf "localhost,%s-server,*.%s-server,*.%s-server.%s,%s-server.%s,*.%s-server.%s.svc,%s-server.%s.svc,*.server.%s.%s" $name $name $name $ns $name $ns $name $ns $name $ns (.Values.global.datacenter ) (.Values.global.domain) }}{{ include "consul.serverAdditionalDNSSANs" . }}
{{- end -}}

{{- define "consul.serverAdditionalDNSSANs" -}}
{{- if .Values.global.tls -}}{{- if .Values.global.tls.serverAdditionalDNSSANs -}}{{- range $san := .Values.global.tls.serverAdditionalDNSSANs }},{{ $san }} {{- end -}}{{- end -}}{{- end -}}
{{- end -}}

{{- define "consul.serverAdditionalIPSANs" -}}
{{- if .Values.global.tls -}}{{- if .Values.global.tls.serverAdditionalIPSANs -}}{{- range $san := .Values.global.tls.serverAdditionalIPSANs }},{{ $san }} {{- end -}}{{- end -}}{{- end -}}
{{- end -}}

{{- define "consul.connectInjectorTLSAltNames" -}}
{{- $name := include "consul.fullname" . -}}
{{- $ns := .Release.Namespace -}}
{{ printf "%s-connect-injector,%s-connect-injector.%s,%s-connect-injector.%s.svc,%s-connect-injector.%s.svc.cluster.local" $name $name $ns $name $ns $name $ns}}
{{- end -}}

{{- define "consul.vaultReplicationTokenTemplate" -}}
|
          {{ "{{" }}- with secret "{{ .Values.global.acls.replicationToken.secretName }}" -{{ "}}" }}
          {{ "{{" }}- {{ printf ".Data.data.%s" .Values.global.acls.replicationToken.secretKey }} -{{ "}}" }}
          {{ "{{" }}- end -{{ "}}" }}
{{- end -}}

{{- define "consul.vaultReplicationTokenConfigTemplate" -}}
|
          {{ "{{" }}- with secret "{{ .Values.global.acls.replicationToken.secretName }}" -{{ "}}" }}
          acl { tokens { agent = "{{ "{{" }}- {{ printf ".Data.data.%s" .Values.global.acls.replicationToken.secretKey }} -{{ "}}" }}", replication = "{{ "{{" }}- {{ printf ".Data.data.%s" .Values.global.acls.replicationToken.secretKey }} -{{ "}}" }}" }}
          {{ "{{" }}- end -{{ "}}" }}
{{- end -}}

{{- define "consul.vaultBootstrapTokenConfigTemplate" -}}
|
          {{ "{{" }}- with secret "{{ .Values.global.acls.bootstrapToken.secretName }}" -{{ "}}" }}
          acl { tokens { initial_management = "{{ "{{" }}- {{ printf ".Data.data.%s" .Values.global.acls.bootstrapToken.secretKey }} -{{ "}}" }}" }}
          {{ "{{" }}- end -{{ "}}" }}
{{- end -}}

{{/*
Sets up the extra-from-values config file passed to consul and then uses sed to do any necessary
substitution for HOST_IP/POD_IP/HOSTNAME. Useful for dogstats telemetry. The output file
is passed to consul as a -config-file param on command line.
*/}}
{{- define "consul.extraconfig" -}}
              cp /consul/tmp/extra-config/extra-from-values.json /consul/extra-config/extra-from-values.json
              [ -n "${HOST_IP}" ] && sed -Ei "s|HOST_IP|${HOST_IP?}|g" /consul/extra-config/extra-from-values.json
              [ -n "${POD_IP}" ] && sed -Ei "s|POD_IP|${POD_IP?}|g" /consul/extra-config/extra-from-values.json
              [ -n "${HOSTNAME}" ] && sed -Ei "s|HOSTNAME|${HOSTNAME?}|g" /consul/extra-config/extra-from-values.json
{{- end -}}

{{/*
Rehashes the CA certificates written to /trusted-cas so that OpenSSL-based clients
can discover them via SSL_CERT_DIR. OpenSSL only looks up CAs in a certificate
directory by their subject hash (<hash>.N), so the .pem files alone are ignored.

Notes on the implementation:
  - Certificates that share a subject (for example an old and a new revision of the
    same CA during a rotation) share a subject hash, so suffixes are allocated
    sequentially instead of always using .0. Otherwise all but the last would be
    silently dropped.
  - Pre-existing symlinks are cleared first so that a container restart, which
    reuses the same emptyDir, does not keep appending duplicate links.
  - The whole block is a no-op when openssl is not present in the image (the
    consul-telemetry-collector image does not ship it). The command runs under
    `sh -ec`, so an unguarded openssl call would abort container startup.

Callers are expected to indent this with nindent.
*/}}
{{- define "consul.trustedCAsRehash" -}}
if command -v openssl > /dev/null 2>&1; then
  for CERT_LINK in /trusted-cas/*; do
    if [ -L "${CERT_LINK}" ]; then
      rm -f "${CERT_LINK}"
    fi
  done
  for CERT_FILE in /trusted-cas/custom-ca-*.pem; do
    if [ ! -e "${CERT_FILE}" ]; then
      continue
    fi
    CERT_HASH=$(openssl x509 -subject_hash -noout -in "${CERT_FILE}" 2> /dev/null) || CERT_HASH=""
    if [ -z "${CERT_HASH}" ]; then
      continue
    fi
    CERT_SUFFIX=0
    while [ -e "/trusted-cas/${CERT_HASH}.${CERT_SUFFIX}" ]; do
      CERT_SUFFIX=$((CERT_SUFFIX + 1))
    done
    ln -sf "${CERT_FILE}" "/trusted-cas/${CERT_HASH}.${CERT_SUFFIX}"
  done
fi
{{- end -}}

{{/*
Cleanup server.extraConfig entries to avoid conflicting entries:
    - server.enableAgentDebug:
      - `enable_debug` should not exist in extraConfig
    - metrics.disableAgentHostName:
      - if global.metrics.enabled and global.metrics.enableAgentMetrics are enabled, `disable_hostname` should not exist in extraConfig
    - metrics.enableHostMetrics:
      - if global.metrics.enabled and global.metrics.enableAgentMetrics are enabled, `enable_host_metrics` should not exist in extraConfig
    - metrics.prefixFilter
      - if global.metrics.enabled and global.metrics.enableAgentMetrics are enabled, `prefix_filter` should not exist in extraConfig
    - metrics.datadog.enabled:
      - if global.metrics.datadog.enabled and global.metrics.datadog.dogstatsd.enabled, `dogstatsd_tags` and `dogstatsd_addr` should not exist in extraConfig

Usage: {{ template "consul.validateExtraConfig" . }}
*/}}
{{- define "consul.validateExtraConfig" -}}
{{- if (contains "enable_debug" .Values.server.extraConfig) }}{{ fail "The enable_debug key is present in extra-from-values.json. Use server.enableAgentDebug to set this value." }}{{- end }}
{{- if (contains "disable_hostname" .Values.server.extraConfig) }}{{ fail "The disable_hostname key is present in extra-from-values.json. Use global.metrics.disableAgentHostName to set this value." }}{{- end }}
{{- if (contains "enable_host_metrics" .Values.server.extraConfig) }}{{ fail "The enable_host_metrics key is present in extra-from-values.json. Use global.metrics.enableHostMetrics to set this value." }}{{- end }}
{{- if (contains "prefix_filter" .Values.server.extraConfig) }}{{ fail "The prefix_filter key is present in extra-from-values.json. Use global.metrics.prefix_filter to set this value." }}{{- end }}
{{- if (and .Values.global.metrics.enabled .Values.global.metrics.enableAgentMetrics) }}{{- if (and .Values.global.metrics.datadog.dogstatsd.enabled) }}{{- if (contains "dogstatsd_tags" .Values.server.extraConfig) }}{{ fail "The dogstatsd_tags key is present in extra-from-values.json. Use global.metrics.datadog.dogstatsd.dogstatsdTags to set this value." }}{{- end }}{{- end }}{{- if (and .Values.global.metrics.datadog.dogstatsd.enabled) }}{{- if (contains "dogstatsd_addr" .Values.server.extraConfig) }}{{ fail "The dogstatsd_addr key is present in extra-from-values.json. Use global.metrics.datadog.dogstatsd.dogstatsd_addr to set this value." }}{{- end }}{{- end }}{{- end }}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "consul.chart" -}}
{{- printf "%s-helm" .Chart.Name | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Expand the name of the chart.
*/}}
{{- define "consul.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Calculate max number of server pods that are allowed to be voluntarily disrupted.
When there's 1 server, this is set to 0 because this pod should not be disrupted. This is an edge
case and I'm not sure it makes a difference when there's only one server but that's what the previous config was and
I don't want to change it for this edge case.
Otherwise we've changed this to always be 1 as part of the move to set leave_on_terminate
to true. With leave_on_terminate set to true, whenever a server pod is stopped, the number of peers in raft
is reduced. If the number of servers is odd and the count is reduced by 1, the quorum size doesn't change,
but if it's reduced by more than 1, the quorum size can change so that's why this is now always hardcoded to 1.
*/}}
{{- define "consul.server.pdb.maxUnavailable" -}}
{{- if eq (int .Values.server.replicas) 1 -}}
{{ 0 }}
{{- else if .Values.server.disruptionBudget.maxUnavailable -}}
{{ .Values.server.disruptionBudget.maxUnavailable -}}
{{- else -}}
{{ 1 }}
{{- end -}}
{{- end -}}

{{- define "consul.server.autopilotMinQuorum" -}}
{{- add (div (int .Values.server.replicas) 2) 1 -}}
{{- end -}}

{{- define "consul.pdb.connectInject.maxUnavailable" -}}
{{- if eq (int .Values.connectInject.replicas) 1 -}}
{{ 0 }}
{{- else if .Values.connectInject.disruptionBudget.maxUnavailable -}}
{{ .Values.connectInject.disruptionBudget.maxUnavailable -}}
{{- else -}}
{{- if eq (int .Values.connectInject.replicas) 3 -}}
{{- 1 -}}
{{- else -}}
{{- sub (div (int .Values.connectInject.replicas) 2) 1 -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Inject extra environment vars in the format key:value, if populated
*/}}
{{- define "consul.extraEnvironmentVars" -}}
{{- if .extraEnvironmentVars -}}
{{- range $key, $value := .extraEnvironmentVars }}
- name: {{ $key }}
  value: {{ $value | quote }}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Get Consul client CA to use when auto-encrypt is enabled.
This template is for an init container.
*/}}
{{- define "consul.getAutoEncryptClientCA" -}}
- name: get-auto-encrypt-client-ca
  image: {{ .Values.global.imageK8S }}
  {{ template "consul.imagePullPolicy" . }}
  command:
    - "/bin/sh"
    - "-ec"
    - |
      consul-k8s-control-plane get-consul-client-ca \
        -output-file=/consul/tls/client/ca/tls.crt \
        -consul-api-timeout={{ .Values.global.consulAPITimeout }} \
        {{- if .Values.externalServers.enabled }}
        {{- if and .Values.externalServers.enabled (not .Values.externalServers.hosts) }}{{ fail "externalServers.hosts must be set if externalServers.enabled is true" }}{{ end -}}
        -server-addr={{ quote (first .Values.externalServers.hosts) }} \
        -server-port={{ .Values.externalServers.httpsPort }} \
        {{- if .Values.externalServers.tlsServerName }}
        -tls-server-name={{ .Values.externalServers.tlsServerName }} \
        {{- end }}
        {{- else }}
        -server-addr={{ template "consul.fullname" . }}-server \
        -server-port=8501 \
        {{- end }}
        {{- if or (not .Values.externalServers.enabled) (and .Values.externalServers.enabled (not .Values.externalServers.useSystemRoots)) }}
        {{- if .Values.global.secretsBackend.vault.enabled }}
        -ca-file=/vault/secrets/serverca.crt
        {{- else }}
        -ca-file=/consul/tls/ca/tls.crt
        {{- end }}
        {{- end }}
  volumeMounts:
    {{- if not (and .Values.externalServers.enabled .Values.externalServers.useSystemRoots) }}
    {{- if not .Values.global.secretsBackend.vault.enabled }}
    - name: consul-ca-cert
      mountPath: /consul/tls/ca
    {{- end }}
    {{- end }}
    - name: consul-auto-encrypt-ca-cert
      mountPath: /consul/tls/client/ca
  resources:
    requests:
      memory: "50Mi"
      cpu: "50m"
    limits:
      memory: "50Mi"
      cpu: "50m"
{{- end -}}

{{/*
Fails when a reserved name is passed in. This should be used to test against
Consul namespaces and partition names.
This template accepts an array that contains two elements. The first element
is the name that's being checked and the second is the name of the values.yaml
key that's setting the name.

Usage: {{ template "consul.reservedNamesFailer" (list .Values.key "key") }}

*/}}
{{- define "consul.reservedNamesFailer" -}}
{{- $name := index . 0 -}}
{{- $key := index . 1 -}}
{{- if or (eq "system" $name) (eq "universal" $name) (eq "operator" $name) (eq "root" $name) }}
{{- fail (cat "The name" $name "set for key" $key "is reserved by Consul for future use." ) }}
{{- end }}
{{- end -}}

{{/*
Fails when at least one but not all of the following have been set:
- global.secretsBackend.vault.connectInjectRole
- global.secretsBackend.vault.connectInject.tlsCert.secretName
- global.secretsBackend.vault.connectInject.caCert.secretName

The above values are needed in full to turn off web cert manager and allow
connect inject to manage its own webhook certs.

Usage: {{ template "consul.validateVaultWebhookCertConfiguration" . }}

*/}}
{{- define "consul.validateVaultWebhookCertConfiguration" -}}
{{- if or .Values.global.secretsBackend.vault.connectInjectRole .Values.global.secretsBackend.vault.connectInject.tlsCert.secretName .Values.global.secretsBackend.vault.connectInject.caCert.secretName}}
{{- if or (not .Values.global.secretsBackend.vault.connectInjectRole) (not .Values.global.secretsBackend.vault.connectInject.tlsCert.secretName) (not .Values.global.secretsBackend.vault.connectInject.caCert.secretName) }}
{{fail "When one of the following has been set, all must be set:  global.secretsBackend.vault.connectInjectRole, global.secretsBackend.vault.connectInject.tlsCert.secretName, global.secretsBackend.vault.connectInject.caCert.secretName"}}
{{ end }}
{{ end }}
{{- end -}}

{{/*
Consul server environment variables for consul-k8s commands.
*/}}
{{- define "consul.consulK8sConsulServerEnvVars" -}}
- name: CONSUL_ADDRESSES
  {{- if .Values.externalServers.enabled }}
  value: {{ .Values.externalServers.hosts | first }}
  {{- else }}
  value: {{ template "consul.fullname" . }}-server.{{ .Release.Namespace }}.svc
  {{- end }}
- name: CONSUL_GRPC_PORT
  {{- if .Values.externalServers.enabled }}
  value: "{{ .Values.externalServers.grpcPort }}"
  {{- else }}
  value: "8502"
  {{- end }}
- name: CONSUL_HTTP_PORT
  {{- if .Values.externalServers.enabled }}
  value: "{{ .Values.externalServers.httpsPort }}"
  {{- else if .Values.global.tls.enabled }}
  value: "8501"
  {{- else }}
  value: "8500"
  {{- end }}
- name: CONSUL_DATACENTER
  value: {{ .Values.global.datacenter }}
- name: CONSUL_API_TIMEOUT
  value: {{ .Values.global.consulAPITimeout }}
{{- if .Values.global.adminPartitions.enabled }}
- name: CONSUL_PARTITION
  value: {{ .Values.global.adminPartitions.name }}
{{- if .Values.global.acls.manageSystemACLs }}
- name: CONSUL_LOGIN_PARTITION
  value: {{ .Values.global.adminPartitions.name }}
{{- end }}
{{- end }}
{{- if .Values.global.tls.enabled }}
- name: CONSUL_USE_TLS
  value: "true"
{{- if (not (and .Values.externalServers.enabled .Values.externalServers.useSystemRoots)) }}
- name: CONSUL_CACERT_FILE
  {{- if .Values.global.secretsBackend.vault.enabled }}
  value: "/vault/secrets/serverca.crt"
  {{- else }}
  value: "/consul/tls/ca/tls.crt"
  {{- end }}
{{- end }}
{{- if and .Values.externalServers.enabled .Values.externalServers.tlsServerName }}
- name: CONSUL_TLS_SERVER_NAME
  value: {{ .Values.externalServers.tlsServerName }}
{{- end }}
{{- end }}
{{- if and .Values.externalServers.enabled .Values.externalServers.skipServerWatch }}
- name: CONSUL_SKIP_SERVER_WATCH
  value: "true"
{{- end }}
{{- end -}}

{{/*
Fails global.cloud.enabled is true and one of the following secrets is nil or empty.
- global.cloud.resourceId.secretName
- global.cloud.clientId.secretName
- global.cloud.clientSecret.secretName

Usage: {{ template "consul.validateRequiredCloudSecretsExist" . }}

*/}}
{{- define "consul.validateRequiredCloudSecretsExist" -}}
{{- end -}}

{{/*
Fails global.cloud.enabled is true and one of the following secrets has either an empty secretName or secretKey.
- global.cloud.resourceId.secretName / secretKey
- global.cloud.clientId.secretName / secretKey
- global.cloud.clientSecret.secretName / secretKey
- global.cloud.authUrl.secretName / secretKey
- global.cloud.apiHost.secretName / secretKey
- global.cloud.scadaAddress.secretName / secretKey
Usage: {{ template "consul.validateCloudSecretKeys" . }}

*/}}
{{- define "consul.validateCloudSecretKeys" -}}
{{- end -}}

{{/*
Fails if telemetryCollector.clientId or telemetryCollector.clientSecret exist and one of other secrets is nil or empty.
- telemetryCollector.cloud.clientId.secretName
- telemetryCollector.cloud.clientSecret.secretName
- global.cloud.resourceId.secretName

Usage: {{ template "consul.validateTelemetryCollectorCloud" . }}

*/}}
{{- define "consul.validateTelemetryCollectorCloud" -}}
{{- end -}}

{{/*
Fails if telemetryCollector.cloud.resourceId is set but differs from global.cloud.resourceId. This should never happen. Either one or both are set, but they should never differ.
If they differ, that implies we're configuring servers for one HCP Consul cluster but pushing envoy metrics for a different HCP Consul cluster. A user could set the same value
in two secrets (it's questionable whether resourceId should be a secret at all) but we won't know at this point, so we just check secret name+key.

Usage: {{ template "consul.validateTelemetryCollectorResourceId" . }}

*/}}
{{- define "consul.validateTelemetryCollectorResourceId" -}}
{{- end -}}

{{- define "consul.validateTelemetryCollectorCloudSecretKeys" -}}
{{- end -}}

{{/*
Validation for Consul Metrics configuration:

Fail if metrics.enabled=true and metrics.disableAgentHostName=true, but metrics.enableAgentMetrics=false
    - metrics.enabled = true
    - metrics.enableAgentMetrics = false
    - metrics.disableAgentHostName = true

Fail if metrics.enableAgentMetrics=true and metrics.disableAgentHostName=true, but metrics.enabled=false
    - metrics.enabled = false
    - metrics.enableAgentMetrics = true
    - metrics.disableAgentHostName = true

Fail if metrics.enabled=true and metrics.enableHostMetrics=true, but metrics.enableAgentMetrics=false
    - metrics.enabled = true
    - metrics.enableAgentMetrics = false
    - metrics.enableHostMetrics = true

Fail if metrics.enableAgentMetrics=true and metrics.enableHostMetrics=true, but metrics.enabled=false
    - metrics.enabled = false
    - metrics.enableAgentMetrics = true
    - metrics.enableHostMetrics = true

Usage: {{ template "consul.validateMetricsConfig" . }}

*/}}

{{- define "consul.validateMetricsConfig" -}}
{{- if and (not .Values.global.metrics.enableAgentMetrics) (and .Values.global.metrics.disableAgentHostName .Values.global.metrics.enabled )}}
{{fail "When enabling metrics (global.metrics.enabled) and disabling hostname emission from metrics (global.metrics.disableAgentHostName), global.metrics.enableAgentMetrics must be set to true"}}
{{- end }}
{{- if and (not .Values.global.metrics) (and .Values.global.metrics.disableAgentHostName .Values.global.metrics.enableAgentMetrics )}}
{{fail "When enabling Consul agent metrics (global.metrics.enableAgentMetrics) and disabling hostname emission from metrics (global.metrics.disableAgentHostName), global metrics enablement (global.metrics.enabled) must be set to true"}}
{{- end }}
{{- if and (not .Values.global.metrics.enableAgentMetrics) (and .Values.global.metrics.disableAgentHostName .Values.global.metrics.enabled )}}
{{fail "When disabling hostname emission from metrics (global.metrics.disableAgentHostName) and enabling global metrics (global.metrics.enabled), Consul agent metrics must be enabled(global.metrics.enableAgentMetrics=true)"}}
{{- end }}
{{- if and (not .Values.global.metrics.enabled) (and .Values.global.metrics.disableAgentHostName .Values.global.metrics.enableAgentMetrics)}}
{{fail "When enabling Consul agent metrics (global.metrics.enableAgentMetrics) and disabling hostname metrics emission (global.metrics.disableAgentHostName), global metrics must be enabled (global.metrics.enabled)."}}
{{- end }}
{{- end -}}

{{/*
Validation for Consul Datadog Integration deployment:

Fail if Datadog integration enabled and Consul server agent telemetry is not enabled.
    - global.metrics.datadog.enabled=true
    - global.metrics.enableAgentMetrics=false || global.metrics.enabled=false

Fail if Consul OpenMetrics (Prometheus) and DogStatsD metrics are both enabled and configured.
    - global.metrics.datadog.dogstatsd.enabled (scrapes `/v1/agent/metrics?format=prometheus` via the `use_prometheus_endpoint` option)
    - global.metrics.datadog.openMetricsPrometheus.enabled (scrapes `/v1/agent/metrics?format=prometheus`)
    - see https://docs.datadoghq.com/integrations/consul/?tab=host#host for recommendation to not have both

Fail if Datadog OTLP forwarding is enabled and Consul Telemetry Collection is not enabled.
    - global.metrics.datadog.otlp.enabled=true
    - telemetryCollector.enabled=false

Fail if Consul Open Telemetry collector forwarding protocol is not one of either "http" or "grpc"
    - global.metrics.datadog.otlp.protocol!="http" || global.metrics.datadog.otlp.protocol!="grpc"

Usage: {{ template "consul.validateDatadogConfiguration" . }}

*/}}

{{- define "consul.validateDatadogConfiguration" -}}
{{- if and .Values.global.metrics.datadog.enabled (or (not .Values.global.metrics.enableAgentMetrics) (not .Values.global.metrics.enabled) )}}
{{fail "When enabling datadog metrics collection, the /v1/agent/metrics is required to be accessible, therefore global.metrics.enableAgentMetrics and global.metrics.enabled must be also be enabled."}}
{{- end }}
{{- if and .Values.global.metrics.datadog.dogstatsd.enabled .Values.global.metrics.datadog.openMetricsPrometheus.enabled }}
{{fail "You must have one of DogStatsD (global.metrics.datadog.dogstatsd.enabled) or OpenMetrics (global.metrics.datadog.openMetricsPrometheus.enabled) enabled, not both as this is an unsupported configuration." }}
{{- end }}
{{- if and .Values.global.metrics.datadog.otlp.enabled (not .Values.telemetryCollector.enabled) }}
{{fail "Cannot enable Datadog OTLP metrics collection (global.metrics.datadog.otlp.enabled) without consul-telemetry-collector. Ensure Consul OTLP collection is enabled (telemetryCollector.enabled) and configured." }}
{{- end }}
{{- if and (ne ( lower .Values.global.metrics.datadog.otlp.protocol) "http") (ne ( lower .Values.global.metrics.datadog.otlp.protocol) "grpc") }}
{{fail "Valid values for global.metrics.datadog.otlp.protocol must be one of either \"http\" or \"grpc\"." }}
{{- end }}
{{- end -}}

{{/*
Sets the dogstatsd_addr field of the agent configuration dependent on the
socket transport type being used:
  - "UDS" (Unix Domain Socket): prefixes "unix://" to URL and appends path to socket (i.e., unix:///var/run/datadog/dsd.socket)
  - "UDP" (User Datagram Protocol): adds no prefix and appends dogstatsd port number to hostname/IP (i.e., 172.20.180.10:8125)
- global.metrics.enableDatadogIntegration.dogstatsd configuration

Usage: {{ template "consul.dogstatsdAaddressInfo" . }}
*/}}

{{- define "consul.dogstatsdAaddressInfo" -}}
{{- if (and .Values.global.metrics.datadog.enabled .Values.global.metrics.datadog.dogstatsd.enabled) }}
        "dogstatsd_addr": "{{- if eq .Values.global.metrics.datadog.dogstatsd.socketTransportType "UDS" }}unix://{{ .Values.global.metrics.datadog.dogstatsd.dogstatsdAddr }}{{- else }}{{ .Values.global.metrics.datadog.dogstatsd.dogstatsdAddr | trimAll "\"" }}{{- if ne ( .Values.global.metrics.datadog.dogstatsd.dogstatsdPort | int ) 0 }}:{{ .Values.global.metrics.datadog.dogstatsd.dogstatsdPort | toString }}{{- end }}{{- end }}",{{- end }}
{{- end -}}

{{/*
Configures the metrics prefixing that's required to either allow or dissallow certaing RPC or gRPC server calls:

Usage: {{ template "consul.prefixFilter" . }}
*/}}
{{- define "consul.prefixFilter" -}}
{{- $allowList := .Values.global.metrics.prefixFilter.allowList }}
{{- $blockList := .Values.global.metrics.prefixFilter.blockList }}
{{- if and (not (empty $allowList)) (not (empty $blockList)) }}
        "prefix_filter": [{{- range $index, $value := concat $allowList $blockList -}}
    "{{- if (has $value $allowList) }}{{ printf "+%s" ($value | trimAll "\"") }}{{- else }}{{ printf "-%s" ($value | trimAll "\"") }}{{- end }}"{{- if lt $index (sub (len (concat $allowList $blockList)) 1) -}},{{- end -}}
  {{- end -}}],
{{- else if not (empty $allowList) }}
        "prefix_filter": [{{- range $index, $value := $allowList -}}
    "{{ printf "+%s" ($value | trimAll "\"") }}"{{- if lt $index (sub (len $allowList) 1) -}},{{- end -}}
  {{- end -}}],
{{- else if not (empty $blockList) }}
        "prefix_filter": [{{- range $index, $value := $blockList -}}
    "{{ printf "-%s" ($value | trimAll "\"") }}"{{- if lt $index (sub (len $blockList) 1) -}},{{- end -}}
  {{- end -}}],
{{- end }}
{{- end -}}

{{/*
Retrieves the global consul/consul-enterprise version string for use with labels or tags.
Requirements for valid labels:
 -  a valid label must be an empty string or consist of
    =>  alphanumeric characters
    =>  '-', '_' or '.'
    =>  must start and end with an alphanumeric character
        (e.g. 'MyValue',  or 'my_value',  or '12345', regex used for validation is
        '(([A-Za-z0-9][-A-Za-z0-9_.]*)?[A-Za-z0-9])?')

Usage: {{ template "consul.versionInfo" }}
*/}}
{{- define "consul.versionInfo" -}}
{{- $imageVersion := regexSplit ":" .Values.global.image -1 }}
{{- $versionInfo := printf "%s" (index $imageVersion 1 ) | trimSuffix "\"" }}
{{- $sanitizedVersion := "" }}
{{- $pattern := "^([A-Za-z0-9][-A-Za-z0-9_.]*[A-Za-z0-9])?$" }}
{{- if not (regexMatch $pattern $versionInfo) -}}
    {{- $sanitizedVersion = regexReplaceAll "[^A-Za-z0-9-_.]|sha256" $versionInfo "" }}
    {{- $sanitizedVersion = printf "%s" (trimSuffix "-" (trimPrefix "-" $sanitizedVersion)) -}}
{{- else }}
    {{- $sanitizedVersion = $versionInfo }}
{{- end -}}
{{- printf "%s" $sanitizedVersion | trunc 63 | quote }}
{{- end -}}

{{/*
Sets the imagePullPolicy for all Consul images (consul, consul-dataplane, consul-k8s, consul-telemetry-collector)
Valid values are:
    IfNotPresent
    Always
    Never
    In the case of empty, see https://kubernetes.io/docs/concepts/containers/images/#image-pull-policy for details

Usage: {{ template "consul.imagePullPolicy" . }} TODO: melisa should we name this differently ?
*/}}
{{- define "consul.imagePullPolicy" -}}
{{ if or (eq .Values.global.imagePullPolicy "IfNotPresent") (eq .Values.global.imagePullPolicy "Always") (eq .Values.global.imagePullPolicy "Never")}}imagePullPolicy: {{ .Values.global.imagePullPolicy }}
{{ else if eq .Values.global.imagePullPolicy "" }}
{{ else }}
{{fail "imagePullPolicy can only be IfNotPresent, Always, Never, or empty" }}
{{ end }}
{{- end -}}

{{/*
Checks if any of the ingress gateway ports are privileged (< 1024).
This helper takes the ingress gateway configuration and checks both specific
service ports and default service ports to determine if privileged ports are needed.

Usage: {{ template "consul.ingressGatewayHasPrivilegedPorts" (dict "service" .service "defaults" $defaults) }}
*/}}
{{- define "consul.ingressGatewayHasPrivilegedPorts" -}}
{{- $service := .service -}}
{{- $defaults := .defaults -}}
{{- $ports := (default $defaults.service.ports $service.ports) -}}
{{- $hasPrivilegedPorts := false -}}
{{- range $port := $ports -}}
  {{- if lt (int $port.port) 1024 -}}
    {{- $hasPrivilegedPorts = true -}}
  {{- end -}}
{{- end -}}
{{- $hasPrivilegedPorts -}}
{{- end -}}

{{/*
Validates the ai.* section of values.yaml.

The entire template is a no-op unless BOTH of these are true:
  - ai.enabled=true
  - connectInject.enabled=true  (or connectInject.enabled="-" with global.enabled=true)

This means:
  - No ai block in values.yaml at all → skipped (ai.enabled is nil/falsy)
  - ai.enabled=false                  → skipped
  - ai.enabled=true, connectInject=false → skipped (the connectInject gate
    is checked at the template level; the error from the _helpers rule below
    fires instead via the ai-validate.yaml trigger)

Cross-field rules validated when both gates pass:
  1. No AI port may be 20000 (reserved for the Envoy sidecar proxy).
  2. All three ai.agent.defaults ports must be distinct from each other.

Each port is resolved through `default` matching values.yaml defaults:
  inferenceModel.interceptorPort  default 21101
  mcpServer.interceptorPort       default 21102
  agent.interceptorPort           default 21101
  agent.mcpPort                   default 15101
  agent.hitl.port                 default 16101

Usage: {{ template "consul.validateAIConfig" . }}
*/}}
{{- define "consul.validateAIConfig" -}}
{{- $ciEnabled       := (and (ne (.Values.connectInject.enabled | toString) "-") .Values.connectInject.enabled) -}}
{{- $ciGlobalEnabled := (and (eq (.Values.connectInject.enabled | toString) "-") .Values.global.enabled) -}}
{{- $connectInject   := (or $ciEnabled $ciGlobalEnabled) -}}
{{- if and .Values.ai .Values.ai.enabled $connectInject -}}

  {{- /* Resolve every port with its values.yaml default so partially-omitted
         ai blocks never cause a nil-dereference inside the template engine. */}}
  {{- $imcPort   := int (default 21101 .Values.ai.inferenceModel.defaults.interceptorPort) }}
  {{- $mcpPort   := int (default 21102 .Values.ai.mcpServer.defaults.interceptorPort) }}
  {{- $agentInt  := int (default 21101 .Values.ai.agent.defaults.interceptorPort) }}
  {{- $agentMcp  := int (default 15101 .Values.ai.agent.defaults.mcpPort) }}
  {{- $agentHitl := int (default 16101 .Values.ai.agent.defaults.hitl.port) }}

  {{- /* 1. No port may be 20000 (reserved for the Envoy sidecar proxy) */}}
  {{- if eq $imcPort 20000 }}
    {{- fail "ai.inferenceModel.defaults.interceptorPort must not be 20000 (reserved for the Envoy proxy). Default: 21101." }}
  {{- end }}
  {{- if eq $mcpPort 20000 }}
    {{- fail "ai.mcpServer.defaults.interceptorPort must not be 20000 (reserved for the Envoy proxy). Default: 21102." }}
  {{- end }}
  {{- if eq $agentInt 20000 }}
    {{- fail "ai.agent.defaults.interceptorPort must not be 20000 (reserved for the Envoy proxy). Default: 21101." }}
  {{- end }}
  {{- if eq $agentMcp 20000 }}
    {{- fail "ai.agent.defaults.mcpPort must not be 20000 (reserved for the Envoy proxy). Default: 15101." }}
  {{- end }}
  {{- if eq $agentHitl 20000 }}
    {{- fail "ai.agent.defaults.hitl.port must not be 20000 (reserved for the Envoy proxy). Default: 16101." }}
  {{- end }}

  {{- /* 2. All three agent ports must be distinct from each other */}}
  {{- if eq $agentInt $agentMcp }}
    {{- fail (cat "ai.agent.defaults.interceptorPort (" $agentInt ") and ai.agent.defaults.mcpPort (" $agentMcp ") must be different ports. Defaults: 21101 / 15101.") }}
  {{- end }}
  {{- if eq $agentInt $agentHitl }}
    {{- fail (cat "ai.agent.defaults.interceptorPort (" $agentInt ") and ai.agent.defaults.hitl.port (" $agentHitl ") must be different ports. Defaults: 21101 / 16101.") }}
  {{- end }}
  {{- if eq $agentMcp $agentHitl }}
    {{- fail (cat "ai.agent.defaults.mcpPort (" $agentMcp ") and ai.agent.defaults.hitl.port (" $agentHitl ") must be different ports. Defaults: 15101 / 16101.") }}
  {{- end }}

{{- end -}}
{{- end -}}

{{- /*
consul.validateTerminatingGatewayCredentialInjection fails `helm template/install`
when an enabled spec.credentialInjection block is incomplete or invalid, mirroring
the CRD/controller validation so bad input is rejected before a workload is
submitted (Helm renders without admission/controller validation otherwise).
Input dict: ci (effective merged config), name (gateway name for messages).
*/ -}}
{{- define "consul.validateTerminatingGatewayCredentialInjection" -}}
{{- $ci := .ci -}}
{{- $prefix := printf "terminatingGateways gateway %q credentialInjection" .name -}}
{{- if empty $ci.processorImage }}{{ fail (printf "%s: processorImage is required when enabled" $prefix) }}{{ end -}}
{{- if empty $ci.processorConfigMap }}{{ fail (printf "%s: processorConfigMap is required when enabled" $prefix) }}{{ end -}}
{{- if contains "*" (default "" $ci.processorConfigMap) }}{{ fail (printf "%s: processorConfigMap must not contain the wildcard character \"*\"" $prefix) }}{{ end -}}
{{- /* Drain bounds are source-independent: a negative value renders an invalid
       drain-wait / terminationGracePeriodSeconds, and camp-auth-processor's
       drain-wait rejects durations over 300s (the preStop hook would exit
       immediately instead of waiting). Zero disables the drain hook. */ -}}
{{- if and (not (kindIs "invalid" $ci.drainSeconds)) (lt (int $ci.drainSeconds) 0) }}{{ fail (printf "%s: drainSeconds must not be negative" $prefix) }}{{ end -}}
{{- if and (not (kindIs "invalid" $ci.drainSeconds)) (gt (int $ci.drainSeconds) 300) }}{{ fail (printf "%s: drainSeconds must not exceed 300" $prefix) }}{{ end -}}
{{- $source := default "vault" $ci.source -}}
{{- if and (ne $source "vault") (ne $source "kubernetesSecret") }}{{ fail (printf "%s: source must be \"vault\" or \"kubernetesSecret\"" $prefix) }}{{ end -}}
{{- if eq $source "kubernetesSecret" -}}
  {{- if empty $ci.secretName }}{{ fail (printf "%s: secretName is required when source is kubernetesSecret" $prefix) }}{{ end -}}
  {{- if contains "*" (default "" $ci.secretName) }}{{ fail (printf "%s: secretName must not contain the wildcard character \"*\"" $prefix) }}{{ end -}}
{{- else -}}
  {{- if empty $ci.vaultAgentImage }}{{ fail (printf "%s: vaultAgentImage is required when enabled" $prefix) }}{{ end -}}
  {{- if empty $ci.vaultAgentConfigMap }}{{ fail (printf "%s: vaultAgentConfigMap is required when enabled" $prefix) }}{{ end -}}
  {{- if empty $ci.vaultAddress }}{{ fail (printf "%s: vaultAddress is required when enabled" $prefix) }}{{ end -}}
  {{- /* Parsed like the Go API check (url.Parse): an https:// URL with a DNS
         name, IPv4 address, or bracketed IPv6 literal host. */ -}}
  {{- if not (regexMatch "^https://([a-zA-Z0-9._-]+|\\[[0-9a-fA-F:.]+(%[a-zA-Z0-9._~-]+)?\\])(:[0-9]+)?(/.*)?$" (default "" $ci.vaultAddress)) }}{{ fail (printf "%s: vaultAddress must be a valid absolute https:// URL with a host" $prefix) }}{{ end -}}
  {{- if empty $ci.tokenAudience }}{{ fail (printf "%s: tokenAudience is required when enabled" $prefix) }}{{ end -}}
  {{- if not (kindIs "invalid" $ci.tokenExpirationSeconds) -}}
    {{- $exp := int $ci.tokenExpirationSeconds -}}
    {{- if or (lt $exp 600) (gt $exp 43200) }}{{ fail (printf "%s: tokenExpirationSeconds must be between 600 and 43200 seconds" $prefix) }}{{ end -}}
  {{- end -}}
  {{- if and (not (kindIs "invalid" $ci.drainSeconds)) (not (kindIs "invalid" $ci.tokenExpirationSeconds)) (gt (int $ci.drainSeconds) (int $ci.tokenExpirationSeconds)) }}{{ fail (printf "%s: drainSeconds must not exceed tokenExpirationSeconds" $prefix) }}{{ end -}}
  {{- range $field := list "vaultNamespace" "vaultCAConfigMap" "vaultAgentConfigMap" "tokenAudience" -}}
    {{- if contains "*" (default "" (index $ci $field)) }}{{ fail (printf "%s: %s must not contain the wildcard character \"*\"" $prefix $field) }}{{ end -}}
  {{- end -}}
  {{- if and (not (empty $ci.vaultAgentConfigMap)) (eq $ci.processorConfigMap $ci.vaultAgentConfigMap) }}{{ fail (printf "%s: vaultAgentConfigMap must reference a different ConfigMap than processorConfigMap" $prefix) }}{{ end -}}
{{- end -}}
{{- end -}}

{{- /*
consul.terminatingGatewayCredentialVaultAgent renders a Vault Agent container
(init or sidecar) for terminating-gateway credential injection. It authenticates
to Vault with the projected Kubernetes service-account token, verifies the Vault
server via VAULT_CACERT (when a CA ConfigMap is configured, using its ca.crt key),
keeps its token sink private, and renders external-model credentials into the
shared memory volume.
It carries no secret material. Input dict: name, exitAfterAuth (bool), ci, root.
*/ -}}
{{- define "consul.terminatingGatewayCredentialVaultAgent" -}}
- name: {{ .name }}
  image: {{ .ci.vaultAgentImage | quote }}
  {{- with (include "consul.imagePullPolicy" .root | trim) }}
  {{ . }}
  {{- end }}
  command:
  - "vault"
  args:
  - "agent"
  - "-config=/consul/vault-agent-config"
  {{- if .exitAfterAuth }}
  - "-exit-after-auth"
  {{- end }}
  env:
  - name: VAULT_ADDR
    value: {{ .ci.vaultAddress | quote }}
  {{- if .ci.vaultNamespace }}
  - name: VAULT_NAMESPACE
    value: {{ .ci.vaultNamespace | quote }}
  {{- end }}
  {{- if .ci.vaultCAConfigMap }}
  - name: VAULT_CACERT
    value: /consul/vault-ca/ca.crt
  {{- end }}
  securityContext:
    allowPrivilegeEscalation: false
    readOnlyRootFilesystem: true
    capabilities:
      drop:
      - ALL
    runAsNonRoot: true
    # The upstream Vault image defaults to root (uid 0); running `vault agent`
    # directly bypasses the entrypoint that would drop privileges, so pin the
    # non-root vault user (uid 100) to satisfy runAsNonRoot. Shared file access to
    # the rendered-credential volume is provided by the pod fsGroup.
    runAsUser: 100
    seccompProfile:
      type: RuntimeDefault
  volumeMounts:
  - name: camp-vault-token
    mountPath: /consul/vault-token
    readOnly: true
  - name: camp-vault-agent-config
    mountPath: /consul/vault-agent-config
    readOnly: true
  - name: camp-vault-rendered
    mountPath: /consul/vault-rendered
  - name: camp-vault-agent-private
    mountPath: /consul/vault-agent-private
  {{- if .ci.vaultCAConfigMap }}
  - name: camp-vault-ca
    mountPath: /consul/vault-ca
    readOnly: true
  {{- end }}
{{- end -}}

{{- /*
consul.terminatingGatewayCredentialAuthProcessor renders the camp-auth-processor
sidecar for terminating-gateway credential injection. It reads the Vault
Agent-rendered credentials read-only, serves the ext_proc UDS on a writable
socket volume, and loads its non-secret binding config read-only. It must NOT
mount the Vault token or the private Agent token sink. Input dict: ci, logLevel,
drainSeconds, root.
*/ -}}
{{- define "consul.terminatingGatewayCredentialAuthProcessor" -}}
- name: camp-auth-processor
  image: {{ .ci.processorImage | quote }}
  {{- with (include "consul.imagePullPolicy" .root | trim) }}
  {{ . }}
  {{- end }}
  command:
  - "camp-auth-processor"
  args:
  - "-config-file=/consul/processor-config/config.json"
  - "-uds-path=/consul/auth-socket/auth.sock"
  {{- /* camp-auth-processor accepts debug/info/warn/error; Consul's trace
         level maps to its most verbose level. */}}
  - "-log-level={{ if eq (lower .logLevel) "trace" }}debug{{ else }}{{ .logLevel }}{{ end }}"
  securityContext:
    allowPrivilegeEscalation: false
    readOnlyRootFilesystem: true
    capabilities:
      drop:
      - ALL
    runAsNonRoot: true
    seccompProfile:
      type: RuntimeDefault
  volumeMounts:
  - name: camp-vault-rendered
    mountPath: /consul/vault-rendered
    readOnly: true
  - name: camp-auth-socket
    mountPath: /consul/auth-socket
  - name: camp-auth-processor-config
    mountPath: /consul/processor-config
    readOnly: true
  readinessProbe:
    exec:
      command:
      - "camp-auth-processor"
      - "health"
      - "-uds-path=/consul/auth-socket/auth.sock"
      - "-ready"
    initialDelaySeconds: 5
    periodSeconds: 10
    failureThreshold: 3
    timeoutSeconds: 5
  livenessProbe:
    exec:
      command:
      - "camp-auth-processor"
      - "health"
      - "-uds-path=/consul/auth-socket/auth.sock"
      - "-live"
    # Liveness only checks that the process is alive; it stays tolerant of
    # recoverable Vault/file errors (credential unavailability is surfaced via
    # readiness, not liveness) so transient issues don't restart the container.
    initialDelaySeconds: 15
    periodSeconds: 10
    failureThreshold: 6
    timeoutSeconds: 5
  {{- if gt (int .drainSeconds) 0 }}
  lifecycle:
    preStop:
      exec:
        command:
        - "camp-auth-processor"
        - "drain-wait"
        - "-duration={{ .drainSeconds }}s"
  {{- end }}
  resources:
    requests:
      memory: "50Mi"
      cpu: "50m"
    limits:
      memory: "50Mi"
      cpu: "50m"
{{- end -}}

{{/*
Renders an annotations value as a JSON object for the helm-values ConfigMap
read by the TerminatingGateway controller. Annotation values are documented as
multi-line YAML strings (and may contain template expressions), so they are
rendered with tpl and parsed with fromYaml. Map values are passed through.

Usage: {{ template "consul.helmValuesAnnotationsJSON" (dict "root" $ "value" .Values.some.annotations "name" "some.annotations") }}
*/}}
{{- define "consul.helmValuesAnnotationsJSON" -}}
{{- $value := .value -}}
{{- if not $value -}}
{}
{{- else if kindIs "string" $value -}}
{{- $parsed := tpl $value .root | fromYaml -}}
{{- if hasKey $parsed "Error" -}}
{{- fail (printf "%s must be a YAML map of annotations: %s" .name (get $parsed "Error")) -}}
{{- end -}}
{{- $parsed | toJson -}}
{{- else -}}
{{- $value | toJson -}}
{{- end -}}
{{- end -}}
{{/*
Whether external server discovery uses the Kubernetes provider.
*/}}
{{- define "consul.featureGateKubernetesDiscovery" -}}
{{- if and .Values.externalServers.enabled .Values.externalServers.hosts -}}
{{- $addresses := first .Values.externalServers.hosts -}}
{{- if and (not (hasPrefix "exec=" $addresses)) (regexMatch `(^|[[:space:]])provider="?k8s"?([[:space:]]|$)` $addresses) -}}
true
{{- end -}}
{{- end -}}
{{- end -}}
