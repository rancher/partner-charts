{{/* vim: set filetype=mustache: */}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "loft.fullname" -}}
{{- printf "loft" -}}
{{- end -}}

{{/*
Create the name of the service account to use
*/}}
{{- define "loft.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
{{ default (include "loft.fullname" .) .Values.serviceAccount.name }}
{{- else -}}
{{ default "default" .Values.serviceAccount.name }}
{{- end -}}
{{- end -}}

{{/*
Default image name for a given product
*/}}
{{- define "loft.defaultImage" -}}
{{- printf "ghcr.io/loft-sh/loft:%s" .Chart.Version -}}
{{- end -}}

{{/*
Resolve the default image tag for the vCluster Platform image.
Head/dev charts are published with a sentinel version of "0.0.0-latest" or
"0.0.0-<sha>", but the matching platform image exists only under the rolling
"head" tag, never under the chart version. So the sentinel resolves to "head"
while real releases (and the bare "0.0.0" source default) pass through
unchanged. Only loft-sh/vcluster-platform publishes a "head" tag, so callers
must scope this to that repository.
*/}}
{{- define "loft.platformImageTag" -}}
{{- if hasPrefix "0.0.0-" .Chart.Version -}}head{{- else -}}{{ .Chart.Version }}{{- end -}}
{{- end -}}

{{/*
Populate image ref for a given product
*/}}
{{- define "loft.imageRef" -}}
{{- $registry := default "ghcr.io" .Values.imageRef.registry -}}
{{- $repository := coalesce .Values.imageRef.repository .repo "loft-sh/vcluster-platform" -}}
{{- $defaultTag := .Chart.Version -}}
{{- if eq $repository "loft-sh/vcluster-platform" -}}
{{- $defaultTag = include "loft.platformImageTag" . -}}
{{- end -}}
{{- $tag := default $defaultTag .Values.imageRef.tag -}}
{{- printf "%s/%s:%s" $registry $repository $tag -}}
{{- end -}}

{{- define "loft.image" -}}
  {{- if .Values.product -}}
    {{- if eq .Values.product "vcluster-pro" -}}
	  {{- if .Values.imageRef -}}
	    {{ include "loft.imageRef" $ }}
	  {{- else -}}
		{{- printf "ghcr.io/loft-sh/vcluster-platform:%s" (include "loft.platformImageTag" .) -}}
	  {{- end -}}
    {{- else -}}
	  {{- if .Values.imageRef -}}
	    {{ include "loft.imageRef" (merge (dict "repo" "loft-sh/loft") $) }}
	  {{- else -}}
        {{ coalesce .Values.image (include "loft.defaultImage" .) }}
	  {{- end -}}
    {{- end -}}
  {{- else -}}
	{{- if .Values.imageRef -}}
	  {{ include "loft.imageRef" (merge (dict "repo" "loft-sh/loft") $) }}
	{{- else -}}
      {{ coalesce .Values.image (include "loft.defaultImage" .) }}
	{{- end -}}
  {{- end -}}
{{- end -}}


{{/*
Populate audit image ref
*/}}
{{- define "loft.auditImageRef" -}}
{{- $registry := default "docker.io" .Values.audit.imageRef.registry -}}
{{- $repository := default "library/alpine" .Values.audit.imageRef.repository -}}
{{- $tag := default "3.24.3" .Values.audit.imageRef.tag -}}
{{- printf "%s/%s:%s" $registry $repository $tag -}}
{{- end -}}

{{- define "loft.auditImage" -}}
  {{- if .Values.audit.imageRef -}}
    {{ include "loft.auditImageRef" . }}
  {{- else -}}
    {{ default "library/alpine:3.24.3" .Values.audit.image }}
  {{- end -}}
{{- end -}}

{{/*
True when multiRegion is set and enabled (safe when .Values.multiRegion is nil).
Output is truthy when enabled, empty otherwise; use in {{ if include "loft.multiRegionEnabled" . }}.
*/}}
{{- define "loft.multiRegionEnabled" -}}
{{- if and .Values.multiRegion .Values.multiRegion.enabled }}{{ true }}{{ end -}}
{{- end -}}

{{/*
True when config.database is set and enabled (safe when .Values.config or .Values.config.database is nil).
Output is truthy when enabled, empty otherwise; use in {{ if include "loft.configDatabaseEnabled" . }}.
*/}}
{{- define "loft.configDatabaseEnabled" -}}
{{- if and .Values.config .Values.config.database .Values.config.database.enabled }}{{ true }}{{ end -}}
{{- end -}}

{{/*
True when logging.file is set and enabled (safe when .Values.logging or .Values.logging.file is nil).
Output is truthy when enabled, empty otherwise; use in {{ if include "loft.fileLoggingEnabled" . }}.
*/}}
{{- define "loft.fileLoggingEnabled" -}}
{{- if and .Values.logging .Values.logging.file .Values.logging.file.enabled }}{{ true }}{{ end -}}
{{- end -}}

{{/*
True when env.LOFT_EMBEDDED_K8S is set to "true" (safe when .Values.env is nil).
Output is truthy when enabled, empty otherwise; use in {{ if include "loft.envEmbeddedK8sEnabled" . }}.
*/}}
{{- define "loft.envEmbeddedK8sEnabled" -}}
{{- if eq (.Values.env.LOFT_EMBEDDED_K8S | toString) "true" }}{{ true }}{{ end -}}
{{- end -}}

{{- define "loft.strategyType" -}}
  {{- if and .Values.strategy .Values.strategy.type -}}
    {{- .Values.strategy.type -}}
  {{- else -}}
    {{- if eq (int .Values.replicaCount) 1 -}}
      {{ printf "Recreate" }}
    {{- else -}}
      {{ printf "RollingUpdate" }}
    {{- end -}}
  {{- end -}}
{{- end -}}

{{- define "loft.strategy" -}}
{{- $type := include "loft.strategyType" . -}}
type: {{ $type }}
{{- if eq $type "RollingUpdate" }}
rollingUpdate:
  maxSurge: 1
  {{- if (eq (int .Values.replicaCount) 1) }}
  maxUnavailable: 0
  {{- else }}
  maxUnavailable: 1
  {{- end }}
{{- end -}}
{{- end -}}

{{- define "loft.leastPrivilegeModeValues" -}}
{{- $defaultValues := dict
		"enabled" false
		"clusterAccess" (dict "enabled" true)
		"projectQuotas" (dict "enabled" true)
		"secrets" (dict "enabled" true)
		"sleepMode" (dict "enabled" true)
		"role" (dict "enabled" true "extraRules" (list) "overwriteRules" (list))
		"clusterRole" (dict "enabled" true "extraRules" (list) "overwriteRules" (list))
		"namespaceAdminRole" (dict "enabled" true "extraRules" (list) "overwriteRules" (list)) -}}
{{- if .Values.leastPrivilegeMode -}}
{{ mergeOverwrite $defaultValues .Values.leastPrivilegeMode | toJson }}
{{- else -}}
{{ $defaultValues | toJson }}
{{- end -}}
{{- end -}}

{{- define "loft.isLeastPrivilegeModeEnabled" -}}
{{- if .Values.leastPrivilegeMode -}}
{{- if eq true .Values.leastPrivilegeMode.enabled -}}
{{ true }}
{{- end -}}
{{- end -}}
{{- end -}}
